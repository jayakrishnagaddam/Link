using System.Collections.Generic;
using System.Threading.Tasks;
using Trackfit.Services.DTOs;

namespace Trackfit.Services.Interfaces
{
    public interface IChallengeService
    {
        // Challenges
        Task<ChallengeDto> GetChallengeAsync(int challengeId);
        Task<IEnumerable<ChallengeDto>> GetAllChallengesAsync(bool includePrivate = false);
        Task<IEnumerable<ChallengeDto>> GetActiveChallengesAsync();
        Task<IEnumerable<ChallengeDto>> GetUserChallengesAsync(int userId);
        Task<ChallengeDto> CreateChallengeAsync(ChallengeDto challengeDto);
        Task<ChallengeDto> UpdateChallengeAsync(ChallengeDto challengeDto);
        Task<bool> DeleteChallengeAsync(int challengeId);
        
        // Challenge participants
        Task<bool> JoinChallengeAsync(int challengeId, int userId);
        Task<bool> LeaveChallengeAsync(int challengeId, int userId);
        Task<IEnumerable<ChallengeParticipantDto>> GetChallengeParticipantsAsync(int challengeId);
        Task<ChallengeParticipantDto> GetUserChallengeProgressAsync(int challengeId, int userId);
        Task<bool> UpdateChallengeProgressAsync(int challengeId, int userId, decimal progress);
        
        // Challenge leaderboards
        Task<IEnumerable<ChallengeLeaderboardEntryDto>> GetChallengeLeaderboardAsync(int challengeId);
        
        // Challenge invitations
        Task<bool> InviteUserToChallengeAsync(int challengeId, int inviterId, int inviteeId);
    }
}
