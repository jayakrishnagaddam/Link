import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-workout-form',
  templateUrl: './workout-form.component.html',
  styleUrls: ['./workout-form.component.css']
})
export class WorkoutFormComponent implements OnInit {
  workoutForm: FormGroup;
  editMode = false;
  workoutId: number | null = null;
  
  workoutCategories = [
    'Cardio', 'Strength', 'HIIT', 'Yoga', 'Pilates', 'Flexibility', 'CrossFit', 'Bodyweight'
  ];
  
  difficultyLevels = [
    'Beginner', 'Intermediate', 'Advanced', 'Expert'
  ];

  constructor(
    private fb: FormBuilder, 
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.workoutForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      description: ['', Validators.required],
      category: ['', Validators.required],
      difficulty: ['', Validators.required],
      duration: [30, [Validators.required, Validators.min(1)]],
      caloriesBurned: [0, [Validators.min(0)]],
      exercises: this.fb.array([])
    });
  }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.editMode = true;
        this.workoutId = +params['id'];
        this.loadWorkoutData(this.workoutId);
      } else {
        // New workout - add initial exercise
        this.addExercise();
      }
    });
  }

  loadWorkoutData(id: number): void {
    // In a real app, this would come from a service
    const workout = {
      id: id,
      name: 'Full Body HIIT',
      description: 'High-intensity interval training that targets all major muscle groups.',
      duration: 45,
      caloriesBurned: 450,
      difficulty: 'Intermediate',
      category: 'HIIT',
      exercises: [
        { id: 1, name: 'Jumping Jacks', sets: 3, reps: 20, duration: 0, rest: 30, instructions: 'Jump with feet apart and hands above head, then return to standing position' },
        { id: 2, name: 'Push-ups', sets: 3, reps: 15, duration: 0, rest: 45, instructions: 'Keep body straight, lower to ground and push back up' },
        { id: 3, name: 'Mountain Climbers', sets: 3, reps: 0, duration: 30, rest: 30, instructions: 'In plank position, alternate bringing knees to chest' },
        { id: 4, name: 'Squats', sets: 3, reps: 20, duration: 0, rest: 45, instructions: 'Bend knees and lower as if sitting, keep back straight' },
        { id: 5, name: 'Plank', sets: 3, reps: 0, duration: 45, rest: 30, instructions: 'Hold plank position with core engaged and back straight' }
      ]
    };
    
    this.workoutForm.patchValue({
      name: workout.name,
      description: workout.description,
      category: workout.category,
      difficulty: workout.difficulty,
      duration: workout.duration,
      caloriesBurned: workout.caloriesBurned
    });
    
    // Clear any default exercises and add the loaded ones
    this.exercises.clear();
    
    workout.exercises.forEach(exercise => {
      this.exercises.push(this.fb.group({
        name: [exercise.name, Validators.required],
        sets: [exercise.sets, [Validators.required, Validators.min(1)]],
        reps: [exercise.reps, Validators.min(0)],
        duration: [exercise.duration, Validators.min(0)],
        rest: [exercise.rest, [Validators.required, Validators.min(0)]],
        instructions: [exercise.instructions]
      }));
    });
  }
  
  get exercises(): FormArray {
    return this.workoutForm.get('exercises') as FormArray;
  }
  
  addExercise(): void {
    const exerciseGroup = this.fb.group({
      name: ['', Validators.required],
      sets: [3, [Validators.required, Validators.min(1)]],
      reps: [12, Validators.min(0)],
      duration: [0, Validators.min(0)],
      rest: [30, [Validators.required, Validators.min(0)]],
      instructions: ['']
    });
    
    this.exercises.push(exerciseGroup);
  }
  
  removeExercise(index: number): void {
    this.exercises.removeAt(index);
  }
  
  moveExerciseUp(index: number): void {
    if (index === 0) return;
    
    const currentExercise = this.exercises.at(index);
    const exerciseValue = currentExercise.value;
    
    this.exercises.removeAt(index);
    this.exercises.insert(index - 1, this.fb.group(exerciseValue));
  }
  
  moveExerciseDown(index: number): void {
    if (index === this.exercises.length - 1) return;
    
    const currentExercise = this.exercises.at(index);
    const exerciseValue = currentExercise.value;
    
    this.exercises.removeAt(index);
    this.exercises.insert(index + 1, this.fb.group(exerciseValue));
  }
  
  onSubmit(): void {
    if (this.workoutForm.invalid) {
      // Mark all fields as touched to trigger validation visuals
      this.markFormGroupTouched(this.workoutForm);
      return;
    }
    
    console.log('Saving workout', this.workoutForm.value);
    
    // In a real app, this would call a service to save
    setTimeout(() => {
      this.router.navigate(['/workouts']);
    }, 1000);
  }
  
  markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      } else if (control instanceof FormArray) {
        control.controls.forEach(ctrl => {
          if (ctrl instanceof FormGroup) {
            this.markFormGroupTouched(ctrl);
          } else {
            ctrl.markAsTouched();
          }
        });
      }
    });
  }
}