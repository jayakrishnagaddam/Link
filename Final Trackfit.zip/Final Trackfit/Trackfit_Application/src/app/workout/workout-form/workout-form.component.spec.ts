import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { of } from 'rxjs';
import { WorkoutFormComponent } from './workout-form.component';

describe('WorkoutFormComponent', () => {
  let component: WorkoutFormComponent;
  let fixture: ComponentFixture<WorkoutFormComponent>;
  let router: Router;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WorkoutFormComponent ],
      imports: [ ReactiveFormsModule ],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            params: of({})
          }
        },
        {
          provide: Router,
          useValue: {
            navigate: jasmine.createSpy('navigate')
          }
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkoutFormComponent);
    component = fixture.componentInstance;
    router = TestBed.inject(Router);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize form with default values for new workout', () => {
    expect(component.editMode).toBeFalse();
    expect(component.workoutId).toBeNull();
    expect(component.exercises.length).toBe(1); // Should have one default exercise
  });

  it('should add a new exercise when addExercise is called', () => {
    const initialLength = component.exercises.length;
    component.addExercise();
    expect(component.exercises.length).toBe(initialLength + 1);
  });

  it('should remove an exercise when removeExercise is called', () => {
    component.addExercise(); // Add a second exercise
    const initialLength = component.exercises.length;
    component.removeExercise(0);
    expect(component.exercises.length).toBe(initialLength - 1);
  });

  it('should validate required fields', () => {
    component.workoutForm.controls['name'].setValue('');
    component.workoutForm.controls['description'].setValue('');
    component.workoutForm.controls['category'].setValue('');
    component.workoutForm.controls['difficulty'].setValue('');
    
    expect(component.workoutForm.valid).toBeFalse();
    
    component.workoutForm.controls['name'].setValue('Test Workout');
    component.workoutForm.controls['description'].setValue('Test Description');
    component.workoutForm.controls['category'].setValue('Cardio');
    component.workoutForm.controls['difficulty'].setValue('Beginner');
    
    expect(component.workoutForm.valid).toBeTrue();
  });

  it('should submit the form and navigate when valid', () => {
    spyOn(console, 'log');
    
    component.workoutForm.controls['name'].setValue('Test Workout');
    component.workoutForm.controls['description'].setValue('Test Description');
    component.workoutForm.controls['category'].setValue('Cardio');
    component.workoutForm.controls['difficulty'].setValue('Beginner');
    
    component.onSubmit();
    expect(console.log).toHaveBeenCalled();
    
    // Fast-forward time to test the navigation occurs after the timeout
    jasmine.clock().install();
    jasmine.clock().tick(1000);
    
    expect(router.navigate).toHaveBeenCalledWith(['/workouts']);
    jasmine.clock().uninstall();
  });
});