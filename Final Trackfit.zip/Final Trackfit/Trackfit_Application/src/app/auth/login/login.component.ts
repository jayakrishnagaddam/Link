import { Component, type OnInit } from "@angular/core"
import { type FormBuilder, type FormGroup, Validators } from "@angular/forms"
import type { Router, ActivatedRoute } from "@angular/router"
import { first } from "rxjs/operators"

import type { AuthService } from "../../services/auth.service"
import type { NotificationService } from "../../services/notification.service"

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup
  loading = false
  submitted = false
  returnUrl: string
  error = ""
  userType = "User"

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService,
    private notificationService: NotificationService,
  ) {
    // Redirect to home if already logged in
    if (this.authService.currentUserValue) {
      this.redirectToDashboard()
    }
  }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      email: ["", [Validators.required, Validators.email]],
      password: ["", Validators.required],
      rememberMe: [false],
    })

    // Get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams["returnUrl"] || "/"

    // Get user type from route parameters
    const userTypeParam = this.route.snapshot.queryParams["userType"]
    if (userTypeParam && ["User", "Trainer", "Admin"].includes(userTypeParam)) {
      this.userType = userTypeParam
    }
  }

  // Convenience getter for easy access to form fields
  get f() {
    return this.loginForm.controls
  }

  onSubmit(): void {
    this.submitted = true

    // Stop here if form is invalid
    if (this.loginForm.invalid) {
      return
    }

    this.loading = true
    this.authService
      .login({
        email: this.f.email.value,
        password: this.f.password.value,
        rememberMe: this.f.rememberMe.value,
      })
      .pipe(first())
      .subscribe(
        (user) => {
          // Check if user type matches the selected type
          if (user.userType !== this.userType) {
            this.error = `Invalid login. Please use the ${this.userType.toLowerCase()} login.`
            this.loading = false
            return
          }

          this.notificationService.success("Login successful")
          this.redirectToDashboard()
        },
        (error) => {
          this.error = error.error?.message || "Invalid email or password"
          this.loading = false
        },
      )
  }

  switchUserType(userType: string): void {
    this.userType = userType
  }

  navigateToRegister(): void {
    this.router.navigate(["/register"], { queryParams: { userType: this.userType } })
  }

  navigateToForgotPassword(): void {
    this.router.navigate(["/forgot-password"])
  }

  private redirectToDashboard(): void {
    const user = this.authService.currentUserValue
    if (!user) return

    switch (user.userType) {
      case "User":
        this.router.navigate(["/user/dashboard"])
        break
      case "Trainer":
        this.router.navigate(["/trainer/dashboard"])
        break
      case "Admin":
        this.router.navigate(["/admin/dashboard"])
        break
      default:
        this.router.navigate(["/"])
        break
    }
  }
}
