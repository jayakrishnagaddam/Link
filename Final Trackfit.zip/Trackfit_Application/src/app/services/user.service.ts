import { Injectable } from "@angular/core"
import type { HttpClient } from "@angular/common/http"
import type { Observable } from "rxjs"

import type { User, UserProfile, UserStats, UserProgressReport, UserAchievement } from "../models/user.model"
import type { UserWorkoutLog } from "../models/workout.model"
import type { NutritionLog } from "../models/nutrition.model"
import { environment } from "../../environments/environment"

@Injectable({
  providedIn: "root",
})
export class UserService {
  private apiUrl = `${environment.apiUrl}/users`

  constructor(private http: HttpClient) {}

  getUserById(id: number): Observable<User> {
    return this.http.get<User>(`${this.apiUrl}/${id}`)
  }

  getUserProfile(id: number): Observable<UserProfile> {
    return this.http.get<UserProfile>(`${this.apiUrl}/profile/${id}`)
  }

  updateUserProfile(profile: UserProfile): Observable<UserProfile> {
    return this.http.put<UserProfile>(`${this.apiUrl}/profile/${profile.userId}`, profile)
  }

  getUserStats(id: number): Observable<UserStats> {
    return this.http.get<UserStats>(`${this.apiUrl}/${id}/stats`)
  }

  getUserProgressReport(id: number, startDate: Date, endDate: Date): Observable<UserProgressReport> {
    return this.http.get<UserProgressReport>(
      `${this.apiUrl}/${id}/progress?startDate=${startDate.toISOString()}&endDate=${endDate.toISOString()}`,
    )
  }

  getUserWorkoutHistory(id: number, page = 1, pageSize = 10): Observable<UserWorkoutLog[]> {
    return this.http.get<UserWorkoutLog[]>(`${this.apiUrl}/${id}/workouts?page=${page}&pageSize=${pageSize}`)
  }

  logWorkout(workout: UserWorkoutLog): Observable<UserWorkoutLog> {
    return this.http.post<UserWorkoutLog>(`${this.apiUrl}/${workout.userId}/workouts`, workout)
  }

  getUserNutritionLogs(id: number, date?: Date): Observable<NutritionLog[]> {
    let url = `${this.apiUrl}/${id}/nutrition`
    if (date) {
      url += `?date=${date.toISOString()}`
    }
    return this.http.get<NutritionLog[]>(url)
  }

  logNutrition(nutrition: NutritionLog): Observable<NutritionLog> {
    return this.http.post<NutritionLog>(`${this.apiUrl}/${nutrition.userId}/nutrition`, nutrition)
  }

  getUserAchievements(id: number): Observable<UserAchievement[]> {
    return this.http.get<UserAchievement[]>(`${this.apiUrl}/${id}/achievements`)
  }
}
