import { Component, type OnInit } from "@angular/core"
import type { Router } from "@angular/router"
import type { ChallengeService } from "../../services/challenge.service"
import type { AuthService } from "../../services/auth.service"
import type { NotificationService } from "../../services/notification.service"
import type { User } from "../../models/user.model"
import type { Challenge, UserChallenge } from "../../models/challenge.model"

@Component({
  selector: "app-user-challenges",
  templateUrl: "./user-challenges.component.html",
  styleUrls: ["./user-challenges.component.css"],
})
export class UserChallengesComponent implements OnInit {
  currentUser: User | null = null
  activeChallenges: UserChallenge[] = []
  completedChallenges: UserChallenge[] = []
  availableChallenges: Challenge[] = []

  activeTab = "active"

  loading = {
    active: true,
    completed: true,
    available: true,
  }

  error = {
    active: "",
    completed: "",
    available: "",
  }

  constructor(
    private authService: AuthService,
    private challengeService: ChallengeService,
    private notificationService: NotificationService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.authService.currentUser.subscribe((user) => {
      this.currentUser = user
      if (user) {
        this.loadActiveChallenges(user.userId)
        this.loadCompletedChallenges(user.userId)
        this.loadAvailableChallenges(user.userId)
      }
    })
  }

  setActiveTab(tab: string): void {
    this.activeTab = tab
  }

  loadActiveChallenges(userId: number): void {
    this.loading.active = true
    this.challengeService.getUserActiveChallenges(userId).subscribe(
      (challenges) => {
        this.activeChallenges = challenges
        this.loading.active = false
      },
      (error) => {
        console.error("Error loading active challenges", error)
        this.error.active = "Failed to load active challenges"
        this.loading.active = false
      },
    )
  }

  loadCompletedChallenges(userId: number): void {
    this.loading.completed = true
    this.challengeService.getUserCompletedChallenges(userId).subscribe(
      (challenges) => {
        this.completedChallenges = challenges
        this.loading.completed = false
      },
      (error) => {
        console.error("Error loading completed challenges", error)
        this.error.completed = "Failed to load completed challenges"
        this.loading.completed = false
      },
    )
  }

  loadAvailableChallenges(userId: number): void {
    this.loading.available = true
    this.challengeService.getAvailableChallenges(userId).subscribe(
      (challenges) => {
        this.availableChallenges = challenges
        this.loading.available = false
      },
      (error) => {
        console.error("Error loading available challenges", error)
        this.error.available = "Failed to load available challenges"
        this.loading.available = false
      },
    )
  }

  joinChallenge(challengeId: number): void {
    if (!this.currentUser) return

    this.challengeService.joinChallenge(this.currentUser.userId, challengeId).subscribe(
      (success) => {
        if (success) {
          this.notificationService.success("You've joined the challenge!")
          this.loadActiveChallenges(this.currentUser!.userId)
          this.loadAvailableChallenges(this.currentUser!.userId)
        } else {
          this.notificationService.error("Failed to join challenge")
        }
      },
      (error) => {
        this.notificationService.error("An error occurred while joining the challenge")
        console.error("Error joining challenge", error)
      },
    )
  }

  leaveChallenge(userChallengeId: number): void {
    if (confirm("Are you sure you want to leave this challenge? Your progress will be lost.")) {
      this.challengeService.leaveChallenge(userChallengeId).subscribe(
        (success) => {
          if (success) {
            this.notificationService.success("You've left the challenge")
            if (this.currentUser) {
              this.loadActiveChallenges(this.currentUser.userId)
              this.loadAvailableChallenges(this.currentUser.userId)
            }
          } else {
            this.notificationService.error("Failed to leave challenge")
          }
        },
        (error) => {
          this.notificationService.error("An error occurred while leaving the challenge")
          console.error("Error leaving challenge", error)
        },
      )
    }
  }

  viewChallengeDetails(challengeId: number): void {
    this.router.navigate(["/challenges", challengeId])
  }

  getChallengeProgress(challenge: UserChallenge): number {
    if (challenge.targetValue === 0) return 0
    return Math.min(100, Math.round((challenge.currentValue / challenge.targetValue) * 100))
  }

  getDaysRemaining(endDate: Date | string): number {
    const end = new Date(endDate)
    const today = new Date()

    // Set time to midnight for accurate day calculation
    end.setHours(0, 0, 0, 0)
    today.setHours(0, 0, 0, 0)

    const diffTime = end.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))

    return Math.max(0, diffDays)
  }

  formatDate(date: Date | string): string {
    return new Date(date).toLocaleDateString()
  }
}
