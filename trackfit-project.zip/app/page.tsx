"use client"

import  from "../Trackfit_Application/src/app/app.module"

export default function SyntheticV0PageForDeployment() {
  return < />
}