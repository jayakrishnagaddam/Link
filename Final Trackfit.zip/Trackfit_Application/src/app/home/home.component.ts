import { Component, type OnInit } from "@angular/core"
import type { Router } from "@angular/router"
import type { AuthService } from "../services/auth.service"

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"],
})
export class HomeComponent implements OnInit {
  isLoggedIn = false
  userType: string | null = null

  constructor(
    private authService: AuthService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.authService.currentUser.subscribe((user) => {
      this.isLoggedIn = !!user
      this.userType = user ? user.userType : null

      // Redirect if already logged in
      if (this.isLoggedIn) {
        this.redirectToDashboard()
      }
    })
  }

  navigateToLogin(userType: string): void {
    this.router.navigate(["/login"], { queryParams: { userType } })
  }

  private redirectToDashboard(): void {
    switch (this.userType) {
      case "User":
        this.router.navigate(["/user/dashboard"])
        break
      case "Trainer":
        this.router.navigate(["/trainer/dashboard"])
        break
      case "Admin":
        this.router.navigate(["/admin/dashboard"])
        break
      default:
        // Default to home if user type is unknown
        break
    }
  }
}
