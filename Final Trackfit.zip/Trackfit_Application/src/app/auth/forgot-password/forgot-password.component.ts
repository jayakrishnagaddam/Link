import { Component, type OnInit } from "@angular/core"
import { type FormBuilder, type FormGroup, Validators } from "@angular/forms"
import type { Router } from "@angular/router"
import type { AuthService } from "../../services/auth.service"
import type { NotificationService } from "../../services/notification.service"

@Component({
  selector: "app-forgot-password",
  templateUrl: "./forgot-password.component.html",
  styleUrls: ["./forgot-password.component.css"],
})
export class ForgotPasswordComponent implements OnInit {
  forgotPasswordForm: FormGroup
  loading = false
  submitted = false
  emailSent = false

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private notificationService: NotificationService,
  ) {}

  ngOnInit(): void {
    this.forgotPasswordForm = this.formBuilder.group({
      email: ["", [Validators.required, Validators.email]],
    })
  }

  // Convenience getter for easy access to form fields
  get f() {
    return this.forgotPasswordForm.controls
  }

  onSubmit(): void {
    this.submitted = true

    // Stop here if form is invalid
    if (this.forgotPasswordForm.invalid) {
      return
    }

    this.loading = true
    this.authService.forgotPassword(this.f.email.value).subscribe(
      (success) => {
        this.emailSent = true
        this.loading = false
      },
      (error) => {
        // We still show success message even if there's an error
        // This is for security reasons to prevent email enumeration
        this.emailSent = true
        this.loading = false
      },
    )
  }

  navigateToLogin(): void {
    this.router.navigate(["/login"])
  }
}
