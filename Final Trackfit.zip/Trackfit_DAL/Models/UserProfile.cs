using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json;

namespace Trackfit.DAL.Models
{
    public class UserProfile
    {
        [Key]
        public int ProfileId { get; set; }
        
        [Required]
        public int UserId { get; set; }
        
        public int? Age { get; set; }
        
        [StringLength(20)]
        public string Gender { get; set; }
        
        public decimal? Height { get; set; } // in cm
        
        public decimal? Weight { get; set; } // in kg
        
        [StringLength(20)]
        public string FitnessLevel { get; set; } // 'Beginner', 'Intermediate', 'Advanced'
        
        public string FitnessGoals { get; set; } // JSON array of goals
        
        public decimal? BodyFatPercentage { get; set; }
        
        [StringLength(255)]
        public string ProfilePictureUrl { get; set; }
        
        [Required]
        public DateTime LastUpdated { get; set; }
        
        // Navigation properties
        [ForeignKey("UserId")]
        public virtual User User { get; set; }
        
        // Helper methods for JSON properties
        public string[] GetFitnessGoals()
        {
            if (string.IsNullOrEmpty(FitnessGoals))
                return Array.Empty<string>();
            
            return JsonSerializer.Deserialize<string[]>(FitnessGoals);
        }
        
        public void SetFitnessGoals(string[] goals)
        {
            FitnessGoals = JsonSerializer.Serialize(goals);
        }
    }
}
