import { Component, Input, Output, EventEmitter } from "@angular/core"

@Component({
  selector: "app-file-upload",
  templateUrl: "./file-upload.component.html",
  styleUrls: ["./file-upload.component.css"],
})
export class FileUploadComponent {
  @Input() accept = "image/*"
  @Input() multiple = false
  @Input() maxFileSize = 5 // in MB
  @Input() label = "Choose file"
  @Input() dropzoneText = "or drop files here"
  @Input() buttonText = "Browse"

  @Output() filesSelected = new EventEmitter<File[]>()

  files: File[] = []
  isDragging = false
  errors: string[] = []

  constructor() {}

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement
    if (input.files) {
      this.handleFiles(input.files)
    }
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault()
    event.stopPropagation()
    this.isDragging = true
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault()
    event.stopPropagation()
    this.isDragging = false
  }

  onDrop(event: DragEvent): void {
    event.preventDefault()
    event.stopPropagation()
    this.isDragging = false

    if (event.dataTransfer?.files) {
      this.handleFiles(event.dataTransfer.files)
    }
  }

  private handleFiles(fileList: FileList): void {
    this.errors = []
    const newFiles: File[] = []

    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i]

      // Check file size
      if (file.size > this.maxFileSize * 1024 * 1024) {
        this.errors.push(`File "${file.name}" exceeds the maximum size of ${this.maxFileSize}MB`)
        continue
      }

      // Check file type if accept is specified
      if (this.accept && this.accept !== "*") {
        const fileType = file.type
        const acceptTypes = this.accept.split(",").map((type) => type.trim())

        // Check if file type matches any of the accepted types
        const isAccepted = acceptTypes.some((type) => {
          if (type.endsWith("/*")) {
            // Handle wildcards like 'image/*'
            const baseType = type.split("/")[0]
            return fileType.startsWith(baseType + "/")
          }
          return type === fileType
        })

        if (!isAccepted) {
          this.errors.push(`File "${file.name}" is not an accepted file type`)
          continue
        }
      }

      newFiles.push(file)
    }

    if (this.multiple) {
      this.files = [...this.files, ...newFiles]
    } else {
      this.files = newFiles.slice(0, 1)
    }

    this.filesSelected.emit(this.files)
  }

  removeFile(index: number): void {
    this.files.splice(index, 1)
    this.filesSelected.emit(this.files)
  }

  clearFiles(): void {
    this.files = []
    this.filesSelected.emit(this.files)
  }

  formatFileSize(size: number): string {
    if (size < 1024) {
      return size + " B"
    } else if (size < 1024 * 1024) {
      return (size / 1024).toFixed(1) + " KB"
    } else {
      return (size / (1024 * 1024)).toFixed(1) + " MB"
    }
  }
}
