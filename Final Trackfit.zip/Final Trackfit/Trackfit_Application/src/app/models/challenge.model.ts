export interface Challenge {
  challengeId: number
  challengeName: string
  description?: string
  categoryId: number
  categoryName?: string
  difficultyLevel: string
  startDate: Date
  endDate: Date
  createdBy: number
  creatorName?: string
  isPrivate: boolean
  rules?: string
  rewards?: string
  imageUrl?: string
  createdDate: Date
  isActive: boolean
  participantCount?: number
}

export interface ChallengeParticipant {
  participantId: number
  challengeId: number
  userId: number
  userName?: string
  userProfilePicture?: string
  joinDate: Date
  progress: number
  status: string
  ranking?: number
}

export interface ChallengeLeaderboardEntry {
  userId: number
  userName: string
  userProfilePicture?: string
  progress: number
  ranking: number
}
