export interface NutritionLog {
  nutritionLogId: number
  userId: number
  logDate: Date
  mealType: string
  foodName: string
  calories?: number
  protein?: number
  carbohydrates?: number
  fat?: number
  portion?: number
  portionUnit?: string
  notes?: string
  createdDate: Date
}

export interface NutritionPlan {
  planId: number
  planName: string
  description?: string
  createdBy: number
  creatorName?: string
  dailyCalories?: number
  dailyProtein?: number
  dailyCarbohydrates?: number
  dailyFat?: number
  mealPlanDetails?: any
  createdDate: Date
  isActive: boolean
}

export interface UserNutritionPlan {
  userPlanId: number
  userId: number
  planId: number
  planName?: string
  startDate: Date
  endDate?: Date
  status: string
  assignedBy?: number
  assignerName?: string
  assignedDate: Date
}

export interface NutritionSummary {
  userId: number
  date: Date
  totalCalories: number
  totalProtein: number
  totalCarbohydrates: number
  totalFat: number
  goalCalories?: number
  goalProtein?: number
  goalCarbohydrates?: number
  goalFat?: number
  meals: {
    mealType: string
    calories: number
    protein: number
    carbohydrates: number
    fat: number
  }[]
}

export interface NutritionAnalytics {
  userId: number
  startDate: Date
  endDate: Date
  averageCalories: number
  averageProtein: number
  averageCarbohydrates: number
  averageFat: number
  caloriesTrend: { date: Date; value: number }[]
  proteinTrend: { date: Date; value: number }[]
  carbsTrend: { date: Date; value: number }[]
  fatTrend: { date: Date; value: number }[]
  macroDistribution: {
    protein: number
    carbohydrates: number
    fat: number
  }
}
