import { Injectable } from "@angular/core"
import type { HttpClient } from "@angular/common/http"
import { BehaviorSubject, type Observable, of } from "rxjs"
import { map, catchError } from "rxjs/operators"
import type { Router } from "@angular/router"

import type { User, LoginCredentials, RegisterUser } from "../models/user.model"
import { environment } from "../../environments/environment"

@Injectable({
  providedIn: "root",
})
export class AuthService {
  private apiUrl = `${environment.apiUrl}/auth`
  private currentUserSubject: BehaviorSubject<User | null>
  public currentUser: Observable<User | null>
  private tokenExpirationTimer: any

  constructor(
    private http: HttpClient,
    private router: Router,
  ) {
    const storedUser = localStorage.getItem("currentUser")
    this.currentUserSubject = new BehaviorSubject<User | null>(storedUser ? JSON.parse(storedUser) : null)
    this.currentUser = this.currentUserSubject.asObservable()
  }

  public get currentUserValue(): User | null {
    return this.currentUserSubject.value
  }

  login(credentials: LoginCredentials): Observable<User> {
    return this.http.post<any>(`${this.apiUrl}/login`, credentials).pipe(
      map((response) => {
        // Store user details and token in local storage
        const user = response.user
        const token = response.token
        const expiresIn = response.expiresIn

        this.setAuthData(user, token, expiresIn)
        this.startAuthTimer(expiresIn)

        this.currentUserSubject.next(user)
        return user
      }),
    )
  }

  register(user: RegisterUser): Observable<User> {
    return this.http.post<any>(`${this.apiUrl}/register`, user).pipe(
      map((response) => {
        return response.user
      }),
    )
  }

  logout(): void {
    // Remove user from local storage
    localStorage.removeItem("currentUser")
    localStorage.removeItem("token")
    localStorage.removeItem("tokenExpiration")

    if (this.tokenExpirationTimer) {
      clearTimeout(this.tokenExpirationTimer)
    }
    this.tokenExpirationTimer = null

    this.currentUserSubject.next(null)
    this.router.navigate(["/login"])
  }

  forgotPassword(email: string): Observable<boolean> {
    return this.http.post<any>(`${this.apiUrl}/forgot-password`, { email }).pipe(
      map((response) => {
        return response.success
      }),
      catchError((error) => {
        return of(false)
      }),
    )
  }

  resetPassword(token: string, newPassword: string): Observable<boolean> {
    return this.http.post<any>(`${this.apiUrl}/reset-password`, { token, newPassword }).pipe(
      map((response) => {
        return response.success
      }),
      catchError((error) => {
        return of(false)
      }),
    )
  }

  changePassword(currentPassword: string, newPassword: string): Observable<boolean> {
    return this.http.post<any>(`${this.apiUrl}/change-password`, { currentPassword, newPassword }).pipe(
      map((response) => {
        return response.success
      }),
      catchError((error) => {
        return of(false)
      }),
    )
  }

  isAuthenticated(): boolean {
    const token = localStorage.getItem("token")
    const expirationDate = localStorage.getItem("tokenExpiration")

    if (!token || !expirationDate) {
      return false
    }

    return new Date().getTime() < new Date(expirationDate).getTime()
  }

  autoLogin(): void {
    const userData = localStorage.getItem("currentUser")
    const tokenExpiration = localStorage.getItem("tokenExpiration")

    if (!userData || !tokenExpiration) {
      return
    }

    const user: User = JSON.parse(userData)
    const expirationDate = new Date(tokenExpiration)

    if (expirationDate <= new Date()) {
      this.logout()
      return
    }

    this.currentUserSubject.next(user)
    const expiresIn = expirationDate.getTime() - new Date().getTime()
    this.startAuthTimer(expiresIn)
  }

  hasRole(role: string): boolean {
    const user = this.currentUserValue
    return user != null && user.userType === role
  }

  private setAuthData(user: User, token: string, expiresIn: number): void {
    const expirationDate = new Date(new Date().getTime() + expiresIn * 1000)
    localStorage.setItem("currentUser", JSON.stringify(user))
    localStorage.setItem("token", token)
    localStorage.setItem("tokenExpiration", expirationDate.toISOString())
  }

  private startAuthTimer(expiresIn: number): void {
    this.tokenExpirationTimer = setTimeout(() => {
      this.logout()
    }, expiresIn * 1000)
  }
}
