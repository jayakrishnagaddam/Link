using Microsoft.EntityFrameworkCore;
using Trackfit.DAL.Models;

namespace Trackfit.DAL.Data
{
    public class TrackfitDbContext : DbContext
    {
        public TrackfitDbContext(DbContextOptions<TrackfitDbContext> options)
            : base(options)
        {
        }
        
        public DbSet<User> Users { get; set; }
        public DbSet<UserProfile> UserProfiles { get; set; }
        public DbSet<TrainerProfile> TrainerProfiles { get; set; }
        public DbSet<TrainerCredential> TrainerCredentials { get; set; }
        public DbSet<TrainerClient> TrainerClients { get; set; }
        public DbSet<ExerciseCategory> ExerciseCategories { get; set; }
        public DbSet<Exercise> Exercises { get; set; }
        public DbSet<WorkoutProgram> WorkoutPrograms { get; set; }
        public DbSet<WorkoutProgramExercise> WorkoutProgramExercises { get; set; }
        public DbSet<UserWorkoutSchedule> UserWorkoutSchedules { get; set; }
        public DbSet<UserWorkoutLog> UserWorkoutLogs { get; set; }
        public DbSet<UserExerciseLog> UserExerciseLogs { get; set; }
        public DbSet<TrainerFeedback> TrainerFeedback { get; set; }
        public DbSet<NutritionLog> NutritionLogs { get; set; }
        public DbSet<NutritionPlan> NutritionPlans { get; set; }
        public DbSet<UserNutritionPlan> UserNutritionPlans { get; set; }
        public DbSet<Challenge> Challenges { get; set; }
        public DbSet<ChallengeParticipant> ChallengeParticipants { get; set; }
        public DbSet<UserAchievement> UserAchievements { get; set; }
        public DbSet<Message> Messages { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<Subscription> Subscriptions { get; set; }
        public DbSet<UserSubscription> UserSubscriptions { get; set; }
        public DbSet<SupportTicket> SupportTickets { get; set; }
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            
            // Configure relationships
            modelBuilder.Entity<User>()
                .HasOne(u => u.UserProfile)
                .WithOne(p => p.User)
                .HasForeignKey<UserProfile>(p => p.UserId);
                
            modelBuilder.Entity<User>()
                .HasOne(u => u.TrainerProfile)
                .WithOne(p => p.User)
                .HasForeignKey<TrainerProfile>(p => p.UserId);
                
            modelBuilder.Entity<Message>()
                .HasOne(m => m.Sender)
                .WithMany(u => u.SentMessages)
                .HasForeignKey(m => m.SenderId)
                .OnDelete(DeleteBehavior.Restrict);
                
            modelBuilder.Entity<Message>()
                .HasOne(m => m.Receiver)
                .WithMany(u => u.ReceivedMessages)
                .HasForeignKey(m => m.ReceiverId)
                .OnDelete(DeleteBehavior.Restrict);
                
            modelBuilder.Entity<TrainerClient>()
                .HasIndex(tc => new { tc.TrainerProfileId, tc.ClientId })
                .IsUnique();
                
            modelBuilder.Entity<ChallengeParticipant>()
                .HasIndex(cp => new { cp.ChallengeId, cp.UserId })
                .IsUnique();
                
            // Configure table names
            modelBuilder.Entity<User>().ToTable("Users");
            modelBuilder.Entity<UserProfile>().ToTable("UserProfiles");
            modelBuilder.Entity<TrainerProfile>().ToTable("TrainerProfiles");
            modelBuilder.Entity<TrainerCredential>().ToTable("TrainerCredentials");
            modelBuilder.Entity<TrainerClient>().ToTable("TrainerClients");
            modelBuilder.Entity<ExerciseCategory>().ToTable("ExerciseCategories");
            modelBuilder.Entity<Exercise>().ToTable("Exercises");
            modelBuilder.Entity<WorkoutProgram>().ToTable("WorkoutPrograms");
            modelBuilder.Entity<WorkoutProgramExercise>().ToTable("WorkoutProgramExercises");
            modelBuilder.Entity<UserWorkoutSchedule>().ToTable("UserWorkoutSchedules");
            modelBuilder.Entity<UserWorkoutLog>().ToTable("UserWorkoutLogs");
            modelBuilder.Entity<UserExerciseLog>().ToTable("UserExerciseLogs");
            modelBuilder.Entity<TrainerFeedback>().ToTable("TrainerFeedback");
            modelBuilder.Entity<NutritionLog>().ToTable("NutritionLogs");
            modelBuilder.Entity<NutritionPlan>().ToTable("NutritionPlans");
            modelBuilder.Entity<UserNutritionPlan>().ToTable("UserNutritionPlans");
            modelBuilder.Entity<Challenge>().ToTable("Challenges");
            modelBuilder.Entity<ChallengeParticipant>().ToTable("ChallengeParticipants");
            modelBuilder.Entity<UserAchievement>().ToTable("UserAchievements");
            modelBuilder.Entity<Message>().ToTable("Messages");
            modelBuilder.Entity<Notification>().ToTable("Notifications");
            modelBuilder.Entity<Subscription>().ToTable("Subscriptions");
            modelBuilder.Entity<UserSubscription>().ToTable("UserSubscriptions");
            modelBuilder.Entity<SupportTicket>().ToTable("SupportTickets");
        }
    }
}
