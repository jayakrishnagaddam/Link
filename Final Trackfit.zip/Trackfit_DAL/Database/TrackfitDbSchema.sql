-- TrackFit Database Schema

-- Create Database
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'TrackfitDB')
BEGIN
    CREATE DATABASE TrackfitDB;
END
GO

USE TrackfitDB;
GO

-- Users Table (Base table for all user types)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Users')
BEGIN
    CREATE TABLE Users (
        UserId INT IDENTITY(1,1) PRIMARY KEY,
        Email NVARCHAR(100) NOT NULL UNIQUE,
        PasswordHash NVARCHAR(255) NOT NULL,
        FirstName NVARCHAR(50) NOT NULL,
        LastName NVARCHAR(50) NOT NULL,
        UserType NVARCHAR(20) NOT NULL, -- 'User', 'Trainer', 'Admin'
        CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
        LastLoginDate DATETIME NULL,
        IsActive BIT NOT NULL DEFAULT 1
    );
END
GO

-- UserProfiles Table (Detailed information for regular users)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'UserProfiles')
BEGIN
    CREATE TABLE UserProfiles (
        ProfileId INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL UNIQUE FOREIGN KEY REFERENCES Users(UserId),
        Age INT NULL,
        Gender NVARCHAR(20) NULL,
        Height DECIMAL(5,2) NULL, -- in cm
        Weight DECIMAL(5,2) NULL, -- in kg
        FitnessLevel NVARCHAR(20) NULL, -- 'Beginner', 'Intermediate', 'Advanced'
        FitnessGoals NVARCHAR(MAX) NULL, -- JSON array of goals
        BodyFatPercentage DECIMAL(5,2) NULL,
        ProfilePictureUrl NVARCHAR(255) NULL,
        LastUpdated DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- TrainerProfiles Table (Detailed information for trainers)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TrainerProfiles')
BEGIN
    CREATE TABLE TrainerProfiles (
        TrainerProfileId INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL UNIQUE FOREIGN KEY REFERENCES Users(UserId),
        Specialization NVARCHAR(MAX) NULL, -- JSON array of specializations
        Experience INT NULL, -- Years of experience
        Biography NVARCHAR(MAX) NULL,
        HourlyRate DECIMAL(10,2) NULL,
        IsVerified BIT NOT NULL DEFAULT 0,
        Rating DECIMAL(3,2) NULL,
        ProfilePictureUrl NVARCHAR(255) NULL,
        LastUpdated DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- TrainerCredentials Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TrainerCredentials')
BEGIN
    CREATE TABLE TrainerCredentials (
        CredentialId INT IDENTITY(1,1) PRIMARY KEY,
        TrainerProfileId INT NOT NULL FOREIGN KEY REFERENCES TrainerProfiles(TrainerProfileId),
        CredentialName NVARCHAR(100) NOT NULL,
        IssuingOrganization NVARCHAR(100) NOT NULL,
        IssueDate DATE NOT NULL,
        ExpiryDate DATE NULL,
        VerificationDocumentUrl NVARCHAR(255) NULL,
        IsVerified BIT NOT NULL DEFAULT 0,
        VerifiedBy INT NULL FOREIGN KEY REFERENCES Users(UserId),
        VerificationDate DATETIME NULL
    );
END
GO

-- TrainerClients Table (Relationship between trainers and clients)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TrainerClients')
BEGIN
    CREATE TABLE TrainerClients (
        TrainerClientId INT IDENTITY(1,1) PRIMARY KEY,
        TrainerProfileId INT NOT NULL FOREIGN KEY REFERENCES TrainerProfiles(TrainerProfileId),
        ClientId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
        StartDate DATETIME NOT NULL DEFAULT GETDATE(),
        EndDate DATETIME NULL,
        Status NVARCHAR(20) NOT NULL DEFAULT 'Active', -- 'Active', 'Pending', 'Completed'
        CONSTRAINT UQ_TrainerClient UNIQUE (TrainerProfileId, ClientId)
    );
END
GO

-- ExerciseCategories Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ExerciseCategories')
BEGIN
    CREATE TABLE ExerciseCategories (
        CategoryId INT IDENTITY(1,1) PRIMARY KEY,
        CategoryName NVARCHAR(50) NOT NULL UNIQUE,
        Description NVARCHAR(255) NULL
    );
END
GO

-- Exercises Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Exercises')
BEGIN
    CREATE TABLE Exercises (
        ExerciseId INT IDENTITY(1,1) PRIMARY KEY,
        ExerciseName NVARCHAR(100) NOT NULL,
        Description NVARCHAR(MAX) NULL,
        CategoryId INT NOT NULL FOREIGN KEY REFERENCES ExerciseCategories(CategoryId),
        DifficultyLevel NVARCHAR(20) NOT NULL, -- 'Beginner', 'Intermediate', 'Advanced'
        Instructions NVARCHAR(MAX) NULL,
        VideoUrl NVARCHAR(255) NULL,
        ImageUrl NVARCHAR(255) NULL,
        EquipmentRequired NVARCHAR(MAX) NULL, -- JSON array of equipment
        CreatedBy INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
        CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
        IsActive BIT NOT NULL DEFAULT 1
    );
END
GO

-- WorkoutPrograms Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'WorkoutPrograms')
BEGIN
    CREATE TABLE WorkoutPrograms (
        ProgramId INT IDENTITY(1,1) PRIMARY KEY,
        ProgramName NVARCHAR(100) NOT NULL,
        Description NVARCHAR(MAX) NULL,
        DifficultyLevel NVARCHAR(20) NOT NULL, -- 'Beginner', 'Intermediate', 'Advanced'
        CategoryId INT NOT NULL FOREIGN KEY REFERENCES ExerciseCategories(CategoryId),
        Duration INT NOT NULL, -- in minutes
        EquipmentRequired NVARCHAR(MAX) NULL, -- JSON array of equipment
        ImageUrl NVARCHAR(255) NULL,
        CreatedBy INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
        CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
        IsPublic BIT NOT NULL DEFAULT 1,
        IsActive BIT NOT NULL DEFAULT 1
    );
END
GO

-- WorkoutProgramExercises Table (Junction table for programs and exercises)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'WorkoutProgramExercises')
BEGIN
    CREATE TABLE WorkoutProgramExercises (
        ProgramExerciseId INT IDENTITY(1,1) PRIMARY KEY,
        ProgramId INT NOT NULL FOREIGN KEY REFERENCES WorkoutPrograms(ProgramId),
        ExerciseId INT NOT NULL FOREIGN KEY REFERENCES Exercises(ExerciseId),
        Sets INT NOT NULL,
        Reps INT NOT NULL,
        RestPeriod INT NOT NULL, -- in seconds
        OrderIndex INT NOT NULL,
        Notes NVARCHAR(MAX) NULL
    );
END
GO

-- UserWorkoutSchedules Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'UserWorkoutSchedules')
BEGIN
    CREATE TABLE UserWorkoutSchedules (
        ScheduleId INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
        ProgramId INT NOT NULL FOREIGN KEY REFERENCES WorkoutPrograms(ProgramId),
        ScheduledDate DATETIME NOT NULL,
        IsRecurring BIT NOT NULL DEFAULT 0,
        RecurrencePattern NVARCHAR(50) NULL, -- 'Daily', 'Weekly', 'Custom'
        RecurrenceDetails NVARCHAR(MAX) NULL, -- JSON with recurrence details
        ReminderTime INT NULL, -- minutes before workout
        ReminderType NVARCHAR(20) NULL, -- 'Push', 'Email', 'SMS'
        Status NVARCHAR(20) NOT NULL DEFAULT 'Scheduled', -- 'Scheduled', 'Completed', 'Missed', 'Cancelled'
        CreatedDate DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- UserWorkoutLogs Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'UserWorkoutLogs')
BEGIN
    CREATE TABLE UserWorkoutLogs (
        LogId INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
        ProgramId INT NOT NULL FOREIGN KEY REFERENCES WorkoutPrograms(ProgramId),
        ScheduleId INT NULL FOREIGN KEY REFERENCES UserWorkoutSchedules(ScheduleId),
        StartTime DATETIME NOT NULL,
        EndTime DATETIME NULL,
        Notes NVARCHAR(MAX) NULL,
        Rating INT NULL, -- User rating of workout (1-5)
        CreatedDate DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- UserExerciseLogs Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'UserExerciseLogs')
BEGIN
    CREATE TABLE UserExerciseLogs (
        ExerciseLogId INT IDENTITY(1,1) PRIMARY KEY,
        LogId INT NOT NULL FOREIGN KEY REFERENCES UserWorkoutLogs(LogId),
        ExerciseId INT NOT NULL FOREIGN KEY REFERENCES Exercises(ExerciseId),
        Sets INT NOT NULL,
        Reps INT NOT NULL,
        Weight DECIMAL(7,2) NULL, -- in kg
        Duration INT NULL, -- in seconds
        Notes NVARCHAR(MAX) NULL,
        FormVideoUrl NVARCHAR(255) NULL
    );
END
GO

-- TrainerFeedback Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TrainerFeedback')
BEGIN
    CREATE TABLE TrainerFeedback (
        FeedbackId INT IDENTITY(1,1) PRIMARY KEY,
        ExerciseLogId INT NOT NULL FOREIGN KEY REFERENCES UserExerciseLogs(ExerciseLogId),
        TrainerProfileId INT NOT NULL FOREIGN KEY REFERENCES TrainerProfiles(TrainerProfileId),
        FeedbackText NVARCHAR(MAX) NOT NULL,
        AnnotatedVideoUrl NVARCHAR(255) NULL,
        VoiceFeedbackUrl NVARCHAR(255) NULL,
        CreatedDate DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- NutritionLogs Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'NutritionLogs')
BEGIN
    CREATE TABLE NutritionLogs (
        NutritionLogId INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
        LogDate DATE NOT NULL,
        MealType NVARCHAR(50) NOT NULL, -- 'Breakfast', 'Lunch', 'Dinner', 'Snack'
        FoodName NVARCHAR(100) NOT NULL,
        Calories INT NULL,
        Protein DECIMAL(7,2) NULL, -- in grams
        Carbohydrates DECIMAL(7,2) NULL, -- in grams
        Fat DECIMAL(7,2) NULL, -- in grams
        Portion DECIMAL(7,2) NULL,
        PortionUnit NVARCHAR(20) NULL, -- 'g', 'oz', 'serving'
        Notes NVARCHAR(MAX) NULL,
        CreatedDate DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- NutritionPlans Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'NutritionPlans')
BEGIN
    CREATE TABLE NutritionPlans (
        PlanId INT IDENTITY(1,1) PRIMARY KEY,
        PlanName NVARCHAR(100) NOT NULL,
        Description NVARCHAR(MAX) NULL,
        CreatedBy INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
        DailyCalories INT NULL,
        DailyProtein DECIMAL(7,2) NULL, -- in grams
        DailyCarbohydrates DECIMAL(7,2) NULL, -- in grams
        DailyFat DECIMAL(7,2) NULL, -- in grams
        MealPlanDetails NVARCHAR(MAX) NULL, -- JSON with meal plan details
        CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
        IsActive BIT NOT NULL DEFAULT 1
    );
END
GO

-- UserNutritionPlans Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'UserNutritionPlans')
BEGIN
    CREATE TABLE UserNutritionPlans (
        UserPlanId INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
        PlanId INT NOT NULL FOREIGN KEY REFERENCES NutritionPlans(PlanId),
        StartDate DATE NOT NULL,
        EndDate DATE NULL,
        Status NVARCHAR(20) NOT NULL DEFAULT 'Active', -- 'Active', 'Completed', 'Cancelled'
        AssignedBy INT NULL FOREIGN KEY REFERENCES Users(UserId),
        AssignedDate DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

-- Challenges Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Challenges')
BEGIN
    CREATE TABLE Challenges (
        ChallengeId INT IDENTITY(1,1) PRIMARY KEY,
        ChallengeName NVARCHAR(100) NOT NULL,
        Description NVARCHAR(MAX) NULL,
        CategoryId INT NOT NULL FOREIGN KEY REFERENCES ExerciseCategories(CategoryId),
        DifficultyLevel NVARCHAR(20) NOT NULL, -- 'Beginner', 'Intermediate', 'Advanced'
        StartDate DATETIME NOT NULL,
        EndDate DATETIME NOT NULL,
        CreatedBy INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
        IsPrivate BIT NOT NULL DEFAULT 0,
        Rules NVARCHAR(MAX) NULL,
        Rewards NVARCHAR(MAX) NULL,
        ImageUrl NVARCHAR(255) NULL,
        CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
        IsActive BIT NOT NULL DEFAULT 1
    );
END
GO

-- ChallengeParticipants Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ChallengeParticipants')
BEGIN
    CREATE TABLE ChallengeParticipants (
        ParticipantId INT IDENTITY(1,1) PRIMARY KEY,
        ChallengeId INT NOT NULL FOREIGN KEY REFERENCES Challenges(ChallengeId),
        UserId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
        JoinDate DATETIME NOT NULL DEFAULT GETDATE(),
        Progress DECIMAL(5,2) NOT NULL DEFAULT 0, -- percentage
        Status NVARCHAR(20) NOT NULL DEFAULT 'Active', -- 'Active', 'Completed', 'Dropped'
        Ranking INT NULL,
        CONSTRAINT UQ_ChallengeParticipant UNIQUE (ChallengeId, UserId)
    );
END
GO

-- UserAchievements Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'UserAchievements')
BEGIN
    CREATE TABLE UserAchievements (
        AchievementId INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
        AchievementType NVARCHAR(50) NOT NULL, -- 'Challenge', 'Workout', 'Streak', etc.
        AchievementName NVARCHAR(100) NOT NULL,
        Description NVARCHAR(MAX) NULL,
        AwardedDate DATETIME NOT NULL DEFAULT GETDATE(),
        BadgeUrl NVARCHAR(255) NULL
    );
END
GO

-- Messages Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Messages')
BEGIN
    CREATE TABLE Messages (
        MessageId INT IDENTITY(1,1) PRIMARY KEY,
        SenderId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
        ReceiverId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
        MessageText NVARCHAR(MAX) NOT NULL,
        AttachmentUrl NVARCHAR(255) NULL,
        AttachmentType NVARCHAR(50) NULL, -- 'Image', 'Video', 'Document'
        SentDate DATETIME NOT NULL DEFAULT GETDATE(),
        ReadDate DATETIME NULL,
        IsDeleted BIT NOT NULL DEFAULT 0
    );
END
GO

-- Notifications Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Notifications')
BEGIN
    CREATE TABLE Notifications (
        NotificationId INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
        NotificationType NVARCHAR(50) NOT NULL, -- 'Workout', 'Challenge', 'Message', etc.
        Title NVARCHAR(100) NOT NULL,
        Message NVARCHAR(MAX) NOT NULL,
        RelatedEntityId INT NULL, -- ID of related entity (workout, challenge, etc.)
        RelatedEntityType NVARCHAR(50) NULL, -- Type of related entity
        CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
        IsRead BIT NOT NULL DEFAULT 0,
        IsDeleted BIT NOT NULL DEFAULT 0
    );
END
GO

-- Subscriptions Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Subscriptions')
BEGIN
    CREATE TABLE Subscriptions (
        SubscriptionId INT IDENTITY(1,1) PRIMARY KEY,
        SubscriptionName NVARCHAR(50) NOT NULL,
        Description NVARCHAR(MAX) NULL,
        Price DECIMAL(10,2) NOT NULL,
        Duration INT NOT NULL, -- in days
        Features NVARCHAR(MAX) NULL, -- JSON array of features
        IsActive BIT NOT NULL DEFAULT 1
    );
END
GO

-- UserSubscriptions Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'UserSubscriptions')
BEGIN
    CREATE TABLE UserSubscriptions (
        UserSubscriptionId INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
        SubscriptionId INT NOT NULL FOREIGN KEY REFERENCES Subscriptions(SubscriptionId),
        StartDate DATETIME NOT NULL DEFAULT GETDATE(),
        EndDate DATETIME NOT NULL,
        PaymentStatus NVARCHAR(20) NOT NULL, -- 'Paid', 'Pending', 'Failed'
        PaymentReference NVARCHAR(100) NULL,
        IsActive BIT NOT NULL DEFAULT 1,
        CancellationDate DATETIME NULL,
        CancellationReason NVARCHAR(MAX) NULL
    );
END
GO

-- SupportTickets Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'SupportTickets')
BEGIN
    CREATE TABLE SupportTickets (
        TicketId INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL FOREIGN KEY REFERENCES Users(UserId),
        Subject NVARCHAR(100) NOT NULL,
        Description NVARCHAR(MAX) NOT NULL,
        Category NVARCHAR(50) NOT NULL, -- 'Technical', 'Billing', 'Account', etc.
        Priority NVARCHAR(20) NOT NULL DEFAULT 'Medium', -- 'Low', 'Medium', 'High'
        Status NVARCHAR(20) NOT NULL DEFAULT 'Open', -- 'Open', 'In Progress', 'Resolved', 'Closed'
        AssignedTo INT NULL FOREIGN KEY REFERENCES Users(UserId),
        CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
        ResolvedDate DATETIME NULL,
        Resolution NVARCHAR(MAX) NULL
    );
END
GO

-- Initial Data Insertion
-- Insert Exercise Categories
IF NOT EXISTS (SELECT * FROM ExerciseCategories)
BEGIN
    INSERT INTO ExerciseCategories (CategoryName, Description)
    VALUES 
        ('Strength', 'Exercises focused on building muscle strength'),
        ('Cardio', 'Exercises focused on cardiovascular endurance'),
        ('Flexibility', 'Exercises focused on improving flexibility and mobility'),
        ('Balance', 'Exercises focused on improving balance and stability'),
        ('HIIT', 'High-Intensity Interval Training exercises');
END
GO

-- Insert Admin User
IF NOT EXISTS (SELECT * FROM Users WHERE Email = 'admin@trackfit.com')
BEGIN
    INSERT INTO Users (Email, PasswordHash, FirstName, LastName, UserType, CreatedDate, IsActive)
    VALUES ('admin@trackfit.com', 'AQAAAAEAACcQAAAAEHxQPHsMfJmkIjQj+NvRRfSGHzoRpPKJBbKQnG/gJsHAI7pHp9GEK9xnVl3yQqQnrA==', 'Admin', 'User', 'Admin', GETDATE(), 1);
END
GO

-- Create Views
-- View for User Workout Progress
IF NOT EXISTS (SELECT * FROM sys.views WHERE name = 'vw_UserWorkoutProgress')
BEGIN
    EXEC('
    CREATE VIEW vw_UserWorkoutProgress AS
    SELECT 
        u.UserId,
        u.FirstName + '' '' + u.LastName AS UserName,
        COUNT(DISTINCT uwl.LogId) AS TotalWorkouts,
        SUM(DATEDIFF(MINUTE, uwl.StartTime, uwl.EndTime)) AS TotalMinutesWorkedOut,
        AVG(uwl.Rating) AS AverageWorkoutRating,
        MAX(uwl.StartTime) AS LastWorkoutDate
    FROM 
        Users u
        LEFT JOIN UserWorkoutLogs uwl ON u.UserId = uwl.UserId
    WHERE 
        u.UserType = ''User''
    GROUP BY 
        u.UserId, u.FirstName, u.LastName
    ');
END
GO

-- View for Trainer Client List
IF NOT EXISTS (SELECT * FROM sys.views WHERE name = 'vw_TrainerClients')
BEGIN
    EXEC('
    CREATE VIEW vw_TrainerClients AS
    SELECT 
        t.UserId AS TrainerId,
        t.FirstName + '' '' + t.LastName AS TrainerName,
        tp.TrainerProfileId,
        c.UserId AS ClientId,
        c.FirstName + '' '' + c.LastName AS ClientName,
        tc.StartDate,
        tc.Status
    FROM 
        Users t
        JOIN TrainerProfiles tp ON t.UserId = tp.UserId
        JOIN TrainerClients tc ON tp.TrainerProfileId = tc.TrainerProfileId
        JOIN Users c ON tc.ClientId = c.UserId
    WHERE 
        t.UserType = ''Trainer''
    ');
END
GO

-- View for Popular Workout Programs
IF NOT EXISTS (SELECT * FROM sys.views WHERE name = 'vw_PopularWorkoutPrograms')
BEGIN
    EXEC('
    CREATE VIEW vw_PopularWorkoutPrograms AS
    SELECT 
        wp.ProgramId,
        wp.ProgramName,
        wp.Description,
        wp.DifficultyLevel,
        ec.CategoryName,
        COUNT(DISTINCT uwl.LogId) AS TimesCompleted,
        AVG(uwl.Rating) AS AverageRating
    FROM 
        WorkoutPrograms wp
        JOIN ExerciseCategories ec ON wp.CategoryId = ec.CategoryId
        LEFT JOIN UserWorkoutLogs uwl ON wp.ProgramId = uwl.ProgramId
    WHERE 
        wp.IsActive = 1
        AND wp.IsPublic = 1
    GROUP BY 
        wp.ProgramId, wp.ProgramName, wp.Description, wp.DifficultyLevel, ec.CategoryName
    ');
END
GO

-- Create Stored Procedures
-- Procedure to Get User Progress Report
IF NOT EXISTS (SELECT * FROM sys.procedures WHERE name = 'sp_GetUserProgressReport')
BEGIN
    EXEC('
    CREATE PROCEDURE sp_GetUserProgressReport
        @UserId INT,
        @StartDate DATE,
        @EndDate DATE
    AS
    BEGIN
        -- Workout Summary
        SELECT 
            COUNT(DISTINCT LogId) AS TotalWorkouts,
            SUM(DATEDIFF(MINUTE, StartTime, EndTime)) AS TotalMinutesWorkedOut,
            AVG(Rating) AS AverageWorkoutRating
        FROM 
            UserWorkoutLogs
        WHERE 
            UserId = @UserId
            AND CAST(StartTime AS DATE) BETWEEN @StartDate AND @EndDate;
        
        -- Exercise Progress
        SELECT 
            e.ExerciseName,
            MAX(uel.Weight) AS MaxWeight,
            AVG(uel.Weight) AS AverageWeight,
            MAX(uel.Reps) AS MaxReps
        FROM 
            UserExerciseLogs uel
            JOIN UserWorkoutLogs uwl ON uel.LogId = uwl.LogId
            JOIN Exercises e ON uel.ExerciseId = e.ExerciseId
        WHERE 
            uwl.UserId = @UserId
            AND CAST(uwl.StartTime AS DATE) BETWEEN @StartDate AND @EndDate
        GROUP BY 
            e.ExerciseName;
        
        -- Nutrition Summary
        SELECT 
            AVG(Calories) AS AverageCalories,
            AVG(Protein) AS AverageProtein,
            AVG(Carbohydrates) AS AverageCarbs,
            AVG(Fat) AS AverageFat
        FROM 
            (
                SELECT 
                    LogDate,
                    SUM(Calories) AS Calories,
                    SUM(Protein) AS Protein,
                    SUM(Carbohydrates) AS Carbohydrates,
                    SUM(Fat) AS Fat
                FROM 
                    NutritionLogs
                WHERE 
                    UserId = @UserId
                    AND LogDate BETWEEN @StartDate AND @EndDate
                GROUP BY 
                    LogDate
            ) AS DailyNutrition;
    END
    ');
END
GO

-- Procedure to Assign Workout Program to User
IF NOT EXISTS (SELECT * FROM sys.procedures WHERE name = 'sp_AssignWorkoutProgramToUser')
BEGIN
    EXEC('
    CREATE PROCEDURE sp_AssignWorkoutProgramToUser
        @UserId INT,
        @ProgramId INT,
        @ScheduledDate DATETIME,
        @IsRecurring BIT,
        @RecurrencePattern NVARCHAR(50) = NULL,
        @RecurrenceDetails NVARCHAR(MAX) = NULL,
        @ReminderTime INT = NULL,
        @ReminderType NVARCHAR(20) = NULL,
        @AssignedBy INT
    AS
    BEGIN
        -- Insert into UserWorkoutSchedules
        INSERT INTO UserWorkoutSchedules (
            UserId, 
            ProgramId, 
            ScheduledDate, 
            IsRecurring, 
            RecurrencePattern, 
            RecurrenceDetails, 
            ReminderTime, 
            ReminderType, 
            Status, 
            CreatedDate
        )
        VALUES (
            @UserId, 
            @ProgramId, 
            @ScheduledDate, 
            @IsRecurring, 
            @RecurrencePattern, 
            @RecurrenceDetails, 
            @ReminderTime, 
            @ReminderType, 
            ''Scheduled'', 
            GETDATE()
        );
        
        -- Create notification for user
        INSERT INTO Notifications (
            UserId,
            NotificationType,
            Title,
            Message,
            RelatedEntityId,
            RelatedEntityType,
            CreatedDate,
            IsRead
        )
        VALUES (
            @UserId,
            ''Workout'',
            ''New Workout Scheduled'',
            (SELECT ''You have been assigned the workout program: '' + ProgramName FROM WorkoutPrograms WHERE ProgramId = @ProgramId),
            @ProgramId,
            ''WorkoutProgram'',
            GETDATE(),
            0
        );
        
        -- Return the created schedule ID
        SELECT SCOPE_IDENTITY() AS ScheduleId;
    END
    ');
END
GO

-- Procedure to Log User Workout
IF NOT EXISTS (SELECT * FROM sys.procedures WHERE name = 'sp_LogUserWorkout')
BEGIN
    EXEC('
    CREATE PROCEDURE sp_LogUserWorkout
        @UserId INT,
        @ProgramId INT,
        @ScheduleId INT = NULL,
        @StartTime DATETIME,
        @EndTime DATETIME,
        @Notes NVARCHAR(MAX) = NULL,
        @Rating INT = NULL,
        @ExerciseLogs ExerciseLogType READONLY
    AS
    BEGIN
        -- Create a user-defined table type for exercise logs
        -- CREATE TYPE ExerciseLogType AS TABLE (
        --     ExerciseId INT,
        --     Sets INT,
        --     Reps INT,
        --     Weight DECIMAL(7,2) NULL,
        --     Duration INT NULL,
        --     Notes NVARCHAR(MAX) NULL,
        --     FormVideoUrl NVARCHAR(255) NULL
        -- );
        
        DECLARE @LogId INT;
        
        -- Insert workout log
        INSERT INTO UserWorkoutLogs (
            UserId,
            ProgramId,
            ScheduleId,
            StartTime,
            EndTime,
            Notes,
            Rating,
            CreatedDate
        )
        VALUES (
            @UserId,
            @ProgramId,
            @ScheduleId,
            @StartTime,
            @EndTime,
            @Notes,
            @Rating,
            GETDATE()
        );
        
        SET @LogId = SCOPE_IDENTITY();
        
        -- Insert exercise logs
        INSERT INTO UserExerciseLogs (
            LogId,
            ExerciseId,
            Sets,
            Reps,
            Weight,
            Duration,
            Notes,
            FormVideoUrl
        )
        SELECT 
            @LogId,
            ExerciseId,
            Sets,
            Reps,
            Weight,
            Duration,
            Notes,
            FormVideoUrl
        FROM 
            @ExerciseLogs;
        
        -- Update schedule status if applicable
        IF @ScheduleId IS NOT NULL
        BEGIN
            UPDATE UserWorkoutSchedules
            SET Status = ''Completed''
            WHERE ScheduleId = @ScheduleId;
        END
        
        -- Return the created log ID
        SELECT @LogId AS LogId;
    END
    ');
END
GO

-- Create Triggers
-- Trigger to Update User Profile Last Updated Date
IF NOT EXISTS (SELECT * FROM sys.triggers WHERE name = 'trg_UpdateUserProfileLastUpdated')
BEGIN
    EXEC('
    CREATE TRIGGER trg_UpdateUserProfileLastUpdated
    ON UserProfiles
    AFTER UPDATE
    AS
    BEGIN
        UPDATE UserProfiles
        SET LastUpdated = GETDATE()
        FROM UserProfiles up
        INNER JOIN inserted i ON up.ProfileId = i.ProfileId;
    END
    ');
END
GO

-- Trigger to Create Notification on New Message
IF NOT EXISTS (SELECT * FROM sys.triggers WHERE name = 'trg_CreateMessageNotification')
BEGIN
    EXEC('
    CREATE TRIGGER trg_CreateMessageNotification
    ON Messages
    AFTER INSERT
    AS
    BEGIN
        INSERT INTO Notifications (
            UserId,
            NotificationType,
            Title,
            Message,
            RelatedEntityId,
            RelatedEntityType,
            CreatedDate,
            IsRead
        )
        SELECT 
            i.ReceiverId,
            ''Message'',
            ''New Message'',
            ''You have received a new message from '' + u.FirstName + '' '' + u.LastName,
            i.MessageId,
            ''Message'',
            GETDATE(),
            0
        FROM 
            inserted i
            JOIN Users u ON i.SenderId = u.UserId;
    END
    ');
END
GO

-- Trigger to Update Challenge Progress
IF NOT EXISTS (SELECT * FROM sys.triggers WHERE name = 'trg_UpdateChallengeProgress')
BEGIN
    EXEC('
    CREATE TRIGGER trg_UpdateChallengeProgress
    ON UserWorkoutLogs
    AFTER INSERT
    AS
    BEGIN
        -- Update challenge progress for active challenges
        UPDATE cp
        SET Progress = Progress + 10 -- Simplified example, actual logic would be more complex
        FROM ChallengeParticipants cp
        JOIN inserted i ON cp.UserId = i.UserId
        JOIN Challenges c ON cp.ChallengeId = c.ChallengeId
        WHERE 
            cp.Status = ''Active''
            AND c.StartDate <= i.StartTime
            AND c.EndDate >= i.StartTime;
        
        -- Check for completed challenges
        UPDATE cp
        SET Status = ''Completed''
        FROM ChallengeParticipants cp
        WHERE Progress >= 100;
        
        -- Create achievements for completed challenges
        INSERT INTO UserAchievements (
            UserId,
            AchievementType,
            AchievementName,
            Description,
            AwardedDate,
            BadgeUrl
        )
        SELECT 
            cp.UserId,
            ''Challenge'',
            ''Completed Challenge: '' + c.ChallengeName,
            ''Successfully completed the challenge: '' + c.ChallengeName,
            GETDATE(),
            ''/badges/challenge-complete.png''
        FROM 
            ChallengeParticipants cp
            JOIN Challenges c ON cp.ChallengeId = c.ChallengeId
        WHERE 
            cp.Status = ''Completed''
            AND cp.Progress >= 100
            AND NOT EXISTS (
                SELECT 1 
                FROM UserAchievements ua 
                WHERE ua.UserId = cp.UserId 
                AND ua.AchievementName = ''Completed Challenge: '' + c.ChallengeName
            );
    END
    ');
END
GO

PRINT 'TrackFit database schema created successfully.';
