import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

interface Exercise {
  id: number;
  name: string;
  description?: string;
  muscleGroups?: string[];
  equipment?: string[];
  difficulty?: string;
  instructions?: string[];
  videoUrl?: string;
  imageUrl?: string;
}

@Component({
  selector: 'app-exercise',
  templateUrl: './exercise.component.html',
  styleUrls: ['./exercise.component.css']
})
export class ExerciseComponent implements OnInit {
  @Input() exercise: Exercise | null = null;
  @Input() showControls = false;
  @Input() inProgress = false;
  @Input() currentSet = 0;
  @Input() totalSets = 0;
  @Input() timerValue = 0;
  
  @Output() startExercise = new EventEmitter<number>();
  @Output() completeSet = new EventEmitter<void>();
  @Output() skipExercise = new EventEmitter<void>();
  
  activeInstructionStep = 0;
  
  // For demo purposes only - would normally come from a service
  sampleExercise: Exercise = {
    id: 1,
    name: 'Push-up',
    description: 'A classic bodyweight exercise that targets the chest, shoulders, and triceps.',
    muscleGroups: ['Chest', 'Shoulders', 'Triceps', 'Core'],
    equipment: ['None'],
    difficulty: 'Beginner',
    instructions: [
      'Start in a plank position with hands slightly wider than shoulder-width apart.',
      'Keep your body in a straight line from head to heels.',
      'Lower your body until your chest nearly touches the floor.',
      'Pause, then push yourself back to the starting position.',
      'Keep your core engaged throughout the movement.'
    ],
    videoUrl: 'https://example.com/push-up-video.mp4',
    imageUrl: '/assets/exercises/pushup.jpg'
  };

  constructor() { }

  ngOnInit(): void {
    if (!this.exercise) {
      this.exercise = this.sampleExercise;
    }
  }
  
  onStart(): void {
    this.startExercise.emit(this.exercise?.id);
  }
  
  onCompleteSet(): void {
    this.completeSet.emit();
  }
  
  onSkip(): void {
    this.skipExercise.emit();
  }
  
  nextInstructionStep(): void {
    if (this.exercise?.instructions && this.activeInstructionStep < this.exercise.instructions.length - 1) {
      this.activeInstructionStep++;
    }
  }
  
  prevInstructionStep(): void {
    if (this.activeInstructionStep > 0) {
      this.activeInstructionStep--;
    }
  }
  
  formatTime(seconds: number): string {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }
}