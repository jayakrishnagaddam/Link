import { Component, type OnInit } from "@angular/core"
import { type FormBuilder, type FormGroup, Validators } from "@angular/forms"
import type { AuthService } from "../../services/auth.service"
import type { UserService } from "../../services/user.service"
import type { NotificationService } from "../../services/notification.service"
import type { User, UserProfile } from "../../models/user.model"

@Component({
  selector: "app-user-profile",
  templateUrl: "./user-profile.component.html",
  styleUrls: ["./user-profile.component.css"],
})
export class UserProfileComponent implements OnInit {
  currentUser: User | null = null
  userProfile: UserProfile | null = null
  profileForm: FormGroup

  loading = {
    profile: true,
    update: false,
    image: false,
  }

  error = {
    profile: "",
    update: "",
    image: "",
  }

  fitnessLevels = ["Beginner", "Intermediate", "Advanced"]
  fitnessGoals = [
    "Weight Loss",
    "Muscle Gain",
    "Strength Training",
    "Endurance",
    "Flexibility",
    "General Fitness",
    "Athletic Performance",
  ]

  selectedImage: File | null = null
  imagePreview: string | null = null

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private userService: UserService,
    private notificationService: NotificationService,
  ) {
    this.profileForm = this.formBuilder.group({
      firstName: ["", Validators.required],
      lastName: ["", Validators.required],
      age: [null, [Validators.min(13), Validators.max(100)]],
      gender: [""],
      height: [null, [Validators.min(50), Validators.max(300)]],
      weight: [null, [Validators.min(30), Validators.max(500)]],
      fitnessLevel: [""],
      fitnessGoals: [[]],
      bodyFatPercentage: [null, [Validators.min(1), Validators.max(50)]],
    })
  }

  ngOnInit(): void {
    this.authService.currentUser.subscribe((user) => {
      this.currentUser = user
      if (user) {
        this.loadUserProfile(user.userId)
      }
    })
  }

  loadUserProfile(userId: number): void {
    this.loading.profile = true
    this.userService.getUserProfile(userId).subscribe(
      (profile) => {
        this.userProfile = profile
        this.populateForm(profile)
        this.loading.profile = false
      },
      (error) => {
        console.error("Error loading user profile", error)
        this.error.profile = "Failed to load profile data"
        this.loading.profile = false
      },
    )
  }

  populateForm(profile: UserProfile): void {
    if (!this.currentUser) return

    this.profileForm.patchValue({
      firstName: this.currentUser.firstName,
      lastName: this.currentUser.lastName,
      age: profile.age,
      gender: profile.gender,
      height: profile.height,
      weight: profile.weight,
      fitnessLevel: profile.fitnessLevel,
      fitnessGoals: profile.fitnessGoals || [],
      bodyFatPercentage: profile.bodyFatPercentage,
    })

    this.imagePreview = profile.profilePictureUrl || null
  }

  onSubmit(): void {
    if (this.profileForm.invalid) {
      return
    }

    this.loading.update = true

    if (!this.currentUser || !this.userProfile) {
      this.error.update = "User data not available"
      this.loading.update = false
      return
    }

    // Update user data
    const userData: User = {
      ...this.currentUser,
      firstName: this.profileForm.value.firstName,
      lastName: this.profileForm.value.lastName,
    }

    // Update profile data
    const profileData: UserProfile = {
      ...this.userProfile,
      age: this.profileForm.value.age,
      gender: this.profileForm.value.gender,
      height: this.profileForm.value.height,
      weight: this.profileForm.value.weight,
      fitnessLevel: this.profileForm.value.fitnessLevel,
      fitnessGoals: this.profileForm.value.fitnessGoals,
      bodyFatPercentage: this.profileForm.value.bodyFatPercentage,
    }

    // First update user data
    this.userService.updateUser(userData).subscribe(
      (updatedUser) => {
        // Then update profile data
        this.userService.updateUserProfile(profileData).subscribe(
          (updatedProfile) => {
            this.notificationService.success("Profile updated successfully")
            this.loading.update = false

            // Update local user data
            this.authService.updateCurrentUser(updatedUser)
          },
          (error) => {
            console.error("Error updating profile", error)
            this.error.update = "Failed to update profile"
            this.loading.update = false
          },
        )
      },
      (error) => {
        console.error("Error updating user", error)
        this.error.update = "Failed to update user information"
        this.loading.update = false
      },
    )
  }

  onFileSelected(files: File[]): void {
    if (files.length === 0) {
      this.selectedImage = null
      this.imagePreview = this.userProfile?.profilePictureUrl || null
      return
    }

    this.selectedImage = files[0]

    // Create a preview
    const reader = new FileReader()
    reader.onload = () => {
      this.imagePreview = reader.result as string
    }
    reader.readAsDataURL(this.selectedImage)

    // Upload the image
    this.uploadProfileImage()
  }

  uploadProfileImage(): void {
    if (!this.selectedImage || !this.currentUser) return

    this.loading.image = true

    this.userService.uploadProfileImage(this.currentUser.userId, this.selectedImage).subscribe(
      (imageUrl) => {
        if (this.userProfile) {
          this.userProfile.profilePictureUrl = imageUrl
          this.notificationService.success("Profile picture updated successfully")
        }
        this.loading.image = false
      },
      (error) => {
        console.error("Error uploading image", error)
        this.error.image = "Failed to upload profile picture"
        this.loading.image = false
      },
    )
  }

  removeProfileImage(): void {
    if (!this.currentUser || !this.userProfile) return

    this.loading.image = true

    this.userService.removeProfileImage(this.currentUser.userId).subscribe(
      () => {
        if (this.userProfile) {
          this.userProfile.profilePictureUrl = null
          this.imagePreview = null
          this.selectedImage = null
          this.notificationService.success("Profile picture removed successfully")
        }
        this.loading.image = false
      },
      (error) => {
        console.error("Error removing image", error)
        this.error.image = "Failed to remove profile picture"
        this.loading.image = false
      },
    )
  }
}
