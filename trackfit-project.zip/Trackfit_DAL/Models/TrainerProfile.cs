using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json;

namespace Trackfit.DAL.Models
{
    public class TrainerProfile
    {
        [Key]
        public int TrainerProfileId { get; set; }
        
        [Required]
        public int UserId { get; set; }
        
        public string Specialization { get; set; } // JSON array of specializations
        
        public int? Experience { get; set; } // Years of experience
        
        public string Biography { get; set; }
        
        public decimal? HourlyRate { get; set; }
        
        [Required]
        public bool IsVerified { get; set; }
        
        public decimal? Rating { get; set; }
        
        [StringLength(255)]
        public string ProfilePictureUrl { get; set; }
        
        [Required]
        public DateTime LastUpdated { get; set; }
        
        // Navigation properties
        [ForeignKey("UserId")]
        public virtual User User { get; set; }
        
        public virtual ICollection<TrainerCredential> Credentials { get; set; }
        public virtual ICollection<TrainerClient> Clients { get; set; }
        public virtual ICollection<TrainerFeedback> Feedback { get; set; }
        
        // Helper methods for JSON properties
        public string[] GetSpecializations()
        {
            if (string.IsNullOrEmpty(Specialization))
                return Array.Empty<string>();
            
            return JsonSerializer.Deserialize<string[]>(Specialization);
        }
        
        public void SetSpecializations(string[] specializations)
        {
            Specialization = JsonSerializer.Serialize(specializations);
        }
    }
}
