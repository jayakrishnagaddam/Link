"use client"

import  from "../Trackfit_Application/src/main"

export default function SyntheticV0PageForDeployment() {
  return < />
}