import { Component, type OnInit, Input, Output, EventEmitter } from "@angular/core"

interface CalendarDay {
  date: Date
  isCurrentMonth: boolean
  isToday: boolean
  hasEvents: boolean
  events?: any[]
}

@Component({
  selector: "app-calendar",
  templateUrl: "./calendar.component.html",
  styleUrls: ["./calendar.component.css"],
})
export class CalendarComponent implements OnInit {
  @Input() events: any[] = []
  @Input() eventDateField = "date"

  @Output() dayClick = new EventEmitter<Date>()
  @Output() eventClick = new EventEmitter<any>()

  currentDate: Date = new Date()
  selectedDate: Date | null = null
  calendarDays: CalendarDay[] = []
  weekdays: string[] = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
  months: string[] = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ]

  constructor() {}

  ngOnInit(): void {
    this.generateCalendarDays()
  }

  ngOnChanges(): void {
    this.generateCalendarDays()
  }

  generateCalendarDays(): void {
    this.calendarDays = []

    const year = this.currentDate.getFullYear()
    const month = this.currentDate.getMonth()

    // First day of the month
    const firstDay = new Date(year, month, 1)
    // Last day of the month
    const lastDay = new Date(year, month + 1, 0)

    // Get the day of the week for the first day (0-6, where 0 is Sunday)
    const firstDayOfWeek = firstDay.getDay()

    // Get the last date of the previous month
    const prevMonthLastDay = new Date(year, month, 0).getDate()

    // Add days from previous month
    for (let i = firstDayOfWeek - 1; i >= 0; i--) {
      const date = new Date(year, month - 1, prevMonthLastDay - i)
      this.calendarDays.push({
        date,
        isCurrentMonth: false,
        isToday: this.isToday(date),
        hasEvents: this.hasEvents(date),
      })
    }

    // Add days of current month
    for (let i = 1; i <= lastDay.getDate(); i++) {
      const date = new Date(year, month, i)
      this.calendarDays.push({
        date,
        isCurrentMonth: true,
        isToday: this.isToday(date),
        hasEvents: this.hasEvents(date),
      })
    }

    // Add days from next month to complete the calendar grid
    const remainingDays = 42 - this.calendarDays.length // 6 rows of 7 days
    for (let i = 1; i <= remainingDays; i++) {
      const date = new Date(year, month + 1, i)
      this.calendarDays.push({
        date,
        isCurrentMonth: false,
        isToday: this.isToday(date),
        hasEvents: this.hasEvents(date),
      })
    }
  }

  isToday(date: Date): boolean {
    const today = new Date()
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    )
  }

  hasEvents(date: Date): boolean {
    if (!this.events || this.events.length === 0) return false

    return this.events.some((event) => {
      const eventDate = new Date(event[this.eventDateField])
      return (
        eventDate.getDate() === date.getDate() &&
        eventDate.getMonth() === date.getMonth() &&
        eventDate.getFullYear() === date.getFullYear()
      )
    })
  }

  getEventsForDay(date: Date): any[] {
    if (!this.events || this.events.length === 0) return []

    return this.events.filter((event) => {
      const eventDate = new Date(event[this.eventDateField])
      return (
        eventDate.getDate() === date.getDate() &&
        eventDate.getMonth() === date.getMonth() &&
        eventDate.getFullYear() === date.getFullYear()
      )
    })
  }

  onDayClick(day: CalendarDay): void {
    this.selectedDate = day.date
    this.dayClick.emit(day.date)
  }

  onEventClick(event: any): void {
    this.eventClick.emit(event)
  }

  previousMonth(): void {
    this.currentDate = new Date(this.currentDate.getFullYear(), this.currentDate.getMonth() - 1, 1)
    this.generateCalendarDays()
  }

  nextMonth(): void {
    this.currentDate = new Date(this.currentDate.getFullYear(), this.currentDate.getMonth() + 1, 1)
    this.generateCalendarDays()
  }

  goToToday(): void {
    this.currentDate = new Date()
    this.generateCalendarDays()
  }
}
