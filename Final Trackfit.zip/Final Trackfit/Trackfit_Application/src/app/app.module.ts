import { NgModule } from "@angular/core"
import { BrowserModule } from "@angular/platform-browser"
import { FormsModule, ReactiveFormsModule } from "@angular/forms"
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http"
import { BrowserAnimationsModule } from "@angular/platform-browser/animations"
import { RouterModule } from "@angular/router"

import { AppRoutingModule } from "./app-routing.module"
import { AppComponent } from "./app.component"

// Core components
import { HeaderComponent } from "./core/header/header.component"
import { FooterComponent } from "./core/footer/footer.component"
import { SidebarComponent } from "./core/sidebar/sidebar.component"
import { PageNotFoundComponent } from "./core/page-not-found/page-not-found.component"

// Auth components
import { LoginComponent } from "./auth/login/login.component"
import { RegisterComponent } from "./auth/register/register.component"
import { ForgotPasswordComponent } from "./auth/forgot-password/forgot-password.component"
import { ResetPasswordComponent } from "./auth/reset-password/reset-password.component"

// Home components
import { HomeComponent } from "./home/home.component"
import { IntroComponent } from "./home/intro/intro.component"

// User components
import { UserProfileComponent } from "./user/user-profile/user-profile.component"
import { UserDashboardComponent } from "./user/user-dashboard/user-dashboard.component"
import { UserWorkoutsComponent } from "./user/user-workouts/user-workouts.component"
import { UserNutritionComponent } from "./user/user-nutrition/user-nutrition.component"
import { UserProgressComponent } from "./user/user-progress/user-progress.component"
import { UserChallengesComponent } from "./user/user-challenges/user-challenges.component"
import { UserSettingsComponent } from "./user/user-settings/user-settings.component"

// Trainer components
import { TrainerProfileComponent } from "./trainer/trainer-profile/trainer-profile.component"
import { TrainerDashboardComponent } from "./trainer/trainer-dashboard/trainer-dashboard.component"
import { TrainerClientsComponent } from "./trainer/trainer-clients/trainer-clients.component"
import { TrainerWorkoutsComponent } from "./trainer/trainer-workouts/trainer-workouts.component"
import { TrainerFeedbackComponent } from "./trainer/trainer-feedback/trainer-feedback.component"
import { TrainerSettingsComponent } from "./trainer/trainer-settings/trainer-settings.component"

// Admin components
import { AdminDashboardComponent } from "./admin/admin-dashboard/admin-dashboard.component"
import { AdminUsersComponent } from "./admin/admin-users/admin-users.component"
import { AdminTrainersComponent } from "./admin/admin-trainers/admin-trainers.component"
import { AdminContentComponent } from "./admin/admin-content/admin-content.component"
import { AdminAnalyticsComponent } from "./admin/admin-analytics/admin-analytics.component"
import { AdminSubscriptionsComponent } from "./admin/admin-subscriptions/admin-subscriptions.component"
import { AdminSupportComponent } from "./admin/admin-support/admin-support.component"
import { AdminSettingsComponent } from "./admin/admin-settings/admin-settings.component"

// Workout components
import { WorkoutListComponent } from "./workouts/workout-list/workout-list.component"
import { WorkoutDetailComponent } from "./workouts/workout-detail/workout-detail.component"
import { WorkoutPlayerComponent } from "./workouts/workout-player/workout-player.component"
import { ExerciseListComponent } from "./workouts/exercise-list/exercise-list.component"
import { ExerciseDetailComponent } from "./workouts/exercise-detail/exercise-detail.component"

// Nutrition components
import { NutritionLogComponent } from "./nutrition/nutrition-log/nutrition-log.component"
import { NutritionPlanComponent } from "./nutrition/nutrition-plan/nutrition-plan.component"
import { NutritionAnalyticsComponent } from "./nutrition/nutrition-analytics/nutrition-analytics.component"

// Challenge components
import { ChallengeListComponent } from "./challenges/challenge-list/challenge-list.component"
import { ChallengeDetailComponent } from "./challenges/challenge-detail/challenge-detail.component"
import { ChallengeLeaderboardComponent } from "./challenges/challenge-leaderboard/challenge-leaderboard.component"

// Shared components
import { LoadingSpinnerComponent } from "./shared/loading-spinner/loading-spinner.component"
import { AlertComponent } from "./shared/alert/alert.component"
import { ConfirmDialogComponent } from "./shared/confirm-dialog/confirm-dialog.component"
import { ChartComponent } from "./shared/chart/chart.component"
import { CalendarComponent } from "./shared/calendar/calendar.component"
import { FileUploadComponent } from "./shared/file-upload/file-upload.component"

// Services
import { AuthService } from "./services/auth.service"
import { UserService } from "./services/user.service"
import { TrainerService } from "./services/trainer.service"
import { AdminService } from "./services/admin.service"
import { WorkoutService } from "./services/workout.service"
import { NutritionService } from "./services/nutrition.service"
import { ChallengeService } from "./services/challenge.service"
import { MessageService } from "./services/message.service"
import { NotificationService } from "./services/notification.service"

// Interceptors
import { AuthInterceptor } from "./interceptors/auth.interceptor"
import { ErrorInterceptor } from "./interceptors/error.interceptor"

// Guards
import { AuthGuard } from "./guards/auth.guard"
import { RoleGuard } from "./guards/role.guard"

@NgModule({
  declarations: [
    AppComponent,
    // Core components
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    PageNotFoundComponent,
    // Auth components
    LoginComponent,
    RegisterComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    // Home components
    HomeComponent,
    IntroComponent,
    // User components
    UserProfileComponent,
    UserDashboardComponent,
    UserWorkoutsComponent,
    UserNutritionComponent,
    UserProgressComponent,
    UserChallengesComponent,
    UserSettingsComponent,
    // Trainer components
    TrainerProfileComponent,
    TrainerDashboardComponent,
    TrainerClientsComponent,
    TrainerWorkoutsComponent,
    TrainerFeedbackComponent,
    TrainerSettingsComponent,
    // Admin components
    AdminDashboardComponent,
    AdminUsersComponent,
    AdminTrainersComponent,
    AdminContentComponent,
    AdminAnalyticsComponent,
    AdminSubscriptionsComponent,
    AdminSupportComponent,
    AdminSettingsComponent,
    // Workout components
    WorkoutListComponent,
    WorkoutDetailComponent,
    WorkoutPlayerComponent,
    ExerciseListComponent,
    ExerciseDetailComponent,
    // Nutrition components
    NutritionLogComponent,
    NutritionPlanComponent,
    NutritionAnalyticsComponent,
    // Challenge components
    ChallengeListComponent,
    ChallengeDetailComponent,
    ChallengeLeaderboardComponent,
    // Shared components
    LoadingSpinnerComponent,
    AlertComponent,
    ConfirmDialogComponent,
    ChartComponent,
    CalendarComponent,
    FileUploadComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    RouterModule,
  ],
  providers: [
    // Services
    AuthService,
    UserService,
    TrainerService,
    AdminService,
    WorkoutService,
    NutritionService,
    ChallengeService,
    MessageService,
    NotificationService,
    // Guards
    AuthGuard,
    RoleGuard,
    // Interceptors
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
