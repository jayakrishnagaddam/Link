using System.Collections.Generic;
using System.Threading.Tasks;
using Trackfit.Services.DTOs;

namespace Trackfit.Services.Interfaces
{
    public interface ITrainerService
    {
        // Trainer profile
        Task<TrainerProfileDto> GetTrainerProfileAsync(int trainerId);
        Task<TrainerProfileDto> UpdateTrainerProfileAsync(TrainerProfileDto profileDto);
        Task<IEnumerable<TrainerProfileDto>> GetAllTrainersAsync();
        Task<IEnumerable<TrainerProfileDto>> SearchTrainersAsync(string searchTerm, string specialization = null);
        
        // Trainer credentials
        Task<IEnumerable<TrainerCredentialDto>> GetTrainerCredentialsAsync(int trainerId);
        Task<TrainerCredentialDto> AddTrainerCredentialAsync(TrainerCredentialDto credentialDto);
        Task<TrainerCredentialDto> UpdateTrainerCredentialAsync(TrainerCredentialDto credentialDto);
        Task<bool> DeleteTrainerCredentialAsync(int credentialId);
        
        // Trainer clients
        Task<IEnumerable<UserDto>> GetTrainerClientsAsync(int trainerId);
        Task<bool> AddClientAsync(int trainerId, int clientId);
        Task<bool> RemoveClientAsync(int trainerId, int clientId);
        
        // Workout programs
        Task<WorkoutProgramDto> CreateWorkoutProgramAsync(WorkoutProgramDto programDto);
        Task<WorkoutProgramDto> UpdateWorkoutProgramAsync(WorkoutProgramDto programDto);
        Task<bool> DeleteWorkoutProgramAsync(int programId);
        Task<IEnumerable<WorkoutProgramDto>> GetTrainerWorkoutProgramsAsync(int trainerId);
        
        // Client feedback
        Task<TrainerFeedbackDto> ProvideExerciseFeedbackAsync(TrainerFeedbackDto feedbackDto);
        Task<IEnumerable<TrainerFeedbackDto>> GetClientFeedbackHistoryAsync(int trainerId, int clientId);
        
        // Nutrition plans
        Task<NutritionPlanDto> CreateNutritionPlanAsync(NutritionPlanDto planDto);
        Task<NutritionPlanDto> UpdateNutritionPlanAsync(NutritionPlanDto planDto);
        Task<bool> DeleteNutritionPlanAsync(int planId);
        Task<bool> AssignNutritionPlanToClientAsync(int planId, int clientId);
    }
}
