import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {
  profileForm: FormGroup;
  notificationsForm: FormGroup;
  privacyForm: FormGroup;
  appearanceForm: FormGroup;
  
  themeOptions = [
    { value: 'light', label: 'Light' },
    { value: 'dark', label: 'Dark' },
    { value: 'system', label: 'System Default' }
  ];
  
  measurementOptions = [
    { value: 'metric', label: 'Metric (kg, cm)' },
    { value: 'imperial', label: 'Imperial (lbs, ft/in)' }
  ];
  
  languageOptions = [
    { value: 'en', label: 'English' },
    { value: 'es', label: 'Spanish' },
    { value: 'fr', label: 'French' },
    { value: 'de', label: 'German' }
  ];
  
  loading = false;
  saveSuccess = false;
  saveError = false;

  constructor(private fb: FormBuilder) {
    this.profileForm = this.fb.group({
      firstName: ['John', Validators.required],
      lastName: ['Doe', Validators.required],
      email: ['john.doe@example.com', [Validators.required, Validators.email]],
      phone: [''],
      language: ['en', Validators.required],
      measurement: ['metric', Validators.required]
    });
    
    this.notificationsForm = this.fb.group({
      workoutReminders: [true],
      achievementNotifications: [true],
      weeklyReports: [true],
      challengeUpdates: [true],
      emailNotifications: [true],
      pushNotifications: [true],
      reminderTime: ['18:00', Validators.required]
    });
    
    this.privacyForm = this.fb.group({
      profileVisibility: ['friends'], // public, friends, private
      activitySharing: [true],
      dataCollection: [true],
      allowTagging: [true]
    });
    
    this.appearanceForm = this.fb.group({
      theme: ['light', Validators.required],
      compactMode: [false],
      animationsEnabled: [true],
      fontSize: ['medium'] // small, medium, large
    });
  }

  ngOnInit(): void {
    // Load user settings from API in a real app
  }
  
  saveProfile(): void {
    if (this.profileForm.invalid) {
      this.markFormGroupTouched(this.profileForm);
      return;
    }
    
    this.saveSettings(this.profileForm.value, 'profile');
  }
  
  saveNotifications(): void {
    if (this.notificationsForm.invalid) {
      this.markFormGroupTouched(this.notificationsForm);
      return;
    }
    
    this.saveSettings(this.notificationsForm.value, 'notifications');
  }
  
  savePrivacy(): void {
    if (this.privacyForm.invalid) {
      this.markFormGroupTouched(this.privacyForm);
      return;
    }
    
    this.saveSettings(this.privacyForm.value, 'privacy');
  }
  
  saveAppearance(): void {
    if (this.appearanceForm.invalid) {
      this.markFormGroupTouched(this.appearanceForm);
      return;
    }
    
    this.saveSettings(this.appearanceForm.value, 'appearance');
  }
  
  saveSettings(formData: any, settingType: string): void {
    this.loading = true;
    this.saveSuccess = false;
    this.saveError = false;
    
    // Simulate API call
    console.log(`Saving ${settingType} settings:`, formData);
    
    setTimeout(() => {
      this.loading = false;
      this.saveSuccess = true;
      
      // Hide success message after 3 seconds
      setTimeout(() => {
        this.saveSuccess = false;
      }, 3000);
    }, 1000);
  }
  
  markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }
}