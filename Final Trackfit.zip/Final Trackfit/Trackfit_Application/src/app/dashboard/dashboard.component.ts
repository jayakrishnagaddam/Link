import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  userStats = {
    workoutsCompleted: 42,
    activeChallenges: 3,
    caloriesBurned: 12500,
    streakDays: 15
  };

  recentWorkouts = [
    { id: 1, name: 'Morning Cardio', date: '2023-05-15', duration: '45 min', caloriesBurned: 320 },
    { id: 2, name: 'Upper Body Strength', date: '2023-05-14', duration: '60 min', caloriesBurned: 450 },
    { id: 3, name: 'Yoga Flow', date: '2023-05-12', duration: '30 min', caloriesBurned: 180 }
  ];

  upcomingEvents = [
    { id: 1, name: 'HIIT Challenge', date: '2023-05-18', type: 'challenge' },
    { id: 2, name: 'Weekly Weigh-In', date: '2023-05-20', type: 'progress' },
    { id: 3, name: 'Nutrition Plan Update', date: '2023-05-21', type: 'nutrition' }
  ];

  constructor() { }

  ngOnInit(): void {
    // Load user dashboard data
  }
}