import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { SettingsComponent } from './settings.component';

describe('SettingsComponent', () => {
  let component: SettingsComponent;
  let fixture: ComponentFixture<SettingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SettingsComponent ],
      imports: [ ReactiveFormsModule ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize all forms with default values', () => {
    expect(component.profileForm).toBeTruthy();
    expect(component.notificationsForm).toBeTruthy();
    expect(component.privacyForm).toBeTruthy();
    expect(component.appearanceForm).toBeTruthy();
    
    // Check some default values
    expect(component.profileForm.get('firstName')?.value).toBe('John');
    expect(component.notificationsForm.get('workoutReminders')?.value).toBeTrue();
    expect(component.appearanceForm.get('theme')?.value).toBe('light');
  });

  it('should validate the profile form correctly', () => {
    // Valid form
    expect(component.profileForm.valid).toBeTrue();
    
    // Make it invalid
    component.profileForm.get('firstName')?.setValue('');
    component.profileForm.get('email')?.setValue('invalid-email');
    
    expect(component.profileForm.valid).toBeFalse();
    expect(component.profileForm.get('firstName')?.valid).toBeFalse();
    expect(component.profileForm.get('email')?.valid).toBeFalse();
  });

  it('should show loading state when saving settings', () => {
    component.saveProfile();
    expect(component.loading).toBeTrue();
    
    // Fast-forward time
    jasmine.clock().install();
    jasmine.clock().tick(1000);
    
    expect(component.loading).toBeFalse();
    expect(component.saveSuccess).toBeTrue();
    
    jasmine.clock().tick(3000);
    expect(component.saveSuccess).toBeFalse();
    
    jasmine.clock().uninstall();
  });

  it('should mark form as touched when saving invalid form', () => {
    component.profileForm.get('firstName')?.setValue('');
    spyOn(component, 'markFormGroupTouched');
    
    component.saveProfile();
    
    expect(component.markFormGroupTouched).toHaveBeenCalledWith(component.profileForm);
  });
});