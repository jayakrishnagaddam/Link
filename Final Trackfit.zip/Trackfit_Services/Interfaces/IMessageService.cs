using System.Collections.Generic;
using System.Threading.Tasks;
using Trackfit.Services.DTOs;

namespace Trackfit.Services.Interfaces
{
    public interface IMessageService
    {
        // Messages
        Task<MessageDto> SendMessageAsync(MessageDto messageDto);
        Task<MessageDto> GetMessageAsync(int messageId);
        Task<IEnumerable<MessageDto>> GetUserMessagesAsync(int userId, bool sent = false);
        Task<IEnumerable<MessageDto>> GetConversationAsync(int user1Id, int user2Id);
        Task<bool> MarkMessageAsReadAsync(int messageId);
        Task<bool> DeleteMessageAsync(int messageId);
        
        // Notifications
        Task<NotificationDto> CreateNotificationAsync(NotificationDto notificationDto);
        Task<IEnumerable<NotificationDto>> GetUserNotificationsAsync(int userId, bool unreadOnly = false);
        Task<bool> MarkNotificationAsReadAsync(int notificationId);
        Task<bool> DeleteNotificationAsync(int notificationId);
    }
}
