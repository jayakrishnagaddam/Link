import { Component, type OnInit } from "@angular/core"
import type { Router } from "@angular/router"
import type { NutritionService } from "../../services/nutrition.service"
import type { AuthService } from "../../services/auth.service"
import type { NotificationService } from "../../services/notification.service"
import type { User } from "../../models/user.model"
import type { NutritionLog, NutritionSummary, NutritionPlan } from "../../models/nutrition.model"

@Component({
  selector: "app-user-nutrition",
  templateUrl: "./user-nutrition.component.html",
  styleUrls: ["./user-nutrition.component.css"],
})
export class UserNutritionComponent implements OnInit {
  currentUser: User | null = null
  selectedDate: Date = new Date()
  nutritionSummary: NutritionSummary | null = null
  nutritionLogs: NutritionLog[] = []
  activePlans: NutritionPlan[] = []

  activeTab = "daily"

  loading = {
    summary: true,
    logs: true,
    plans: true,
  }

  error = {
    summary: "",
    logs: "",
    plans: "",
  }

  showAddMealModal = false
  mealTypes = ["Breakfast", "Lunch", "Dinner", "Snack"]

  constructor(
    private authService: AuthService,
    private nutritionService: NutritionService,
    private notificationService: NotificationService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.authService.currentUser.subscribe((user) => {
      this.currentUser = user
      if (user) {
        this.loadNutritionData(user.userId, this.selectedDate)
        this.loadActivePlans(user.userId)
      }
    })
  }

  setActiveTab(tab: string): void {
    this.activeTab = tab
  }

  changeDate(offset: number): void {
    const newDate = new Date(this.selectedDate)
    newDate.setDate(newDate.getDate() + offset)
    this.selectedDate = newDate

    if (this.currentUser) {
      this.loadNutritionData(this.currentUser.userId, this.selectedDate)
    }
  }

  setToday(): void {
    this.selectedDate = new Date()

    if (this.currentUser) {
      this.loadNutritionData(this.currentUser.userId, this.selectedDate)
    }
  }

  openAddMealModal(): void {
    this.showAddMealModal = true
  }

  closeAddMealModal(): void {
    this.showAddMealModal = false
  }

  addMeal(mealData: any): void {
    if (!this.currentUser) return

    const nutritionLog: NutritionLog = {
      nutritionLogId: 0,
      userId: this.currentUser.userId,
      logDate: this.selectedDate,
      mealType: mealData.mealType,
      foodName: mealData.foodName,
      calories: mealData.calories,
      protein: mealData.protein,
      carbohydrates: mealData.carbohydrates,
      fat: mealData.fat,
      portion: mealData.portion,
      portionUnit: mealData.portionUnit,
      notes: mealData.notes,
      createdDate: new Date(),
    }

    this.nutritionService.logNutrition(nutritionLog).subscribe(
      (result) => {
        this.notificationService.success("Meal added successfully")
        this.closeAddMealModal()
        this.loadNutritionData(this.currentUser!.userId, this.selectedDate)
      },
      (error) => {
        this.notificationService.error("Failed to add meal")
        console.error("Error adding meal", error)
      },
    )
  }

  deleteMeal(logId: number): void {
    if (confirm("Are you sure you want to delete this meal?")) {
      this.nutritionService.deleteNutritionLog(logId).subscribe(
        (success) => {
          if (success) {
            this.notificationService.success("Meal deleted successfully")
            this.loadNutritionData(this.currentUser!.userId, this.selectedDate)
          } else {
            this.notificationService.error("Failed to delete meal")
          }
        },
        (error) => {
          this.notificationService.error("An error occurred while deleting the meal")
          console.error("Error deleting meal", error)
        },
      )
    }
  }

  viewPlanDetails(planId: number): void {
    this.router.navigate(["/nutrition/plan", planId])
  }

  viewNutritionAnalytics(): void {
    this.router.navigate(["/nutrition/analytics"])
  }

  private loadNutritionData(userId: number, date: Date): void {
    this.loadNutritionSummary(userId, date)
    this.loadNutritionLogs(userId, date)
  }

  private loadNutritionSummary(userId: number, date: Date): void {
    this.loading.summary = true
    this.nutritionService.getUserNutritionSummary(userId, date).subscribe(
      (summary) => {
        this.nutritionSummary = summary
        this.loading.summary = false
      },
      (error) => {
        console.error("Error loading nutrition summary", error)
        this.error.summary = "Failed to load nutrition summary"
        this.loading.summary = false
      },
    )
  }

  private loadNutritionLogs(userId: number, date: Date): void {
    this.loading.logs = true
    this.nutritionService.getUserNutritionLogs(userId, date).subscribe(
      (logs) => {
        this.nutritionLogs = logs
        this.loading.logs = false
      },
      (error) => {
        console.error("Error loading nutrition logs", error)
        this.error.logs = "Failed to load nutrition logs"
        this.loading.logs = false
      },
    )
  }

  private loadActivePlans(userId: number): void {
    this.loading.plans = true
    this.nutritionService.getUserNutritionPlans(userId).subscribe(
      (plans) => {
        this.activePlans = plans.filter((p) => p.isActive)
        this.loading.plans = false
      },
      (error) => {
        console.error("Error loading nutrition plans", error)
        this.error.plans = "Failed to load nutrition plans"
        this.loading.plans = false
      },
    )
  }

  getNutritionPercentage(current: number, goal: number | undefined): number {
    if (!goal || goal === 0) return 0
    return Math.min(100, Math.round((current / goal) * 100))
  }

  formatDate(date: Date | string): string {
    const d = new Date(date)
    return d.toLocaleDateString("en-US", {
      weekday: "long",
      month: "long",
      day: "numeric",
    })
  }
}
