export const environment = {
  production: true,
  apiUrl: "https://api.trackfit.com/api",
}
