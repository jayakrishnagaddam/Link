import { Component, type OnInit } from "@angular/core"
import type { AuthService } from "../../services/auth.service"
import type { User } from "../../models/user.model"

@Component({
  selector: "app-sidebar",
  templateUrl: "./sidebar.component.html",
  styleUrls: ["./sidebar.component.css"],
})
export class SidebarComponent implements OnInit {
  currentUser: User | null = null
  isCollapsed = false

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    this.authService.currentUser.subscribe((user) => {
      this.currentUser = user
    })
  }

  toggleSidebar(): void {
    this.isCollapsed = !this.isCollapsed
  }
}
