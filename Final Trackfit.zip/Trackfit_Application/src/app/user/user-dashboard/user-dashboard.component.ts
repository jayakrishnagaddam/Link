import { Component, type OnInit } from "@angular/core"
import type { UserService } from "../../services/user.service"
import type { WorkoutService } from "../../services/workout.service"
import type { NutritionService } from "../../services/nutrition.service"
import type { ChallengeService } from "../../services/challenge.service"
import type { AuthService } from "../../services/auth.service"
import type { User, UserStats } from "../../models/user.model"
import type { UserWorkoutSchedule, UserWorkoutLog } from "../../models/workout.model"
import type { NutritionSummary } from "../../models/nutrition.model"
import type { Challenge } from "../../models/challenge.model"

@Component({
  selector: "app-user-dashboard",
  templateUrl: "./user-dashboard.component.html",
  styleUrls: ["./user-dashboard.component.css"],
})
export class UserDashboardComponent implements OnInit {
  currentUser: User | null = null
  userStats: UserStats | null = null
  upcomingWorkouts: UserWorkoutSchedule[] = []
  recentWorkouts: UserWorkoutLog[] = []
  recommendedWorkouts: any[] = []
  todayNutrition: NutritionSummary | null = null
  activeChallenges: Challenge[] = []

  loading = {
    stats: true,
    upcomingWorkouts: true,
    recentWorkouts: true,
    recommendedWorkouts: true,
    nutrition: true,
    challenges: true,
  }

  error = {
    stats: "",
    upcomingWorkouts: "",
    recentWorkouts: "",
    recommendedWorkouts: "",
    nutrition: "",
    challenges: "",
  }

  constructor(
    private authService: AuthService,
    private userService: UserService,
    private workoutService: WorkoutService,
    private nutritionService: NutritionService,
    private challengeService: ChallengeService,
  ) {}

  ngOnInit(): void {
    this.authService.currentUser.subscribe((user) => {
      this.currentUser = user
      if (user) {
        this.loadDashboardData(user.userId)
      }
    })
  }

  private loadDashboardData(userId: number): void {
    this.loadUserStats(userId)
    this.loadUpcomingWorkouts(userId)
    this.loadRecentWorkouts(userId)
    this.loadRecommendedWorkouts(userId)
    this.loadTodayNutrition(userId)
    this.loadActiveChallenges(userId)
  }

  private loadUserStats(userId: number): void {
    this.loading.stats = true
    this.userService.getUserStats(userId).subscribe(
      (stats) => {
        this.userStats = stats
        this.loading.stats = false
      },
      (error) => {
        console.error("Error loading user stats", error)
        this.error.stats = "Failed to load user statistics"
        this.loading.stats = false
      },
    )
  }

  private loadUpcomingWorkouts(userId: number): void {
    this.loading.upcomingWorkouts = true
    const today = new Date()
    const nextWeek = new Date()
    nextWeek.setDate(today.getDate() + 7)

    this.workoutService.getUserWorkoutSchedules(userId, today, nextWeek).subscribe(
      (schedules) => {
        this.upcomingWorkouts = schedules
          .filter((s) => s.status === "Scheduled")
          .sort((a, b) => new Date(a.scheduledDate).getTime() - new Date(b.scheduledDate).getTime())
        this.loading.upcomingWorkouts = false
      },
      (error) => {
        console.error("Error loading upcoming workouts", error)
        this.error.upcomingWorkouts = "Failed to load upcoming workouts"
        this.loading.upcomingWorkouts = false
      },
    )
  }

  private loadRecentWorkouts(userId: number): void {
    this.loading.recentWorkouts = true
    this.workoutService.getUserWorkoutLogs(userId).subscribe(
      (logs) => {
        this.recentWorkouts = logs.slice(0, 5)
        this.loading.recentWorkouts = false
      },
      (error) => {
        console.error("Error loading recent workouts", error)
        this.error.recentWorkouts = "Failed to load recent workouts"
        this.loading.recentWorkouts = false
      },
    )
  }

  private loadRecommendedWorkouts(userId: number): void {
    this.loading.recommendedWorkouts = true
    this.workoutService.getRecommendedWorkoutPrograms(userId).subscribe(
      (programs) => {
        this.recommendedWorkouts = programs.slice(0, 3)
        this.loading.recommendedWorkouts = false
      },
      (error) => {
        console.error("Error loading recommended workouts", error)
        this.error.recommendedWorkouts = "Failed to load workout recommendations"
        this.loading.recommendedWorkouts = false
      },
    )
  }

  private loadTodayNutrition(userId: number): void {
    this.loading.nutrition = true
    const today = new Date()
    this.nutritionService.getUserNutritionSummary(userId, today).subscribe(
      (summary) => {
        this.todayNutrition = summary
        this.loading.nutrition = false
      },
      (error) => {
        console.error("Error loading nutrition summary", error)
        this.error.nutrition = "Failed to load nutrition data"
        this.loading.nutrition = false
      },
    )
  }

  private loadActiveChallenges(userId: number): void {
    this.loading.challenges = true
    this.challengeService.getUserChallenges(userId).subscribe(
      (challenges) => {
        this.activeChallenges = challenges.filter(
          (c) => new Date(c.startDate) <= new Date() && new Date(c.endDate) >= new Date(),
        )
        this.loading.challenges = false
      },
      (error) => {
        console.error("Error loading active challenges", error)
        this.error.challenges = "Failed to load challenges"
        this.loading.challenges = false
      },
    )
  }

  formatDate(date: Date | string): string {
    const d = new Date(date)
    return d.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  getWorkoutTimeRemaining(schedule: UserWorkoutSchedule): string {
    const now = new Date()
    const scheduledDate = new Date(schedule.scheduledDate)
    const diffMs = scheduledDate.getTime() - now.getTime()

    if (diffMs < 0) return "Overdue"

    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))
    const diffHours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))

    if (diffDays > 0) {
      return `${diffDays}d ${diffHours}h`
    } else {
      const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60))
      return `${diffHours}h ${diffMinutes}m`
    }
  }

  getChallengeProgress(challenge: Challenge): number {
    const now = new Date()
    const start = new Date(challenge.startDate)
    const end = new Date(challenge.endDate)

    const totalDuration = end.getTime() - start.getTime()
    const elapsed = now.getTime() - start.getTime()

    return Math.min(100, Math.max(0, Math.round((elapsed / totalDuration) * 100)))
  }

  getChallengeTimeRemaining(challenge: Challenge): string {
    const now = new Date()
    const end = new Date(challenge.endDate)
    const diffMs = end.getTime() - now.getTime()

    if (diffMs < 0) return "Ended"

    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))

    if (diffDays > 0) {
      return `${diffDays} days left`
    } else {
      const diffHours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
      return `${diffHours} hours left`
    }
  }

  getNutritionPercentage(current: number, goal: number | undefined): number {
    if (!goal || goal === 0) return 0
    return Math.min(100, Math.round((current / goal) * 100))
  }
}
