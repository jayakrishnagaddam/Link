import { Component, type OnInit } from "@angular/core"
import type { Router } from "@angular/router"
import type { ProgressService } from "../../services/progress.service"
import type { AuthService } from "../../services/auth.service"
import type { NotificationService } from "../../services/notification.service"
import type { User } from "../../models/user.model"
import type { ProgressMetric, ProgressEntry, ProgressGoal } from "../../models/progress.model"

@Component({
  selector: "app-user-progress",
  templateUrl: "./user-progress.component.html",
  styleUrls: ["./user-progress.component.css"],
})
export class UserProgressComponent implements OnInit {
  currentUser: User | null = null
  metrics: ProgressMetric[] = []
  selectedMetric: ProgressMetric | null = null
  progressEntries: ProgressEntry[] = []
  progressGoals: ProgressGoal[] = []

  timeRanges = ["1W", "1M", "3M", "6M", "1Y", "All"]
  selectedTimeRange = "1M"

  loading = {
    metrics: true,
    entries: false,
    goals: true,
  }

  error = {
    metrics: "",
    entries: "",
    goals: "",
  }

  showAddEntryModal = false
  showAddGoalModal = false

  constructor(
    private authService: AuthService,
    private progressService: ProgressService,
    private notificationService: NotificationService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.authService.currentUser.subscribe((user) => {
      this.currentUser = user
      if (user) {
        this.loadMetrics(user.userId)
        this.loadGoals(user.userId)
      }
    })
  }

  loadMetrics(userId: number): void {
    this.loading.metrics = true
    this.progressService.getUserProgressMetrics(userId).subscribe(
      (metrics) => {
        this.metrics = metrics
        this.loading.metrics = false

        // Select the first metric by default if available
        if (metrics.length > 0 && !this.selectedMetric) {
          this.selectMetric(metrics[0])
        }
      },
      (error) => {
        console.error("Error loading progress metrics", error)
        this.error.metrics = "Failed to load progress metrics"
        this.loading.metrics = false
      },
    )
  }

  loadGoals(userId: number): void {
    this.loading.goals = true
    this.progressService.getUserProgressGoals(userId).subscribe(
      (goals) => {
        this.progressGoals = goals
        this.loading.goals = false
      },
      (error) => {
        console.error("Error loading progress goals", error)
        this.error.goals = "Failed to load progress goals"
        this.loading.goals = false
      },
    )
  }

  loadProgressEntries(metricId: number): void {
    if (!this.currentUser) return

    this.loading.entries = true
    const timeRange = this.getTimeRangeInDays(this.selectedTimeRange)

    this.progressService.getUserProgressEntries(this.currentUser.userId, metricId, timeRange).subscribe(
      (entries) => {
        this.progressEntries = entries.sort((a, b) => new Date(a.entryDate).getTime() - new Date(b.entryDate).getTime())
        this.loading.entries = false
      },
      (error) => {
        console.error("Error loading progress entries", error)
        this.error.entries = "Failed to load progress data"
        this.loading.entries = false
      },
    )
  }

  selectMetric(metric: ProgressMetric): void {
    this.selectedMetric = metric
    this.loadProgressEntries(metric.metricId)
  }

  selectTimeRange(range: string): void {
    this.selectedTimeRange = range
    if (this.selectedMetric) {
      this.loadProgressEntries(this.selectedMetric.metricId)
    }
  }

  openAddEntryModal(): void {
    this.showAddEntryModal = true
  }

  closeAddEntryModal(): void {
    this.showAddEntryModal = false
  }

  openAddGoalModal(): void {
    this.showAddGoalModal = true
  }

  closeAddGoalModal(): void {
    this.showAddGoalModal = false
  }

  addProgressEntry(entryData: any): void {
    if (!this.currentUser || !this.selectedMetric) return

    const entry: ProgressEntry = {
      entryId: 0,
      userId: this.currentUser.userId,
      metricId: this.selectedMetric.metricId,
      entryDate: entryData.entryDate || new Date(),
      value: entryData.value,
      notes: entryData.notes || "",
      createdDate: new Date(),
    }

    this.progressService.addProgressEntry(entry).subscribe(
      (result) => {
        this.notificationService.success("Progress entry added successfully")
        this.closeAddEntryModal()
        this.loadProgressEntries(this.selectedMetric!.metricId)
      },
      (error) => {
        this.notificationService.error("Failed to add progress entry")
        console.error("Error adding progress entry", error)
      },
    )
  }

  addProgressGoal(goalData: any): void {
    if (!this.currentUser) return

    const goal: ProgressGoal = {
      goalId: 0,
      userId: this.currentUser.userId,
      metricId: goalData.metricId,
      targetValue: goalData.targetValue,
      targetDate: goalData.targetDate,
      startValue: goalData.startValue,
      startDate: new Date(),
      isCompleted: false,
      createdDate: new Date(),
    }

    this.progressService.addProgressGoal(goal).subscribe(
      (result) => {
        this.notificationService.success("Progress goal added successfully")
        this.closeAddGoalModal()
        this.loadGoals(this.currentUser!.userId)
      },
      (error) => {
        this.notificationService.error("Failed to add progress goal")
        console.error("Error adding progress goal", error)
      },
    )
  }

  deleteProgressEntry(entryId: number): void {
    if (confirm("Are you sure you want to delete this progress entry?")) {
      this.progressService.deleteProgressEntry(entryId).subscribe(
        (success) => {
          if (success) {
            this.notificationService.success("Progress entry deleted successfully")
            if (this.selectedMetric) {
              this.loadProgressEntries(this.selectedMetric.metricId)
            }
          } else {
            this.notificationService.error("Failed to delete progress entry")
          }
        },
        (error) => {
          this.notificationService.error("An error occurred while deleting the progress entry")
          console.error("Error deleting progress entry", error)
        },
      )
    }
  }

  deleteProgressGoal(goalId: number): void {
    if (confirm("Are you sure you want to delete this goal?")) {
      this.progressService.deleteProgressGoal(goalId).subscribe(
        (success) => {
          if (success) {
            this.notificationService.success("Goal deleted successfully")
            if (this.currentUser) {
              this.loadGoals(this.currentUser.userId)
            }
          } else {
            this.notificationService.error("Failed to delete goal")
          }
        },
        (error) => {
          this.notificationService.error("An error occurred while deleting the goal")
          console.error("Error deleting goal", error)
        },
      )
    }
  }

  markGoalComplete(goalId: number): void {
    this.progressService.markGoalComplete(goalId).subscribe(
      (success) => {
        if (success) {
          this.notificationService.success("Goal marked as complete")
          if (this.currentUser) {
            this.loadGoals(this.currentUser.userId)
          }
        } else {
          this.notificationService.error("Failed to update goal")
        }
      },
      (error) => {
        this.notificationService.error("An error occurred while updating the goal")
        console.error("Error updating goal", error)
      },
    )
  }

  getGoalProgress(goal: ProgressGoal): number {
    if (!this.selectedMetric) return 0

    // Find the latest entry for this metric
    const entries = this.progressEntries.filter((e) => e.metricId === goal.metricId)
    if (entries.length === 0) return 0

    // Sort by date descending to get the latest entry
    const latestEntry = entries.sort((a, b) => new Date(b.entryDate).getTime() - new Date(a.entryDate).getTime())[0]

    // Calculate progress percentage
    const totalChange = goal.targetValue - goal.startValue
    const currentChange = latestEntry.value - goal.startValue

    if (totalChange === 0) return 0

    const progressPercentage = (currentChange / totalChange) * 100

    // Ensure progress is between 0 and 100
    return Math.min(100, Math.max(0, progressPercentage))
  }

  getTimeRangeInDays(range: string): number {
    const today = new Date()

    switch (range) {
      case "1W":
        return 7
      case "1M":
        return 30
      case "3M":
        return 90
      case "6M":
        return 180
      case "1Y":
        return 365
      case "All":
      default:
        return 3650 // ~10 years, effectively "all"
    }
  }

  formatDate(date: Date | string): string {
    return new Date(date).toLocaleDateString()
  }

  getMetricUnit(metricId: number): string {
    const metric = this.metrics.find((m) => m.metricId === metricId)
    return metric ? metric.unit : ""
  }
}
