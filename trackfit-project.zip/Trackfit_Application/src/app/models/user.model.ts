export interface User {
  userId: number
  email: string
  firstName: string
  lastName: string
  userType: string
  createdDate: Date
  lastLoginDate?: Date
  isActive: boolean
  fullName?: string
}

export interface UserProfile {
  profileId: number
  userId: number
  age?: number
  gender?: string
  height?: number
  weight?: number
  fitnessLevel?: string
  fitnessGoals?: string[]
  bodyFatPercentage?: number
  profilePictureUrl?: string
  lastUpdated: Date
}

export interface TrainerProfile {
  trainerProfileId: number
  userId: number
  specialization?: string[]
  experience?: number
  biography?: string
  hourlyRate?: number
  isVerified: boolean
  rating?: number
  profilePictureUrl?: string
  lastUpdated: Date
}

export interface RegisterUser {
  email: string
  password: string
  confirmPassword: string
  firstName: string
  lastName: string
  userType: string
}

export interface LoginCredentials {
  email: string
  password: string
  rememberMe?: boolean
}

export interface UserStats {
  userId: number
  totalWorkouts: number
  totalWorkoutMinutes: number
  lastWorkoutDate?: Date
  nutritionLogDays: number
  completedChallenges: number
  achievementCount: number
  currentWeight?: number
  currentHeight?: number
  currentBodyFatPercentage?: number
}

export interface UserProgressReport {
  userId: number
  startDate: Date
  endDate: Date
  totalWorkouts: number
  totalWorkoutMinutes: number
  averageWorkoutDuration: number
  exerciseProgress: ExerciseProgress[]
  averageCalories: number
  averageProtein: number
  averageCarbohydrates: number
  averageFat: number
  dailyNutrition: DailyNutrition[]
}

export interface ExerciseProgress {
  exerciseId: number
  exerciseName: string
  maxWeight?: number
  averageWeight: number
  maxReps: number
  totalSets: number
}

export interface DailyNutrition {
  date: Date
  totalCalories: number
  totalProtein: number
  totalCarbohydrates: number
  totalFat: number
}

export interface UserAchievement {
  achievementId: number
  userId: number
  achievementType: string
  achievementName: string
  description?: string
  awardedDate: Date
  badgeUrl?: string
}
