using System.Collections.Generic;
using System.Threading.Tasks;
using Trackfit.Services.DTOs;

namespace Trackfit.Services.Interfaces
{
    public interface INutritionService
    {
        // Nutrition logs
        Task<NutritionLogDto> LogNutritionAsync(NutritionLogDto logDto);
        Task<NutritionLogDto> UpdateNutritionLogAsync(NutritionLogDto logDto);
        Task<bool> DeleteNutritionLogAsync(int logId);
        Task<IEnumerable<NutritionLogDto>> GetUserNutritionLogsAsync(int userId, System.DateTime? date = null);
        Task<NutritionSummaryDto> GetUserNutritionSummaryAsync(int userId, System.DateTime date);
        
        // Nutrition plans
        Task<NutritionPlanDto> GetNutritionPlanAsync(int planId);
        Task<IEnumerable<NutritionPlanDto>> GetUserNutritionPlansAsync(int userId);
        Task<NutritionPlanDto> CreateNutritionPlanAsync(NutritionPlanDto planDto);
        Task<NutritionPlanDto> UpdateNutritionPlanAsync(NutritionPlanDto planDto);
        Task<bool> DeleteNutritionPlanAsync(int planId);
        
        // User nutrition plans
        Task<bool> AssignNutritionPlanToUserAsync(int planId, int userId, int assignedBy);
        Task<bool> RemoveNutritionPlanFromUserAsync(int userPlanId);
        
        // Nutrition analytics
        Task<NutritionAnalyticsDto> GetUserNutritionAnalyticsAsync(int userId, System.DateTime startDate, System.DateTime endDate);
    }
}
