import { Injectable } from "@angular/core"
import type { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree, Router } from "@angular/router"
import type { Observable } from "rxjs"
import type { AuthService } from "../services/auth.service"
import type { NotificationService } from "../services/notification.service"

@Injectable({
  providedIn: "root",
})
export class RoleGuard implements CanActivate {
  constructor(
    private authService: AuthService,
    private router: Router,
    private notificationService: NotificationService,
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot,
  ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    // Check if user is authenticated
    if (!this.authService.isAuthenticated()) {
      this.router.navigate(["/login"], { queryParams: { returnUrl: state.url } })
      return false
    }

    // Check if route has data with roles
    const roles = route.data["roles"] as Array<string>
    if (!roles || roles.length === 0) {
      return true
    }

    // Check if user has required role
    const user = this.authService.currentUserValue
    if (user && roles.includes(user.userType)) {
      return true
    }

    // User doesn't have required role, redirect to appropriate dashboard
    this.notificationService.error("You do not have permission to access this area.")

    if (user) {
      switch (user.userType) {
        case "User":
          this.router.navigate(["/user/dashboard"])
          break
        case "Trainer":
          this.router.navigate(["/trainer/dashboard"])
          break
        case "Admin":
          this.router.navigate(["/admin/dashboard"])
          break
        default:
          this.router.navigate(["/"])
          break
      }
    } else {
      this.router.navigate(["/"])
    }

    return false
  }
}
