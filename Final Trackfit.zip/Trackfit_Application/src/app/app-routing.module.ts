import { NgModule } from "@angular/core"
import { RouterModule, type Routes } from "@angular/router"

// Core components
import { PageNotFoundComponent } from "./core/page-not-found/page-not-found.component"

// Auth components
import { LoginComponent } from "./auth/login/login.component"
import { RegisterComponent } from "./auth/register/register.component"
import { ForgotPasswordComponent } from "./auth/forgot-password/forgot-password.component"
import { ResetPasswordComponent } from "./auth/reset-password/reset-password.component"

// Home components
import { HomeComponent } from "./home/home.component"

// User components
import { UserProfileComponent } from "./user/user-profile/user-profile.component"
import { UserDashboardComponent } from "./user/user-dashboard/user-dashboard.component"
import { UserWorkoutsComponent } from "./user/user-workouts/user-workouts.component"
import { UserNutritionComponent } from "./user/user-nutrition/user-nutrition.component"
import { UserProgressComponent } from "./user/user-progress/user-progress.component"
import { UserChallengesComponent } from "./user/user-challenges/user-challenges.component"
import { UserSettingsComponent } from "./user/user-settings/user-settings.component"

// Trainer components
import { TrainerProfileComponent } from "./trainer/trainer-profile/trainer-profile.component"
import { TrainerDashboardComponent } from "./trainer/trainer-dashboard/trainer-dashboard.component"
import { TrainerClientsComponent } from "./trainer/trainer-clients/trainer-clients.component"
import { TrainerWorkoutsComponent } from "./trainer/trainer-workouts/trainer-workouts.component"
import { TrainerFeedbackComponent } from "./trainer/trainer-feedback/trainer-feedback.component"
import { TrainerSettingsComponent } from "./trainer/trainer-settings/trainer-settings.component"

// Admin components
import { AdminDashboardComponent } from "./admin/admin-dashboard/admin-dashboard.component"
import { AdminUsersComponent } from "./admin/admin-users/admin-users.component"
import { AdminTrainersComponent } from "./admin/admin-trainers/admin-trainers.component"
import { AdminContentComponent } from "./admin/admin-content/admin-content.component"
import { AdminAnalyticsComponent } from "./admin/admin-analytics/admin-analytics.component"
import { AdminSubscriptionsComponent } from "./admin/admin-subscriptions/admin-subscriptions.component"
import { AdminSupportComponent } from "./admin/admin-support/admin-support.component"
import { AdminSettingsComponent } from "./admin/admin-settings/admin-settings.component"

// Workout components
import { WorkoutListComponent } from "./workouts/workout-list/workout-list.component"
import { WorkoutDetailComponent } from "./workouts/workout-detail/workout-detail.component"
import { WorkoutPlayerComponent } from "./workouts/workout-player/workout-player.component"
import { ExerciseListComponent } from "./workouts/exercise-list/exercise-list.component"
import { ExerciseDetailComponent } from "./workouts/exercise-detail/exercise-detail.component"

// Nutrition components
import { NutritionLogComponent } from "./nutrition/nutrition-log/nutrition-log.component"
import { NutritionPlanComponent } from "./nutrition/nutrition-plan/nutrition-plan.component"
import { NutritionAnalyticsComponent } from "./nutrition/nutrition-analytics/nutrition-analytics.component"

// Challenge components
import { ChallengeListComponent } from "./challenges/challenge-list/challenge-list.component"
import { ChallengeDetailComponent } from "./challenges/challenge-detail/challenge-detail.component"
import { ChallengeLeaderboardComponent } from "./challenges/challenge-leaderboard/challenge-leaderboard.component"

// Guards
import { AuthGuard } from "./guards/auth.guard"
import { RoleGuard } from "./guards/role.guard"

const routes: Routes = [
  // Home routes
  { path: "", component: HomeComponent },

  // Auth routes
  { path: "login", component: LoginComponent },
  { path: "register", component: RegisterComponent },
  { path: "forgot-password", component: ForgotPasswordComponent },
  { path: "reset-password", component: ResetPasswordComponent },

  // User routes
  {
    path: "user",
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ["User"] },
    children: [
      { path: "", redirectTo: "dashboard", pathMatch: "full" },
      { path: "dashboard", component: UserDashboardComponent },
      { path: "profile", component: UserProfileComponent },
      { path: "workouts", component: UserWorkoutsComponent },
      { path: "nutrition", component: UserNutritionComponent },
      { path: "progress", component: UserProgressComponent },
      { path: "challenges", component: UserChallengesComponent },
      { path: "settings", component: UserSettingsComponent },
    ],
  },

  // Trainer routes
  {
    path: "trainer",
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ["Trainer"] },
    children: [
      { path: "", redirectTo: "dashboard", pathMatch: "full" },
      { path: "dashboard", component: TrainerDashboardComponent },
      { path: "profile", component: TrainerProfileComponent },
      { path: "clients", component: TrainerClientsComponent },
      { path: "workouts", component: TrainerWorkoutsComponent },
      { path: "feedback", component: TrainerFeedbackComponent },
      { path: "settings", component: TrainerSettingsComponent },
    ],
  },

  // Admin routes
  {
    path: "admin",
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ["Admin"] },
    children: [
      { path: "", redirectTo: "dashboard", pathMatch: "full" },
      { path: "dashboard", component: AdminDashboardComponent },
      { path: "users", component: AdminUsersComponent },
      { path: "trainers", component: AdminTrainersComponent },
      { path: "content", component: AdminContentComponent },
      { path: "analytics", component: AdminAnalyticsComponent },
      { path: "subscriptions", component: AdminSubscriptionsComponent },
      { path: "support", component: AdminSupportComponent },
      { path: "settings", component: AdminSettingsComponent },
    ],
  },

  // Workout routes
  {
    path: "workouts",
    canActivate: [AuthGuard],
    children: [
      { path: "", component: WorkoutListComponent },
      { path: ":id", component: WorkoutDetailComponent },
      { path: ":id/play", component: WorkoutPlayerComponent },
    ],
  },

  // Exercise routes
  {
    path: "exercises",
    canActivate: [AuthGuard],
    children: [
      { path: "", component: ExerciseListComponent },
      { path: ":id", component: ExerciseDetailComponent },
    ],
  },

  // Nutrition routes
  {
    path: "nutrition",
    canActivate: [AuthGuard],
    children: [
      { path: "log", component: NutritionLogComponent },
      { path: "plan", component: NutritionPlanComponent },
      { path: "analytics", component: NutritionAnalyticsComponent },
    ],
  },

  // Challenge routes
  {
    path: "challenges",
    canActivate: [AuthGuard],
    children: [
      { path: "", component: ChallengeListComponent },
      { path: ":id", component: ChallengeDetailComponent },
      { path: ":id/leaderboard", component: ChallengeLeaderboardComponent },
    ],
  },

  // Fallback route
  { path: "**", component: PageNotFoundComponent },
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
