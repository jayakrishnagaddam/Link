using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json;

namespace Trackfit.DAL.Models
{
    public class WorkoutProgram
    {
        [Key]
        public int ProgramId { get; set; }
        
        [Required]
        [StringLength(100)]
        public string ProgramName { get; set; }
        
        public string Description { get; set; }
        
        [Required]
        [StringLength(20)]
        public string DifficultyLevel { get; set; } // 'Beginner', 'Intermediate', 'Advanced'
        
        [Required]
        public int CategoryId { get; set; }
        
        [Required]
        public int Duration { get; set; } // in minutes
        
        public string EquipmentRequired { get; set; } // JSON array of equipment
        
        [StringLength(255)]
        public string ImageUrl { get; set; }
        
        [Required]
        public int CreatedBy { get; set; }
        
        [Required]
        public DateTime CreatedDate { get; set; }
        
        [Required]
        public bool IsPublic { get; set; }
        
        [Required]
        public bool IsActive { get; set; }
        
        // Navigation properties
        [ForeignKey("CategoryId")]
        public virtual ExerciseCategory Category { get; set; }
        
        [ForeignKey("CreatedBy")]
        public virtual User Creator { get; set; }
        
        public virtual ICollection<WorkoutProgramExercise> ProgramExercises { get; set; }
        public virtual ICollection<UserWorkoutSchedule> UserSchedules { get; set; }
        public virtual ICollection<UserWorkoutLog> UserLogs { get; set; }
        
        // Helper methods for JSON properties
        public string[] GetEquipmentRequired()
        {
            if (string.IsNullOrEmpty(EquipmentRequired))
                return Array.Empty<string>();
            
            return JsonSerializer.Deserialize<string[]>(EquipmentRequired);
        }
        
        public void SetEquipmentRequired(string[] equipment)
        {
            EquipmentRequired = JsonSerializer.Serialize(equipment);
        }
    }
}
