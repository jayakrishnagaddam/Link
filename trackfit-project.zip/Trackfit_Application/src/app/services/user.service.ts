import { Injectable } from "@angular/core"
import type { HttpClient } from "@angular/common/http"
import { environment } from "../../environments/environment"

@Injectable({
  providedIn: "root",
})
export class UserService {
  private apiUrl = `${environment.apiUrl}/users`

  constructor(private http: HttpClient) {
    // Constructor code here
  }

  // Methods for user service here

  // Let's create the home page and login components:
  // Home page component code here

  // Login component code here
}
