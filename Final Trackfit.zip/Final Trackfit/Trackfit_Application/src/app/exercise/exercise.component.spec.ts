import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ExerciseComponent } from './exercise.component';

describe('ExerciseComponent', () => {
  let component: ExerciseComponent;
  let fixture: ComponentFixture<ExerciseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExerciseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExerciseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load sample exercise if no exercise is provided', () => {
    expect(component.exercise).toBeTruthy();
    expect(component.exercise?.name).toBe('Push-up');
  });

  it('should emit startExercise event when onStart is called', () => {
    spyOn(component.startExercise, 'emit');
    component.onStart();
    expect(component.startExercise.emit).toHaveBeenCalledWith(component.exercise?.id);
  });

  it('should emit completeSet event when onCompleteSet is called', () => {
    spyOn(component.completeSet, 'emit');
    component.onCompleteSet();
    expect(component.completeSet.emit).toHaveBeenCalled();
  });

  it('should emit skipExercise event when onSkip is called', () => {
    spyOn(component.skipExercise, 'emit');
    component.onSkip();
    expect(component.skipExercise.emit).toHaveBeenCalled();
  });

  it('should navigate instruction steps correctly', () => {
    component.activeInstructionStep = 1;
    component.prevInstructionStep();
    expect(component.activeInstructionStep).toBe(0);
    
    component.nextInstructionStep();
    expect(component.activeInstructionStep).toBe(1);
  });

  it('should format time correctly', () => {
    expect(component.formatTime(65)).toBe('1:05');
    expect(component.formatTime(125)).toBe('2:05');
  });
});