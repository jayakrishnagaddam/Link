using System.Threading.Tasks;
using Trackfit.DAL.Data;
using Trackfit.DAL.Models;
using Trackfit.DAL.Repositories;

namespace Trackfit.DAL.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly TrackfitDbContext _context;
        
        public IRepository<User> Users { get; private set; }
        public IRepository<UserProfile> UserProfiles { get; private set; }
        public IRepository<TrainerProfile> TrainerProfiles { get; private set; }
        public IRepository<TrainerCredential> TrainerCredentials { get; private set; }
        public IRepository<TrainerClient> TrainerClients { get; private set; }
        public IRepository<ExerciseCategory> ExerciseCategories { get; private set; }
        public IRepository<Exercise> Exercises { get; private set; }
        public IRepository<WorkoutProgram> WorkoutPrograms { get; private set; }
        public IRepository<WorkoutProgramExercise> WorkoutProgramExercises { get; private set; }
        public IRepository<UserWorkoutSchedule> UserWorkoutSchedules { get; private set; }
        public IRepository<UserWorkoutLog> UserWorkoutLogs { get; private set; }
        public IRepository<UserExerciseLog> UserExerciseLogs { get; private set; }
        public IRepository<TrainerFeedback> TrainerFeedback { get; private set; }
        public IRepository<NutritionLog> NutritionLogs { get; private set; }
        public IRepository<NutritionPlan> NutritionPlans { get; private set; }
        public IRepository<UserNutritionPlan> UserNutritionPlans { get; private set; }
        public IRepository<Challenge> Challenges { get; private set; }
        public IRepository<ChallengeParticipant> ChallengeParticipants { get; private set; }
        public IRepository<UserAchievement> UserAchievements { get; private set; }
        public IRepository<Message> Messages { get; private set; }
        public IRepository<Notification> Notifications { get; private set; }
        public IRepository<Subscription> Subscriptions { get; private set; }
        public IRepository<UserSubscription> UserSubscriptions { get; private set; }
        public IRepository<SupportTicket> SupportTickets { get; private set; }
        
        public UnitOfWork(TrackfitDbContext context)
        {
            _context = context;
            
            Users = new Repository<User>(context);
            UserProfiles = new Repository<UserProfile>(context);
            TrainerProfiles = new Repository<TrainerProfile>(context);
            TrainerCredentials = new Repository<TrainerCredential>(context);
            TrainerClients = new Repository<TrainerClient>(context);
            ExerciseCategories = new Repository<ExerciseCategory>(context);
            Exercises = new Repository<Exercise>(context);
            WorkoutPrograms = new Repository<WorkoutProgram>(context);
            WorkoutProgramExercises = new Repository<WorkoutProgramExercise>(context);
            UserWorkoutSchedules = new Repository<UserWorkoutSchedule>(context);
            UserWorkoutLogs = new Repository<UserWorkoutLog>(context);
            UserExerciseLogs = new Repository<UserExerciseLog>(context);
            TrainerFeedback = new Repository<TrainerFeedback>(context);
            NutritionLogs = new Repository<NutritionLog>(context);
            NutritionPlans = new Repository<NutritionPlan>(context);
            UserNutritionPlans = new Repository<UserNutritionPlan>(context);
            Challenges = new Repository<Challenge>(context);
            ChallengeParticipants = new Repository<ChallengeParticipant>(context);
            UserAchievements = new Repository<UserAchievement>(context);
            Messages = new Repository<Message>(context);
            Notifications = new Repository<Notification>(context);
            Subscriptions = new Repository<Subscription>(context);
            UserSubscriptions = new Repository<UserSubscription>(context);
            SupportTickets = new Repository<SupportTicket>(context);
        }
        
        public async Task<int> CompleteAsync()
        {
            return await _context.SaveChangesAsync();
        }
        
        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
