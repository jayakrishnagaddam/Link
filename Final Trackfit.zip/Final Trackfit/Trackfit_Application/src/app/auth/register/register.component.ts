import { Component, type OnInit } from "@angular/core"
import { type FormBuilder, type FormGroup, Validators } from "@angular/forms"
import type { Router, ActivatedRoute } from "@angular/router"
import type { AuthService } from "../../services/auth.service"
import type { NotificationService } from "../../services/notification.service"

@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.css"],
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup
  loading = false
  submitted = false
  error = ""
  userType = "User"

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService,
    private notificationService: NotificationService,
  ) {
    // Redirect to home if already logged in
    if (this.authService.currentUserValue) {
      this.router.navigate(["/"])
    }
  }

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group(
      {
        firstName: ["", Validators.required],
        lastName: ["", Validators.required],
        email: ["", [Validators.required, Validators.email]],
        password: ["", [Validators.required, Validators.minLength(6)]],
        confirmPassword: ["", Validators.required],
      },
      {
        validator: this.mustMatch("password", "confirmPassword"),
      },
    )

    // Get user type from route parameters
    const userTypeParam = this.route.snapshot.queryParams["userType"]
    if (userTypeParam && ["User", "Trainer", "Admin"].includes(userTypeParam)) {
      this.userType = userTypeParam
    }
  }

  // Custom validator to check if passwords match
  mustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName]
      const matchingControl = formGroup.controls[matchingControlName]

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
        return
      }

      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true })
      } else {
        matchingControl.setErrors(null)
      }
    }
  }

  // Convenience getter for easy access to form fields
  get f() {
    return this.registerForm.controls
  }

  onSubmit(): void {
    this.submitted = true

    // Stop here if form is invalid
    if (this.registerForm.invalid) {
      return
    }

    this.loading = true
    this.authService
      .register({
        firstName: this.f.firstName.value,
        lastName: this.f.lastName.value,
        email: this.f.email.value,
        password: this.f.password.value,
        confirmPassword: this.f.confirmPassword.value,
        userType: this.userType,
      })
      .subscribe(
        (data) => {
          this.notificationService.success("Registration successful. Please login.")
          this.router.navigate(["/login"], { queryParams: { userType: this.userType } })
        },
        (error) => {
          this.error = error.error?.message || "Registration failed. Please try again."
          this.loading = false
        },
      )
  }

  switchUserType(userType: string): void {
    this.userType = userType
  }

  navigateToLogin(): void {
    this.router.navigate(["/login"], { queryParams: { userType: this.userType } })
  }
}
