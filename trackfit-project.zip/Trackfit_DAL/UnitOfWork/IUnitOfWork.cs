using System;
using System.Threading.Tasks;
using Trackfit.DAL.Repositories;
using Trackfit.DAL.Models;

namespace Trackfit.DAL.UnitOfWork
{
    public interface IUnitOfWork : IDisposable
    {
        IRepository<User> Users { get; }
        IRepository<UserProfile> UserProfiles { get; }
        IRepository<TrainerProfile> TrainerProfiles { get; }
        IRepository<TrainerCredential> TrainerCredentials { get; }
        IRepository<TrainerClient> TrainerClients { get; }
        IRepository<ExerciseCategory> ExerciseCategories { get; }
        IRepository<Exercise> Exercises { get; }
        IRepository<WorkoutProgram> WorkoutPrograms { get; }
        IRepository<WorkoutProgramExercise> WorkoutProgramExercises { get; }
        IRepository<UserWorkoutSchedule> UserWorkoutSchedules { get; }
        IRepository<UserWorkoutLog> UserWorkoutLogs { get; }
        IRepository<UserExerciseLog> UserExerciseLogs { get; }
        IRepository<TrainerFeedback> TrainerFeedback { get; }
        IRepository<NutritionLog> NutritionLogs { get; }
        IRepository<NutritionPlan> NutritionPlans { get; }
        IRepository<UserNutritionPlan> UserNutritionPlans { get; }
        IRepository<Challenge> Challenges { get; }
        IRepository<ChallengeParticipant> ChallengeParticipants { get; }
        IRepository<UserAchievement> UserAchievements { get; }
        IRepository<Message> Messages { get; }
        IRepository<Notification> Notifications { get; }
        IRepository<Subscription> Subscriptions { get; }
        IRepository<UserSubscription> UserSubscriptions { get; }
        IRepository<SupportTicket> SupportTickets { get; }
        
        Task<int> CompleteAsync();
    }
}
