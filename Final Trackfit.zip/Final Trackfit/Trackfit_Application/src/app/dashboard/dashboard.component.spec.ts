import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DashboardComponent } from './dashboard.component';

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DashboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have user stats', () => {
    expect(component.userStats).toBeDefined();
    expect(component.userStats.workoutsCompleted).toBeGreaterThan(0);
  });

  it('should have recent workouts', () => {
    expect(component.recentWorkouts.length).toBeGreaterThan(0);
  });

  it('should have upcoming events', () => {
    expect(component.upcomingEvents.length).toBeGreaterThan(0);
  });
});