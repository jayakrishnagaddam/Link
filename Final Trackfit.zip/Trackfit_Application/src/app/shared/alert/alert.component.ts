import { Component, type OnInit, type OnDestroy, Input } from "@angular/core"
import type { Subscription } from "rxjs"
import type { NotificationService } from "../../services/notification.service"

@Component({
  selector: "app-alert",
  templateUrl: "./alert.component.html",
  styleUrls: ["./alert.component.css"],
})
export class AlertComponent implements OnInit, OnDestroy {
  @Input() id = "default-alert"
  @Input() fade = true

  alerts: any[] = []
  alertSubscription: Subscription

  constructor(private notificationService: NotificationService) {}

  ngOnInit() {
    // Subscribe to new alert notifications
    this.alertSubscription = this.notificationService.getAlert().subscribe((alert) => {
      // Clear alerts when an empty alert is received
      if (!alert) {
        // Filter out alerts without 'keepAfterRouteChange' flag
        this.alerts = this.alerts.filter((x) => x.keepAfterRouteChange)

        // Remove 'keepAfterRouteChange' flag on the rest
        this.alerts.forEach((x) => delete x.keepAfterRouteChange)
        return
      }

      // Add alert to array
      this.alerts.push(alert)

      // Auto close alert if required
      if (alert.autoClose !== false) {
        setTimeout(() => this.removeAlert(alert), 5000)
      }
    })
  }

  ngOnDestroy() {
    // Unsubscribe to avoid memory leaks
    this.alertSubscription.unsubscribe()
  }

  removeAlert(alert: any) {
    // Check if alert has already been removed
    if (!this.alerts.includes(alert)) return

    if (this.fade) {
      // Fade out alert
      alert.fade = true

      // Remove alert after faded out
      setTimeout(() => {
        this.alerts = this.alerts.filter((x) => x !== alert)
      }, 250)
    } else {
      // Remove alert
      this.alerts = this.alerts.filter((x) => x !== alert)
    }
  }

  cssClass(alert: any) {
    if (!alert) return

    const classes = ["alert", "alert-dismissible"]

    const alertTypeClass = {
      success: "alert-success",
      error: "alert-danger",
      info: "alert-info",
      warning: "alert-warning",
    }

    classes.push(alertTypeClass[alert.type])

    if (alert.fade) {
      classes.push("fade")
    }

    return classes.join(" ")
  }
}
