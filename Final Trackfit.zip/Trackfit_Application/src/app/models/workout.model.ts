export interface WorkoutProgram {
  programId: number
  programName: string
  description?: string
  difficultyLevel: string
  categoryId: number
  categoryName?: string
  duration: number
  equipmentRequired?: string[]
  imageUrl?: string
  createdBy: number
  creatorName?: string
  createdDate: Date
  isPublic: boolean
  isActive: boolean
  programExercises?: WorkoutProgramExercise[]
}

export interface WorkoutProgramExercise {
  programExerciseId: number
  programId: number
  exerciseId: number
  exercise?: Exercise
  sets: number
  reps: number
  restPeriod: number
  orderIndex: number
  notes?: string
}

export interface Exercise {
  exerciseId: number
  exerciseName: string
  description?: string
  categoryId: number
  categoryName?: string
  difficultyLevel: string
  instructions?: string
  videoUrl?: string
  imageUrl?: string
  equipmentRequired?: string[]
  createdBy: number
  createdDate: Date
  isActive: boolean
}

export interface ExerciseCategory {
  categoryId: number
  categoryName: string
  description?: string
}

export interface UserWorkoutSchedule {
  scheduleId: number
  userId: number
  programId: number
  programName?: string
  scheduledDate: Date
  isRecurring: boolean
  recurrencePattern?: string
  recurrenceDetails?: any
  reminderTime?: number
  reminderType?: string
  status: string
  createdDate: Date
}

export interface UserWorkoutLog {
  logId: number
  userId: number
  programId: number
  programName?: string
  scheduleId?: number
  startTime: Date
  endTime?: Date
  notes?: string
  rating?: number
  createdDate: Date
  exerciseLogs?: UserExerciseLog[]
}

export interface UserExerciseLog {
  exerciseLogId: number
  logId: number
  exerciseId: number
  exerciseName?: string
  sets: number
  reps: number
  weight?: number
  duration?: number
  notes?: string
  formVideoUrl?: string
}

export interface TrainerFeedback {
  feedbackId: number
  exerciseLogId: number
  trainerProfileId: number
  trainerName?: string
  feedbackText: string
  annotatedVideoUrl?: string
  voiceFeedbackUrl?: string
  createdDate: Date
}
