import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-workout-detail',
  templateUrl: './workout-detail.component.html',
  styleUrls: ['./workout-detail.component.css']
})
export class WorkoutDetailComponent implements OnInit {
  workoutId: number;
  workout = {
    id: 0,
    name: '',
    description: '',
    duration: 0,
    caloriesBurned: 0,
    difficulty: '',
    category: '',
    exercises: []
  };

  constructor(private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.workoutId = +params['id'];
      this.loadWorkoutDetails(this.workoutId);
    });
  }

  loadWorkoutDetails(id: number): void {
    // In a real app, this would come from a service
    this.workout = {
      id: id,
      name: 'Full Body HIIT',
      description: 'High-intensity interval training that targets all major muscle groups.',
      duration: 45,
      caloriesBurned: 450,
      difficulty: 'Intermediate',
      category: 'HIIT',
      exercises: [
        { id: 1, name: 'Jumping Jacks', sets: 3, reps: 20, duration: 0, rest: 30, instructions: 'Jump with feet apart and hands above head, then return to standing position' },
        { id: 2, name: 'Push-ups', sets: 3, reps: 15, duration: 0, rest: 45, instructions: 'Keep body straight, lower to ground and push back up' },
        { id: 3, name: 'Mountain Climbers', sets: 3, reps: 0, duration: 30, rest: 30, instructions: 'In plank position, alternate bringing knees to chest' },
        { id: 4, name: 'Squats', sets: 3, reps: 20, duration: 0, rest: 45, instructions: 'Bend knees and lower as if sitting, keep back straight' },
        { id: 5, name: 'Plank', sets: 3, reps: 0, duration: 45, rest: 30, instructions: 'Hold plank position with core engaged and back straight' }
      ]
    };
  }

  startWorkout(): void {
    console.log('Starting workout', this.workoutId);
    // Navigate to workout session/timer
  }

  editWorkout(): void {
    console.log('Editing workout', this.workoutId);
    // Navigate to workout form
  }
}