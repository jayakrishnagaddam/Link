using System.Collections.Generic;
using System.Threading.Tasks;
using Trackfit.Services.DTOs;

namespace Trackfit.Services.Interfaces
{
    public interface IWorkoutService
    {
        // Workout programs
        Task<WorkoutProgramDto> GetWorkoutProgramAsync(int programId);
        Task<IEnumerable<WorkoutProgramDto>> GetAllWorkoutProgramsAsync(int page = 1, int pageSize = 20);
        Task<IEnumerable<WorkoutProgramDto>> SearchWorkoutProgramsAsync(string searchTerm, int? categoryId = null, string difficultyLevel = null);
        Task<IEnumerable<WorkoutProgramDto>> GetRecommendedWorkoutProgramsAsync(int userId);
        
        // Exercises
        Task<ExerciseDto> GetExerciseAsync(int exerciseId);
        Task<IEnumerable<ExerciseDto>> GetAllExercisesAsync(int page = 1, int pageSize = 50);
        Task<IEnumerable<ExerciseDto>> GetExercisesByCategoryAsync(int categoryId);
        Task<ExerciseDto> CreateExerciseAsync(ExerciseDto exerciseDto);
        Task<ExerciseDto> UpdateExerciseAsync(ExerciseDto exerciseDto);
        Task<bool> DeleteExerciseAsync(int exerciseId);
        
        // Exercise categories
        Task<IEnumerable<ExerciseCategoryDto>> GetAllExerciseCategoriesAsync();
        Task<ExerciseCategoryDto> CreateExerciseCategoryAsync(ExerciseCategoryDto categoryDto);
        Task<ExerciseCategoryDto> UpdateExerciseCategoryAsync(ExerciseCategoryDto categoryDto);
        Task<bool> DeleteExerciseCategoryAsync(int categoryId);
        
        // User workout schedules
        Task<UserWorkoutScheduleDto> ScheduleWorkoutAsync(UserWorkoutScheduleDto scheduleDto);
        Task<UserWorkoutScheduleDto> UpdateWorkoutScheduleAsync(UserWorkoutScheduleDto scheduleDto);
        Task<bool> CancelWorkoutScheduleAsync(int scheduleId);
        Task<IEnumerable<UserWorkoutScheduleDto>> GetUserWorkoutSchedulesAsync(int userId, System.DateTime? startDate = null, System.DateTime? endDate = null);
        
        // User workout logs
        Task<UserWorkoutLogDto> LogWorkoutAsync(UserWorkoutLogDto logDto);
        Task<IEnumerable<UserWorkoutLogDto>> GetUserWorkoutLogsAsync(int userId, System.DateTime? startDate = null, System.DateTime? endDate = null);
        Task<UserWorkoutLogDto> GetWorkoutLogDetailsAsync(int logId);
        
        // User exercise logs
        Task<IEnumerable<UserExerciseLogDto>> GetUserExerciseLogsAsync(int userId, int exerciseId);
        Task<UserExerciseLogDto> GetExerciseLogDetailsAsync(int exerciseLogId);
    }
}
