import { Injectable } from "@angular/core"
import type { HttpClient } from "@angular/common/http"
import type { Observable } from "rxjs"

import type { Challenge, ChallengeParticipant, ChallengeLeaderboardEntry } from "../models/challenge.model"
import { environment } from "../../environments/environment"

@Injectable({
  providedIn: "root",
})
export class ChallengeService {
  private apiUrl = `${environment.apiUrl}/challenges`

  constructor(private http: HttpClient) {}

  getChallenge(id: number): Observable<Challenge> {
    return this.http.get<Challenge>(`${this.apiUrl}/${id}`)
  }

  getAllChallenges(includePrivate = false): Observable<Challenge[]> {
    return this.http.get<Challenge[]>(`${this.apiUrl}?includePrivate=${includePrivate}`)
  }

  getActiveChallenges(): Observable<Challenge[]> {
    return this.http.get<Challenge[]>(`${this.apiUrl}/active`)
  }

  getUserChallenges(userId: number): Observable<Challenge[]> {
    return this.http.get<Challenge[]>(`${this.apiUrl}/user/${userId}`)
  }

  createChallenge(challenge: Challenge): Observable<Challenge> {
    return this.http.post<Challenge>(`${this.apiUrl}`, challenge)
  }

  updateChallenge(challenge: Challenge): Observable<Challenge> {
    return this.http.put<Challenge>(`${this.apiUrl}/${challenge.challengeId}`, challenge)
  }

  deleteChallenge(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`)
  }

  joinChallenge(challengeId: number, userId: number): Observable<boolean> {
    return this.http.post<boolean>(`${this.apiUrl}/${challengeId}/join/${userId}`, {})
  }

  leaveChallenge(challengeId: number, userId: number): Observable<boolean> {
    return this.http.delete<boolean>(`${this.apiUrl}/${challengeId}/leave/${userId}`)
  }

  getChallengeParticipants(challengeId: number): Observable<ChallengeParticipant[]> {
    return this.http.get<ChallengeParticipant[]>(`${this.apiUrl}/${challengeId}/participants`)
  }

  getUserChallengeProgress(challengeId: number, userId: number): Observable<ChallengeParticipant> {
    return this.http.get<ChallengeParticipant>(`${this.apiUrl}/${challengeId}/progress/${userId}`)
  }

  updateChallengeProgress(challengeId: number, userId: number, progress: number): Observable<boolean> {
    return this.http.put<boolean>(`${this.apiUrl}/${challengeId}/progress/${userId}?progress=${progress}`, {})
  }

  getChallengeLeaderboard(challengeId: number): Observable<ChallengeLeaderboardEntry[]> {
    return this.http.get<ChallengeLeaderboardEntry[]>(`${this.apiUrl}/${challengeId}/leaderboard`)
  }

  inviteUserToChallenge(challengeId: number, inviterId: number, inviteeId: number): Observable<boolean> {
    return this.http.post<boolean>(
      `${this.apiUrl}/${challengeId}/invite?inviterId=${inviterId}&inviteeId=${inviteeId}`,
      {},
    )
  }
}
