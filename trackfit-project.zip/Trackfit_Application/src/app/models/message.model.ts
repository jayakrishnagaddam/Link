export interface Message {
  messageId: number
  senderId: number
  senderName?: string
  receiverId: number
  receiverName?: string
  messageText: string
  attachmentUrl?: string
  attachmentType?: string
  sentDate: Date
  readDate?: Date
  isDeleted: boolean
}

export interface Notification {
  notificationId: number
  userId: number
  notificationType: string
  title: string
  message: string
  relatedEntityId?: number
  relatedEntityType?: string
  createdDate: Date
  isRead: boolean
  isDeleted: boolean
}
