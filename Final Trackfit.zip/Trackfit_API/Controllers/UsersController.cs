using System;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Trackfit.Services.DTOs;
using Trackfit.Services.Interfaces;

namespace Trackfit.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserService _userService;
        
        public UsersController(IUserService userService)
        {
            _userService = userService;
        }
        
        [HttpGet("{id}")]
        public async Task<IActionResult> GetUser(int id)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow users to access their own data unless they are an admin
            if (id != currentUserId && userRole != "Admin")
                return Forbid();
                
            var user = await _userService.GetUserByIdAsync(id);
            
            if (user == null)
                return NotFound();
                
            return Ok(user);
        }
        
        [HttpGet("profile/{id}")]
        public async Task<IActionResult> GetUserProfile(int id)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow users to access their own profile unless they are an admin or trainer
            if (id != currentUserId && userRole != "Admin" && userRole != "Trainer")
                return Forbid();
                
            var profile = await _userService.GetUserProfileAsync(id);
            
            if (profile == null)
                return NotFound();
                
            return Ok(profile);
        }
        
        [HttpPut("profile/{id}")]
        public async Task<IActionResult> UpdateUserProfile(int id, [FromBody] UserProfileDto profileDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
                
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            
            // Only allow users to update their own profile
            if (id != currentUserId)
                return Forbid();
                
            // Ensure the profile ID matches the route ID
            if (profileDto.UserId != id)
                return BadRequest(new { message = "User ID mismatch" });
                
            try
            {
                var updatedProfile = await _userService.UpdateUserProfileAsync(profileDto);
                
                if (updatedProfile == null)
                    return NotFound();
                    
                return Ok(updatedProfile);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while updating the profile", error = ex.Message });
            }
        }
        
        [HttpGet("{id}/stats")]
        public async Task<IActionResult> GetUserStats(int id)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow users to access their own stats unless they are an admin or trainer
            if (id != currentUserId && userRole != "Admin" && userRole != "Trainer")
                return Forbid();
                
            var stats = await _userService.GetUserStatsAsync(id);
            
            if (stats == null)
                return NotFound();
                
            return Ok(stats);
        }
        
        [HttpGet("{id}/progress")]
        public async Task<IActionResult> GetUserProgress(int id, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow users to access their own progress unless they are an admin or trainer
            if (id != currentUserId && userRole != "Admin" && userRole != "Trainer")
                return Forbid();
                
            var progress = await _userService.GetUserProgressReportAsync(id, startDate, endDate);
            
            if (progress == null)
                return NotFound();
                
            return Ok(progress);
        }
        
        [HttpGet("{id}/workouts")]
        public async Task<IActionResult> GetUserWorkoutHistory(int id, [FromQuery] int page = 1, [FromQuery] int pageSize = 10)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow users to access their own workout history unless they are an admin or trainer
            if (id != currentUserId && userRole != "Admin" && userRole != "Trainer")
                return Forbid();
                
            var workouts = await _userService.GetUserWorkoutHistoryAsync(id, page, pageSize);
            
            return Ok(workouts);
        }
        
        [HttpPost("{id}/workouts")]
        public async Task<IActionResult> LogWorkout(int id, [FromBody] UserWorkoutLogDto workoutLogDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
                
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            
            // Only allow users to log their own workouts
            if (id != currentUserId)
                return Forbid();
                
            // Ensure the user ID matches the route ID
            if (workoutLogDto.UserId != id)
                return BadRequest(new { message = "User ID mismatch" });
                
            try
            {
                var loggedWorkout = await _userService.LogWorkoutAsync(workoutLogDto);
                return Ok(loggedWorkout);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while logging the workout", error = ex.Message });
            }
        }
        
        [HttpGet("{id}/nutrition")]
        public async Task<IActionResult> GetUserNutritionLogs(int id, [FromQuery] DateTime? date = null)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow users to access their own nutrition logs unless they are an admin or trainer
            if (id != currentUserId && userRole != "Admin" && userRole != "Trainer")
                return Forbid();
                
            var logs = await _userService.GetUserNutritionLogsAsync(id, date);
            
            return Ok(logs);
        }
        
        [HttpPost("{id}/nutrition")]
        public async Task<IActionResult> LogNutrition(int id, [FromBody] NutritionLogDto nutritionLogDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
                
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            
            // Only allow users to log their own nutrition
            if (id != currentUserId)
                return Forbid();
                
            // Ensure the user ID matches the route ID
            if (nutritionLogDto.UserId != id)
                return BadRequest(new { message = "User ID mismatch" });
                
            try
            {
                var loggedNutrition = await _userService.LogNutritionAsync(nutritionLogDto);
                return Ok(loggedNutrition);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while logging nutrition", error = ex.Message });
            }
        }
        
        [HttpGet("{id}/achievements")]
        public async Task<IActionResult> GetUserAchievements(int id)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow users to access their own achievements unless they are an admin or trainer
            if (id != currentUserId && userRole != "Admin" && userRole != "Trainer")
                return Forbid();
                
            var achievements = await _userService.GetUserAchievementsAsync(id);
            
            return Ok(achievements);
        }
    }
}
