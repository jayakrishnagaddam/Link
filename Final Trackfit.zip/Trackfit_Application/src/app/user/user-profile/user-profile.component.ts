import { Component, type OnInit } from "@angular/core"
import { type FormBuilder, type FormGroup, Validators } from "@angular/forms"
import type { AuthService } from "../../services/auth.service"
import type { UserService } from "../../services/user.service"
import type { NotificationService } from "../../services/notification.service"
import type { User, UserProfile } from "../../models/user.model"

@Component({
  selector: "app-user-profile",
  templateUrl: "./user-profile.component.html",
  styleUrls: ["./user-profile.component.css"],
})
export class UserProfileComponent implements OnInit {
  currentUser: User | null = null
  userProfile: UserProfile | null = null
  profileForm: FormGroup
  passwordForm: FormGroup
  loading = {
    profile: false,
    password: false,
  }
  submitted = {
    profile: false,
    password: false,
  }
  error = {
    profile: "",
    password: "",
  }

  fitnessLevels = ["Beginner", "Intermediate", "Advanced"]
  fitnessGoals = [
    "Lose Weight",
    "Build Muscle",
    "Improve Endurance",
    "Increase Strength",
    "Improve Flexibility",
    "Maintain Fitness",
    "Improve Overall Health",
  ]
  selectedGoals: string[] = []

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private userService: UserService,
    private notificationService: NotificationService,
  ) {
    this.profileForm = this.formBuilder.group({
      firstName: ["", Validators.required],
      lastName: ["", Validators.required],
      email: ["", [Validators.required, Validators.email]],
      age: [null, [Validators.min(13), Validators.max(100)]],
      gender: [""],
      height: [null, [Validators.min(50), Validators.max(300)]],
      weight: [null, [Validators.min(30), Validators.max(500)]],
      fitnessLevel: [""],
      bodyFatPercentage: [null, [Validators.min(1), Validators.max(50)]],
    })

    this.passwordForm = this.formBuilder.group(
      {
        currentPassword: ["", Validators.required],
        newPassword: ["", [Validators.required, Validators.minLength(6)]],
        confirmPassword: ["", Validators.required],
      },
      {
        validator: this.mustMatch("newPassword", "confirmPassword"),
      },
    )
  }

  ngOnInit(): void {
    this.authService.currentUser.subscribe((user) => {
      this.currentUser = user
      if (user) {
        this.loadUserProfile(user.userId)
      }
    })
  }

  // Custom validator to check if passwords match
  mustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName]
      const matchingControl = formGroup.controls[matchingControlName]

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
        return
      }

      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true })
      } else {
        matchingControl.setErrors(null)
      }
    }
  }

  // Convenience getters for easy access to form fields
  get pf() {
    return this.profileForm.controls
  }
  get pwf() {
    return this.passwordForm.controls
  }

  loadUserProfile(userId: number): void {
    this.loading.profile = true
    this.userService.getUserProfile(userId).subscribe(
      (profile) => {
        this.userProfile = profile
        this.selectedGoals = profile.fitnessGoals || []

        // Update form values
        this.profileForm.patchValue({
          firstName: this.currentUser?.firstName,
          lastName: this.currentUser?.lastName,
          email: this.currentUser?.email,
          age: profile.age,
          gender: profile.gender,
          height: profile.height,
          weight: profile.weight,
          fitnessLevel: profile.fitnessLevel,
          bodyFatPercentage: profile.bodyFatPercentage,
        })

        this.loading.profile = false
      },
      (error) => {
        this.error.profile = "Failed to load profile data. Please try again."
        this.loading.profile = false
      },
    )
  }

  toggleGoal(goal: string): void {
    const index = this.selectedGoals.indexOf(goal)
    if (index === -1) {
      this.selectedGoals.push(goal)
    } else {
      this.selectedGoals.splice(index, 1)
    }
  }

  isGoalSelected(goal: string): boolean {
    return this.selectedGoals.includes(goal)
  }

  onProfileSubmit(): void {
    this.submitted.profile = true

    // Stop here if form is invalid
    if (this.profileForm.invalid) {
      return
    }

    this.loading.profile = true

    // Prepare profile data
    const profileData: UserProfile = {
      profileId: this.userProfile?.profileId || 0,
      userId: this.currentUser?.userId || 0,
      age: this.pf.age.value,
      gender: this.pf.gender.value,
      height: this.pf.height.value,
      weight: this.pf.weight.value,
      fitnessLevel: this.pf.fitnessLevel.value,
      fitnessGoals: this.selectedGoals,
      bodyFatPercentage: this.pf.bodyFatPercentage.value,
      lastUpdated: new Date(),
    }

    this.userService.updateUserProfile(profileData).subscribe(
      (updatedProfile) => {
        this.userProfile = updatedProfile
        this.notificationService.success("Profile updated successfully")
        this.loading.profile = false
      },
      (error) => {
        this.error.profile = error.error?.message || "Failed to update profile. Please try again."
        this.loading.profile = false
      },
    )
  }

  onPasswordSubmit(): void {
    this.submitted.password = true

    // Stop here if form is invalid
    if (this.passwordForm.invalid) {
      return
    }

    this.loading.password = true

    this.authService.changePassword(this.pwf.currentPassword.value, this.pwf.newPassword.value).subscribe(
      (success) => {
        if (success) {
          this.notificationService.success("Password changed successfully")
          this.passwordForm.reset()
          this.submitted.password = false
        } else {
          this.error.password = "Failed to change password. Please check your current password."
        }
        this.loading.password = false
      },
      (error) => {
        this.error.password = error.error?.message || "Failed to change password. Please try again."
        this.loading.password = false
      },
    )
  }
}
