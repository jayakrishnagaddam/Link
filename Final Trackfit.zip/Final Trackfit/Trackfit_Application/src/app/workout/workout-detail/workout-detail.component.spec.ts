import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';
import { WorkoutDetailComponent } from './workout-detail.component';

describe('WorkoutDetailComponent', () => {
  let component: WorkoutDetailComponent;
  let fixture: ComponentFixture<WorkoutDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WorkoutDetailComponent ],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            params: of({ id: 123 })
          }
        }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkoutDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load workout details based on id from route params', () => {
    expect(component.workoutId).toBe(123);
    expect(component.workout.id).toBe(123);
  });

  it('should have exercises in the workout', () => {
    expect(component.workout.exercises.length).toBeGreaterThan(0);
  });

  it('should have startWorkout method', () => {
    spyOn(console, 'log');
    component.startWorkout();
    expect(console.log).toHaveBeenCalledWith('Starting workout', 123);
  });

  it('should have editWorkout method', () => {
    spyOn(console, 'log');
    component.editWorkout();
    expect(console.log).toHaveBeenCalledWith('Editing workout', 123);
  });
});