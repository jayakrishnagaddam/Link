import { Injectable } from "@angular/core"
import type { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from "@angular/common/http"
import { type Observable, throwError } from "rxjs"
import { catchError } from "rxjs/operators"
import type { Router } from "@angular/router"
import type { AuthService } from "../services/auth.service"
import type { NotificationService } from "../services/notification.service"

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  constructor(
    private authService: AuthService,
    private router: Router,
    private notificationService: NotificationService,
  ) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(request).pipe(
      catchError((error: HttpErrorResponse) => {
        if (error.status === 401) {
          // Auto logout if 401 response returned from API
          this.authService.logout()
          this.router.navigate(["/login"])
          this.notificationService.error("Session expired. Please log in again.")
        } else if (error.status === 403) {
          this.notificationService.error("You do not have permission to perform this action.")
        } else if (error.status === 404) {
          this.notificationService.error("The requested resource was not found.")
        } else if (error.status === 500) {
          this.notificationService.error("A server error occurred. Please try again later.")
        } else {
          // Handle other errors
          const errorMessage = error.error?.message || error.statusText || "An unknown error occurred"
          this.notificationService.error(errorMessage)
        }

        return throwError(error)
      }),
    )
  }
}
