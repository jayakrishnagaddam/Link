using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Trackfit.DAL.Models;
using Trackfit.DAL.UnitOfWork;
using Trackfit.Services.DTOs;
using Trackfit.Services.Interfaces;
using Trackfit.Services.Mappers;

namespace Trackfit.Services.Implementations
{
    public class UserService : IUserService
    {
        private readonly IUnitOfWork _unitOfWork;
        
        public UserService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        
        public async Task<UserDto> AuthenticateAsync(string email, string password)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
                return null;
                
            var user = await _unitOfWork.Users.SingleOrDefaultAsync(u => u.Email == email);
            
            // Check if user exists
            if (user == null)
                return null;
                
            // Check if password is correct
            if (!VerifyPasswordHash(password, user.PasswordHash))
                return null;
                
            // Update last login date
            user.LastLoginDate = DateTime.Now;
            _unitOfWork.Users.Update(user);
            await _unitOfWork.CompleteAsync();
            
            return UserMapper.ToDto(user);
        }
        
        public async Task<UserDto> RegisterUserAsync(RegisterUserDto registerDto)
        {
            // Validate input
            if (string.IsNullOrEmpty(registerDto.Email) || string.IsNullOrEmpty(registerDto.Password))
                throw new ArgumentException("Email and password are required");
                
            // Check if email already exists
            if (await _unitOfWork.Users.ExistsAsync(u => u.Email == registerDto.Email))
                throw new InvalidOperationException("Email already exists");
                
            // Create new user
            var user = new User
            {
                Email = registerDto.Email,
                PasswordHash = HashPassword(registerDto.Password),
                FirstName = registerDto.FirstName,
                LastName = registerDto.LastName,
                UserType = registerDto.UserType,
                CreatedDate = DateTime.Now,
                IsActive = true
            };
            
            await _unitOfWork.Users.AddAsync(user);
            await _unitOfWork.CompleteAsync();
            
            // Create user profile
            var userProfile = new UserProfile
            {
                UserId = user.UserId,
                LastUpdated = DateTime.Now
            };
            
            await _unitOfWork.UserProfiles.AddAsync(userProfile);
            
            // Create trainer profile if user is a trainer
            if (user.UserType == "Trainer")
            {
                var trainerProfile = new TrainerProfile
                {
                    UserId = user.UserId,
                    IsVerified = false,
                    LastUpdated = DateTime.Now
                };
                
                await _unitOfWork.TrainerProfiles.AddAsync(trainerProfile);
            }
            
            await _unitOfWork.CompleteAsync();
            
            return UserMapper.ToDto(user);
        }
        
        public async Task<bool> ChangePasswordAsync(int userId, string currentPassword, string newPassword)
        {
            var user = await _unitOfWork.Users.GetByIdAsync(userId);
            
            if (user == null)
                return false;
                
            // Verify current password
            if (!VerifyPasswordHash(currentPassword, user.PasswordHash))
                return false;
                
            // Update password
            user.PasswordHash = HashPassword(newPassword);
            _unitOfWork.Users.Update(user);
            await _unitOfWork.CompleteAsync();
            
            return true;
        }
        
        public async Task<UserDto> GetUserByIdAsync(int userId)
        {
            var user = await _unitOfWork.Users.GetByIdAsync(userId);
            return user != null ? UserMapper.ToDto(user) : null;
        }
        
        public async Task<UserDto> GetUserByEmailAsync(string email)
        {
            var user = await _unitOfWork.Users.SingleOrDefaultAsync(u => u.Email == email);
            return user != null ? UserMapper.ToDto(user) : null;
        }
        
        public async Task<IEnumerable<UserDto>> GetAllUsersAsync()
        {
            var users = await _unitOfWork.Users.GetAllAsync();
            return users.Select(UserMapper.ToDto);
        }
        
        public async Task<UserDto> UpdateUserAsync(UserDto userDto)
        {
            var user = await _unitOfWork.Users.GetByIdAsync(userDto.UserId);
            
            if (user == null)
                return null;
                
            // Update user properties
            user.FirstName = userDto.FirstName;
            user.LastName = userDto.LastName;
            user.Email = userDto.Email;
            
            _unitOfWork.Users.Update(user);
            await _unitOfWork.CompleteAsync();
            
            return UserMapper.ToDto(user);
        }
        
        public async Task<bool> DeactivateUserAsync(int userId)
        {
            var user = await _unitOfWork.Users.GetByIdAsync(userId);
            
            if (user == null)
                return false;
                
            user.IsActive = false;
            _unitOfWork.Users.Update(user);
            await _unitOfWork.CompleteAsync();
            
            return true;
        }
        
        public async Task<bool> ActivateUserAsync(int userId)
        {
            var user = await _unitOfWork.Users.GetByIdAsync(userId);
            
            if (user == null)
                return false;
                
            user.IsActive = true;
            _unitOfWork.Users.Update(user);
            await _unitOfWork.CompleteAsync();
            
            return true;
        }
        
        public async Task<UserProfileDto> GetUserProfileAsync(int userId)
        {
            var userProfile = await _unitOfWork.UserProfiles.SingleOrDefaultAsync(p => p.UserId == userId);
            return userProfile != null ? UserProfileMapper.ToDto(userProfile) : null;
        }
        
        public async Task<UserProfileDto> UpdateUserProfileAsync(UserProfileDto profileDto)
        {
            var userProfile = await _unitOfWork.UserProfiles.SingleOrDefaultAsync(p => p.UserId == profileDto.UserId);
            
            if (userProfile == null)
                return null;
                
            // Update profile properties
            userProfile.Age = profileDto.Age;
            userProfile.Gender = profileDto.Gender;
            userProfile.Height = profileDto.Height;
            userProfile.Weight = profileDto.Weight;
            userProfile.FitnessLevel = profileDto.FitnessLevel;
            userProfile.BodyFatPercentage = profileDto.BodyFatPercentage;
            userProfile.ProfilePictureUrl = profileDto.ProfilePictureUrl;
            userProfile.LastUpdated = DateTime.Now;
            
            // Update fitness goals
            if (profileDto.FitnessGoals != null)
            {
                userProfile.SetFitnessGoals(profileDto.FitnessGoals);
            }
            
            _unitOfWork.UserProfiles.Update(userProfile);
            await _unitOfWork.CompleteAsync();
            
            return UserProfileMapper.ToDto(userProfile);
        }
        
        public async Task<UserStatsDto> GetUserStatsAsync(int userId)
        {
            // Get user profile
            var userProfile = await _unitOfWork.UserProfiles.SingleOrDefaultAsync(p => p.UserId == userId);
            
            if (userProfile == null)
                return null;
                
            // Get workout stats
            var workoutLogs = await _unitOfWork.UserWorkoutLogs.FindAsync(w => w.UserId == userId);
            var workoutCount = workoutLogs.Count();
            var totalWorkoutMinutes = workoutLogs.Sum(w => (w.EndTime - w.StartTime).TotalMinutes);
            var lastWorkout = workoutLogs.OrderByDescending(w => w.StartTime).FirstOrDefault();
            
            // Get nutrition stats
            var nutritionLogs = await _unitOfWork.NutritionLogs.FindAsync(n => n.UserId == userId);
            var nutritionLogDays = nutritionLogs.Select(n => n.LogDate).Distinct().Count();
            
            // Get challenge stats
            var challenges = await _unitOfWork.ChallengeParticipants.FindAsync(c => c.UserId == userId);
            var completedChallenges = challenges.Count(c => c.Status == "Completed");
            
            // Get achievement stats
            var achievements = await _unitOfWork.UserAchievements.FindAsync(a => a.UserId == userId);
            var achievementCount = achievements.Count();
            
            return new UserStatsDto
            {
                UserId = userId,
                TotalWorkouts = workoutCount,
                TotalWorkoutMinutes = (int)totalWorkoutMinutes,
                LastWorkoutDate = lastWorkout?.StartTime,
                NutritionLogDays = nutritionLogDays,
                CompletedChallenges = completedChallenges,
                AchievementCount = achievementCount,
                CurrentWeight = userProfile.Weight,
                CurrentHeight = userProfile.Height,
                CurrentBodyFatPercentage = userProfile.BodyFatPercentage
            };
        }
        
        public async Task<UserProgressReportDto> GetUserProgressReportAsync(int userId, DateTime startDate, DateTime endDate)
        {
            // Get workout logs for the period
            var workoutLogs = await _unitOfWork.UserWorkoutLogs
                .FindAsync(w => w.UserId == userId && w.StartTime >= startDate && w.StartTime <= endDate);
                
            // Get exercise logs for the period
            var exerciseLogs = new List<UserExerciseLog>();
            foreach (var log in workoutLogs)
            {
                var logs = await _unitOfWork.UserExerciseLogs.FindAsync(e => e.LogId == log.LogId);
                exerciseLogs.AddRange(logs);
            }
            
            // Get nutrition logs for the period
            var nutritionLogs = await _unitOfWork.NutritionLogs
                .FindAsync(n => n.UserId == userId && n.LogDate >= startDate && n.LogDate <= endDate);
                
            // Calculate workout stats
            var workoutCount = workoutLogs.Count();
            var totalWorkoutMinutes = workoutLogs.Sum(w => (w.EndTime - w.StartTime).TotalMinutes);
            var averageWorkoutDuration = workoutCount > 0 ? totalWorkoutMinutes / workoutCount : 0;
            
            // Calculate exercise stats
            var exerciseStats = exerciseLogs
                .GroupBy(e => e.ExerciseId)
                .Select(g => new ExerciseProgressDto
                {
                    ExerciseId = g.Key,
                    ExerciseName = g.First().Exercise?.ExerciseName ?? "Unknown",
                    MaxWeight = g.Max(e => e.Weight),
                    AverageWeight = g.Average(e => e.Weight ?? 0),
                    MaxReps = g.Max(e => e.Reps),
                    TotalSets = g.Sum(e => e.Sets)
                })
                .ToList();
                
            // Calculate nutrition stats
            var nutritionStats = nutritionLogs
                .GroupBy(n => n.LogDate)
                .Select(g => new DailyNutritionDto
                {
                    Date = g.Key,
                    TotalCalories = g.Sum(n => n.Calories ?? 0),
                    TotalProtein = g.Sum(n => n.Protein ?? 0),
                    TotalCarbohydrates = g.Sum(n => n.Carbohydrates ?? 0),
                    TotalFat = g.Sum(n => n.Fat ?? 0)
                })
                .ToList();
                
            var averageCalories = nutritionStats.Count > 0 ? nutritionStats.Average(n => n.TotalCalories) : 0;
            var averageProtein = nutritionStats.Count > 0 ? nutritionStats.Average(n => n.TotalProtein) : 0;
            var averageCarbs = nutritionStats.Count > 0 ? nutritionStats.Average(n => n.TotalCarbohydrates) : 0;
            var averageFat = nutritionStats.Count > 0 ? nutritionStats.Average(n => n.TotalFat) : 0;
            
            return new UserProgressReportDto
            {
                UserId = userId,
                StartDate = startDate,
                EndDate = endDate,
                TotalWorkouts = workoutCount,
                TotalWorkoutMinutes = (int)totalWorkoutMinutes,
                AverageWorkoutDuration = (int)averageWorkoutDuration,
                ExerciseProgress = exerciseStats,
                AverageCalories = (int)averageCalories,
                AverageProtein = (decimal)averageProtein,
                AverageCarbohydrates = (decimal)averageCarbs,
                AverageFat = (decimal)averageFat,
                DailyNutrition = nutritionStats
            };
        }
        
        public async Task<IEnumerable<UserWorkoutLogDto>> GetUserWorkoutHistoryAsync(int userId, int page = 1, int pageSize = 10)
        {
            var workoutLogs = await _unitOfWork.UserWorkoutLogs
                .Include(w => w.Program)
                .FindAsync(w => w.UserId == userId);
                
            return workoutLogs
                .OrderByDescending(w => w.StartTime)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(UserWorkoutLogMapper.ToDto);
        }
        
        public async Task<UserWorkoutLogDto> LogWorkoutAsync(UserWorkoutLogDto workoutLogDto)
        {
            var workoutLog = UserWorkoutLogMapper.FromDto(workoutLogDto);
            
            await _unitOfWork.UserWorkoutLogs.AddAsync(workoutLog);
            await _unitOfWork.CompleteAsync();
            
            // Add exercise logs
            if (workoutLogDto.ExerciseLogs != null)
            {
                foreach (var exerciseLogDto in workoutLogDto.ExerciseLogs)
                {
                    var exerciseLog = UserExerciseLogMapper.FromDto(exerciseLogDto);
                    exerciseLog.LogId = workoutLog.LogId;
                    
                    await _unitOfWork.UserExerciseLogs.AddAsync(exerciseLog);
                }
                
                await _unitOfWork.CompleteAsync();
            }
            
            // Update workout schedule if applicable
            if (workoutLog.ScheduleId.HasValue)
            {
                var schedule = await _unitOfWork.UserWorkoutSchedules.GetByIdAsync(workoutLog.ScheduleId.Value);
                
                if (schedule != null)
                {
                    schedule.Status = "Completed";
                    _unitOfWork.UserWorkoutSchedules.Update(schedule);
                    await _unitOfWork.CompleteAsync();
                }
            }
            
            return UserWorkoutLogMapper.ToDto(workoutLog);
        }
        
        public async Task<IEnumerable<NutritionLogDto>> GetUserNutritionLogsAsync(int userId, DateTime? date = null)
        {
            var query = _unitOfWork.NutritionLogs.Include(n => n.User);
            
            if (date.HasValue)
            {
                var nutritionLogs = await query.FindAsync(n => n.UserId == userId && n.LogDate == date.Value);
                return nutritionLogs.Select(NutritionLogMapper.ToDto);
            }
            else
            {
                var nutritionLogs = await query.FindAsync(n => n.UserId == userId);
                return nutritionLogs
                    .OrderByDescending(n => n.LogDate)
                    .ThenBy(n => n.MealType)
                    .Select(NutritionLogMapper.ToDto);
            }
        }
        
        public async Task<NutritionLogDto> LogNutritionAsync(NutritionLogDto nutritionLogDto)
        {
            var nutritionLog = NutritionLogMapper.FromDto(nutritionLogDto);
            
            await _unitOfWork.NutritionLogs.AddAsync(nutritionLog);
            await _unitOfWork.CompleteAsync();
            
            return NutritionLogMapper.ToDto(nutritionLog);
        }
        
        public async Task<IEnumerable<UserAchievementDto>> GetUserAchievementsAsync(int userId)
        {
            var achievements = await _unitOfWork.UserAchievements.FindAsync(a => a.UserId == userId);
            
            return achievements
                .OrderByDescending(a => a.AwardedDate)
                .Select(UserAchievementMapper.ToDto);
        }
        
        #region Helper Methods
        
        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(hashedBytes);
            }
        }
        
        private bool VerifyPasswordHash(string password, string storedHash)
        {
            var hashedPassword = HashPassword(password);
            return hashedPassword == storedHash;
        }
        
        #endregion
    }
}
