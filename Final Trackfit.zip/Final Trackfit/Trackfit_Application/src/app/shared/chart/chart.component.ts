import { Component, Input, type OnInit, type AfterViewInit, type ElementRef, ViewChild } from "@angular/core"
import Chart from "chart.js/auto"

@Component({
  selector: "app-chart",
  templateUrl: "./chart.component.html",
  styleUrls: ["./chart.component.css"],
})
export class ChartComponent implements OnInit, AfterViewInit {
  @ViewChild("chartCanvas") chartCanvas: ElementRef<HTMLCanvasElement>

  @Input() type: "line" | "bar" | "pie" | "doughnut" | "radar" = "line"
  @Input() data: any
  @Input() options: any = {}
  @Input() height = 300
  @Input() responsive = true

  private chart: Chart

  constructor() {}

  ngOnInit(): void {}

  ngAfterViewInit(): void {
    this.createChart()
  }

  private createChart(): void {
    if (!this.chartCanvas || !this.data) return

    const ctx = this.chartCanvas.nativeElement.getContext("2d")

    if (!ctx) return

    this.chart = new Chart(ctx, {
      type: this.type,
      data: this.data,
      options: {
        responsive: this.responsive,
        maintainAspectRatio: false,
        ...this.options,
      },
    })
  }

  // Method to update chart data
  updateChart(newData: any): void {
    if (!this.chart) return

    this.chart.data = newData
    this.chart.update()
  }

  // Method to destroy chart when component is destroyed
  ngOnDestroy(): void {
    if (this.chart) {
      this.chart.destroy()
    }
  }
}
