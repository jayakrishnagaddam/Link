import { Component, type OnInit } from "@angular/core"
import type { Router } from "@angular/router"
import type { WorkoutService } from "../../services/workout.service"
import type { AuthService } from "../../services/auth.service"
import type { NotificationService } from "../../services/notification.service"
import type { User } from "../../models/user.model"
import type { UserWorkoutSchedule, UserWorkoutLog, WorkoutProgram } from "../../models/workout.model"

@Component({
  selector: "app-user-workouts",
  templateUrl: "./user-workouts.component.html",
  styleUrls: ["./user-workouts.component.css"],
})
export class UserWorkoutsComponent implements OnInit {
  currentUser: User | null = null
  upcomingWorkouts: UserWorkoutSchedule[] = []
  recentWorkouts: UserWorkoutLog[] = []
  recommendedWorkouts: WorkoutProgram[] = []
  savedWorkouts: WorkoutProgram[] = []

  activeTab = "upcoming"

  loading = {
    upcoming: true,
    history: true,
    recommended: true,
    saved: true,
  }

  error = {
    upcoming: "",
    history: "",
    recommended: "",
    saved: "",
  }

  constructor(
    private authService: AuthService,
    private workoutService: WorkoutService,
    private notificationService: NotificationService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.authService.currentUser.subscribe((user) => {
      this.currentUser = user
      if (user) {
        this.loadUpcomingWorkouts(user.userId)
        this.loadWorkoutHistory(user.userId)
        this.loadRecommendedWorkouts(user.userId)
        this.loadSavedWorkouts(user.userId)
      }
    })
  }

  setActiveTab(tab: string): void {
    this.activeTab = tab
  }

  startWorkout(scheduleId: number): void {
    // Navigate to workout player with schedule ID
    this.router.navigate(["/workouts", scheduleId, "play"])
  }

  rescheduleWorkout(scheduleId: number): void {
    // Implement reschedule functionality
    // This could open a modal or navigate to a reschedule page
  }

  cancelWorkout(scheduleId: number): void {
    if (confirm("Are you sure you want to cancel this workout?")) {
      this.workoutService.cancelWorkoutSchedule(scheduleId).subscribe(
        (success) => {
          if (success) {
            this.notificationService.success("Workout cancelled successfully")
            // Reload upcoming workouts
            if (this.currentUser) {
              this.loadUpcomingWorkouts(this.currentUser.userId)
            }
          } else {
            this.notificationService.error("Failed to cancel workout")
          }
        },
        (error) => {
          this.notificationService.error("An error occurred while cancelling the workout")
        },
      )
    }
  }

  viewWorkoutDetails(workoutId: number): void {
    this.router.navigate(["/workouts", workoutId])
  }

  scheduleWorkout(programId: number): void {
    // Navigate to schedule workout page with program ID
    this.router.navigate(["/user/schedule-workout"], { queryParams: { programId } })
  }

  saveWorkout(programId: number): void {
    if (this.currentUser) {
      this.workoutService.saveWorkoutProgram(this.currentUser.userId, programId).subscribe(
        (success) => {
          if (success) {
            this.notificationService.success("Workout saved to your collection")
            this.loadSavedWorkouts(this.currentUser!.userId)
          } else {
            this.notificationService.error("Failed to save workout")
          }
        },
        (error) => {
          this.notificationService.error("An error occurred while saving the workout")
        },
      )
    }
  }

  removeSavedWorkout(programId: number): void {
    if (this.currentUser && confirm("Are you sure you want to remove this workout from your saved collection?")) {
      this.workoutService.removeSavedWorkoutProgram(this.currentUser.userId, programId).subscribe(
        (success) => {
          if (success) {
            this.notificationService.success("Workout removed from your collection")
            this.loadSavedWorkouts(this.currentUser!.userId)
          } else {
            this.notificationService.error("Failed to remove workout")
          }
        },
        (error) => {
          this.notificationService.error("An error occurred while removing the workout")
        },
      )
    }
  }

  browseWorkouts(): void {
    this.router.navigate(["/workouts"])
  }

  private loadUpcomingWorkouts(userId: number): void {
    this.loading.upcoming = true
    const today = new Date()
    const nextMonth = new Date()
    nextMonth.setMonth(today.getMonth() + 1)

    this.workoutService.getUserWorkoutSchedules(userId, today, nextMonth).subscribe(
      (schedules) => {
        this.upcomingWorkouts = schedules
          .filter((s) => s.status === "Scheduled")
          .sort((a, b) => new Date(a.scheduledDate).getTime() - new Date(b.scheduledDate).getTime())
        this.loading.upcoming = false
      },
      (error) => {
        console.error("Error loading upcoming workouts", error)
        this.error.upcoming = "Failed to load upcoming workouts"
        this.loading.upcoming = false
      },
    )
  }

  private loadWorkoutHistory(userId: number): void {
    this.loading.history = true
    this.workoutService.getUserWorkoutLogs(userId).subscribe(
      (logs) => {
        this.recentWorkouts = logs.sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime())
        this.loading.history = false
      },
      (error) => {
        console.error("Error loading workout history", error)
        this.error.history = "Failed to load workout history"
        this.loading.history = false
      },
    )
  }

  private loadRecommendedWorkouts(userId: number): void {
    this.loading.recommended = true
    this.workoutService.getRecommendedWorkoutPrograms(userId).subscribe(
      (programs) => {
        this.recommendedWorkouts = programs
        this.loading.recommended = false
      },
      (error) => {
        console.error("Error loading recommended workouts", error)
        this.error.recommended = "Failed to load workout recommendations"
        this.loading.recommended = false
      },
    )
  }

  private loadSavedWorkouts(userId: number): void {
    this.loading.saved = true
    this.workoutService.getSavedWorkoutPrograms(userId).subscribe(
      (programs) => {
        this.savedWorkouts = programs
        this.loading.saved = false
      },
      (error) => {
        console.error("Error loading saved workouts", error)
        this.error.saved = "Failed to load saved workouts"
        this.loading.saved = false
      },
    )
  }

  formatDate(date: Date | string): string {
    const d = new Date(date)
    return d.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  getWorkoutTimeRemaining(schedule: UserWorkoutSchedule): string {
    const now = new Date()
    const scheduledDate = new Date(schedule.scheduledDate)
    const diffMs = scheduledDate.getTime() - now.getTime()

    if (diffMs < 0) return "Overdue"

    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))
    const diffHours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))

    if (diffDays > 0) {
      return `${diffDays}d ${diffHours}h`
    } else {
      const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60))
      return `${diffHours}h ${diffMinutes}m`
    }
  }

  getWorkoutDuration(log: UserWorkoutLog): string {
    if (!log.endTime) return "In progress"

    const start = new Date(log.startTime)
    const end = new Date(log.endTime)
    const diffMs = end.getTime() - start.getTime()

    const diffMinutes = Math.floor(diffMs / (1000 * 60))

    if (diffMinutes < 60) {
      return `${diffMinutes} min`
    } else {
      const hours = Math.floor(diffMinutes / 60)
      const minutes = diffMinutes % 60
      return `${hours}h ${minutes}m`
    }
  }
}
