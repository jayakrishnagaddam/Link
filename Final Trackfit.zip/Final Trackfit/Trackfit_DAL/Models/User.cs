using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Trackfit.DAL.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }
        
        [Required]
        [EmailAddress]
        [StringLength(100)]
        public string Email { get; set; }
        
        [Required]
        [StringLength(255)]
        public string PasswordHash { get; set; }
        
        [Required]
        [StringLength(50)]
        public string FirstName { get; set; }
        
        [Required]
        [StringLength(50)]
        public string LastName { get; set; }
        
        [Required]
        [StringLength(20)]
        public string UserType { get; set; } // 'User', 'Trainer', 'Admin'
        
        [Required]
        public DateTime CreatedDate { get; set; }
        
        public DateTime? LastLoginDate { get; set; }
        
        [Required]
        public bool IsActive { get; set; }
        
        // Navigation properties
        public virtual UserProfile UserProfile { get; set; }
        public virtual TrainerProfile TrainerProfile { get; set; }
        public virtual ICollection<WorkoutProgram> CreatedWorkoutPrograms { get; set; }
        public virtual ICollection<UserWorkoutLog> WorkoutLogs { get; set; }
        public virtual ICollection<UserWorkoutSchedule> WorkoutSchedules { get; set; }
        public virtual ICollection<NutritionLog> NutritionLogs { get; set; }
        public virtual ICollection<Message> SentMessages { get; set; }
        public virtual ICollection<Message> ReceivedMessages { get; set; }
        public virtual ICollection<Notification> Notifications { get; set; }
        public virtual ICollection<UserSubscription> Subscriptions { get; set; }
        public virtual ICollection<ChallengeParticipant> ChallengeParticipations { get; set; }
        public virtual ICollection<UserAchievement> Achievements { get; set; }
        public virtual ICollection<SupportTicket> SupportTickets { get; set; }
        
        [NotMapped]
        public string FullName => $"{FirstName} {LastName}";
    }
}
