import { Injectable } from "@angular/core"
import type { HttpClient } from "@angular/common/http"
import type { Observable } from "rxjs"

import type {
  NutritionLog,
  NutritionPlan,
  UserNutritionPlan,
  NutritionSummary,
  NutritionAnalytics,
} from "../models/nutrition.model"
import { environment } from "../../environments/environment"

@Injectable({
  providedIn: "root",
})
export class NutritionService {
  private apiUrl = `${environment.apiUrl}/nutrition`

  constructor(private http: HttpClient) {}

  logNutrition(log: NutritionLog): Observable<NutritionLog> {
    return this.http.post<NutritionLog>(`${this.apiUrl}/log`, log)
  }

  updateNutritionLog(log: NutritionLog): Observable<NutritionLog> {
    return this.http.put<NutritionLog>(`${this.apiUrl}/log/${log.nutritionLogId}`, log)
  }

  deleteNutritionLog(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/log/${id}`)
  }

  getUserNutritionLogs(userId: number, date?: Date): Observable<NutritionLog[]> {
    let url = `${this.apiUrl}/log/${userId}`
    if (date) {
      url += `?date=${date.toISOString()}`
    }
    return this.http.get<NutritionLog[]>(url)
  }

  getUserNutritionSummary(userId: number, date: Date): Observable<NutritionSummary> {
    return this.http.get<NutritionSummary>(`${this.apiUrl}/summary/${userId}?date=${date.toISOString()}`)
  }

  getNutritionPlan(id: number): Observable<NutritionPlan> {
    return this.http.get<NutritionPlan>(`${this.apiUrl}/plan/${id}`)
  }

  getUserNutritionPlans(userId: number): Observable<UserNutritionPlan[]> {
    return this.http.get<UserNutritionPlan[]>(`${this.apiUrl}/plan/user/${userId}`)
  }

  createNutritionPlan(plan: NutritionPlan): Observable<NutritionPlan> {
    return this.http.post<NutritionPlan>(`${this.apiUrl}/plan`, plan)
  }

  updateNutritionPlan(plan: NutritionPlan): Observable<NutritionPlan> {
    return this.http.put<NutritionPlan>(`${this.apiUrl}/plan/${plan.planId}`, plan)
  }

  deleteNutritionPlan(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/plan/${id}`)
  }

  assignNutritionPlanToUser(planId: number, userId: number, assignedBy: number): Observable<boolean> {
    return this.http.post<boolean>(`${this.apiUrl}/plan/${planId}/assign/${userId}?assignedBy=${assignedBy}`, {})
  }

  removeNutritionPlanFromUser(userPlanId: number): Observable<boolean> {
    return this.http.delete<boolean>(`${this.apiUrl}/plan/user/${userPlanId}`)
  }

  getUserNutritionAnalytics(userId: number, startDate: Date, endDate: Date): Observable<NutritionAnalytics> {
    return this.http.get<NutritionAnalytics>(
      `${this.apiUrl}/analytics/${userId}?startDate=${startDate.toISOString()}&endDate=${endDate.toISOString()}`,
    )
  }
}
