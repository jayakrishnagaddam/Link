using System;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Trackfit.Services.DTOs;
using Trackfit.Services.Interfaces;

namespace Trackfit.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class WorkoutsController : ControllerBase
    {
        private readonly IWorkoutService _workoutService;
        
        public WorkoutsController(IWorkoutService workoutService)
        {
            _workoutService = workoutService;
        }
        
        [HttpGet]
        public async Task<IActionResult> GetAllWorkoutPrograms([FromQuery] int page = 1, [FromQuery] int pageSize = 20)
        {
            var programs = await _workoutService.GetAllWorkoutProgramsAsync(page, pageSize);
            return Ok(programs);
        }
        
        [HttpGet("{id}")]
        public async Task<IActionResult> GetWorkoutProgram(int id)
        {
            var program = await _workoutService.GetWorkoutProgramAsync(id);
            
            if (program == null)
                return NotFound();
                
            return Ok(program);
        }
        
        [HttpGet("search")]
        public async Task<IActionResult> SearchWorkoutPrograms([FromQuery] string searchTerm, [FromQuery] int? categoryId = null, [FromQuery] string difficultyLevel = null)
        {
            var programs = await _workoutService.SearchWorkoutProgramsAsync(searchTerm, categoryId, difficultyLevel);
            return Ok(programs);
        }
        
        [HttpGet("recommended/{userId}")]
        public async Task<IActionResult> GetRecommendedWorkoutPrograms(int userId)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow users to get recommendations for themselves unless they are an admin or trainer
            if (userId != currentUserId && userRole != "Admin" && userRole != "Trainer")
                return Forbid();
                
            var programs = await _workoutService.GetRecommendedWorkoutProgramsAsync(userId);
            return Ok(programs);
        }
        
        [HttpGet("exercises")]
        public async Task<IActionResult> GetAllExercises([FromQuery] int page = 1, [FromQuery] int pageSize = 50)
        {
            var exercises = await _workoutService.GetAllExercisesAsync(page, pageSize);
            return Ok(exercises);
        }
        
        [HttpGet("exercises/{id}")]
        public async Task<IActionResult> GetExercise(int id)
        {
            var exercise = await _workoutService.GetExerciseAsync(id);
            
            if (exercise == null)
                return NotFound();
                
            return Ok(exercise);
        }
        
        [HttpGet("exercises/category/{categoryId}")]
        public async Task<IActionResult> GetExercisesByCategory(int categoryId)
        {
            var exercises = await _workoutService.GetExercisesByCategoryAsync(categoryId);
            return Ok(exercises);
        }
        
        [HttpGet("categories")]
        public async Task<IActionResult> GetAllExerciseCategories()
        {
            var categories = await _workoutService.GetAllExerciseCategoriesAsync();
            return Ok(categories);
        }
        
        [HttpPost]
        [Authorize(Roles = "Trainer,Admin")]
        public async Task<IActionResult> CreateWorkoutProgram([FromBody] WorkoutProgramDto programDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
                
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            
            // Set the creator ID to the current user
            programDto.CreatedBy = currentUserId;
            
            try
            {
                var createdProgram = await _workoutService.CreateWorkoutProgramAsync(programDto);
                return CreatedAtAction(nameof(GetWorkoutProgram), new { id = createdProgram.ProgramId }, createdProgram);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while creating the workout program", error = ex.Message });
            }
        }
        
        [HttpPut("{id}")]
        [Authorize(Roles = "Trainer,Admin")]
        public async Task<IActionResult> UpdateWorkoutProgram(int id, [FromBody] WorkoutProgramDto programDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
                
            if (programDto.ProgramId != id)
                return BadRequest(new { message = "Program ID mismatch" });
                
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow the creator or an admin to update the program
            if (programDto.CreatedBy != currentUserId && userRole != "Admin")
                return Forbid();
                
            try
            {
                var updatedProgram = await _workoutService.UpdateWorkoutProgramAsync(programDto);
                
                if (updatedProgram == null)
                    return NotFound();
                    
                return Ok(updatedProgram);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while updating the workout program", error = ex.Message });
            }
        }
        
        [HttpDelete("{id}")]
        [Authorize(Roles = "Trainer,Admin")]
        public async Task<IActionResult> DeleteWorkoutProgram(int id)
        {
            var program = await _workoutService.GetWorkoutProgramAsync(id);
            
            if (program == null)
                return NotFound();
                
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow the creator or an admin to delete the program
            if (program.CreatedBy != currentUserId && userRole != "Admin")
                return Forbid();
                
            try
            {
                var result = await _workoutService.DeleteWorkoutProgramAsync(id);
                
                if (!result)
                    return NotFound();
                    
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting the workout program", error = ex.Message });
            }
        }
        
        [HttpPost("exercises")]
        [Authorize(Roles = "Trainer,Admin")]
        public async Task<IActionResult> CreateExercise([FromBody] ExerciseDto exerciseDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
                
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            
            // Set the creator ID to the current user
            exerciseDto.CreatedBy = currentUserId;
            
            try
            {
                var createdExercise = await _workoutService.CreateExerciseAsync(exerciseDto);
                return CreatedAtAction(nameof(GetExercise), new { id = createdExercise.ExerciseId }, createdExercise);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while creating the exercise", error = ex.Message });
            }
        }
        
        [HttpPut("exercises/{id}")]
        [Authorize(Roles = "Trainer,Admin")]
        public async Task<IActionResult> UpdateExercise(int id, [FromBody] ExerciseDto exerciseDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
                
            if (exerciseDto.ExerciseId != id)
                return BadRequest(new { message = "Exercise ID mismatch" });
                
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow the creator or an admin to update the exercise
            if (exerciseDto.CreatedBy != currentUserId && userRole != "Admin")
                return Forbid();
                
            try
            {
                var updatedExercise = await _workoutService.UpdateExerciseAsync(exerciseDto);
                
                if (updatedExercise == null)
                    return NotFound();
                    
                return Ok(updatedExercise);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while updating the exercise", error = ex.Message });
            }
        }
        
        [HttpDelete("exercises/{id}")]
        [Authorize(Roles = "Trainer,Admin")]
        public async Task<IActionResult> DeleteExercise(int id)
        {
            var exercise = await _workoutService.GetExerciseAsync(id);
            
            if (exercise == null)
                return NotFound();
                
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow the creator or an admin to delete the exercise
            if (exercise.CreatedBy != currentUserId && userRole != "Admin")
                return Forbid();
                
            try
            {
                var result = await _workoutService.DeleteExerciseAsync(id);
                
                if (!result)
                    return NotFound();
                    
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting the exercise", error = ex.Message });
            }
        }
        
        [HttpPost("schedule")]
        public async Task<IActionResult> ScheduleWorkout([FromBody] UserWorkoutScheduleDto scheduleDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
                
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow users to schedule workouts for themselves unless they are a trainer or admin
            if (scheduleDto.UserId != currentUserId && userRole != "Trainer" && userRole != "Admin")
                return Forbid();
                
            try
            {
                var scheduledWorkout = await _workoutService.ScheduleWorkoutAsync(scheduleDto);
                return Ok(scheduledWorkout);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while scheduling the workout", error = ex.Message });
            }
        }
        
        [HttpGet("schedule/{userId}")]
        public async Task<IActionResult> GetUserWorkoutSchedules(int userId, [FromQuery] DateTime? startDate = null, [FromQuery] DateTime? endDate = null)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow users to view their own schedules unless they are a trainer or admin
            if (userId != currentUserId && userRole != "Trainer" && userRole != "Admin")
                return Forbid();
                
            var schedules = await _workoutService.GetUserWorkoutSchedulesAsync(userId, startDate, endDate);
            return Ok(schedules);
        }
        
        [HttpPut("schedule/{id}")]
        public async Task<IActionResult> UpdateWorkoutSchedule(int id, [FromBody] UserWorkoutScheduleDto scheduleDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
                
            if (scheduleDto.ScheduleId != id)
                return BadRequest(new { message = "Schedule ID mismatch" });
                
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow users to update their own schedules unless they are a trainer or admin
            if (scheduleDto.UserId != currentUserId && userRole != "Trainer" && userRole != "Admin")
                return Forbid();
                
            try
            {
                var updatedSchedule = await _workoutService.UpdateWorkoutScheduleAsync(scheduleDto);
                
                if (updatedSchedule == null)
                    return NotFound();
                    
                return Ok(updatedSchedule);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while updating the workout schedule", error = ex.Message });
            }
        }
        
        [HttpDelete("schedule/{id}")]
        public async Task<IActionResult> CancelWorkoutSchedule(int id)
        {
            var schedule = await _workoutService.GetWorkoutScheduleAsync(id);
            
            if (schedule == null)
                return NotFound();
                
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow users to cancel their own schedules unless they are a trainer or admin
            if (schedule.UserId != currentUserId && userRole != "Trainer" && userRole != "Admin")
                return Forbid();
                
            try
            {
                var result = await _workoutService.CancelWorkoutScheduleAsync(id);
                
                if (!result)
                    return NotFound();
                    
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while canceling the workout schedule", error = ex.Message });
            }
        }
        
        [HttpPost("log")]
        public async Task<IActionResult> LogWorkout([FromBody] UserWorkoutLogDto logDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
                
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            
            // Only allow users to log workouts for themselves
            if (logDto.UserId != currentUserId)
                return Forbid();
                
            try
            {
                var loggedWorkout = await _workoutService.LogWorkoutAsync(logDto);
                return Ok(loggedWorkout);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while logging the workout", error = ex.Message });
            }
        }
        
        [HttpGet("log/{userId}")]
        public async Task<IActionResult> GetUserWorkoutLogs(int userId, [FromQuery] DateTime? startDate = null, [FromQuery] DateTime? endDate = null)
        {
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow users to view their own logs unless they are a trainer or admin
            if (userId != currentUserId && userRole != "Trainer" && userRole != "Admin")
                return Forbid();
                
            var logs = await _workoutService.GetUserWorkoutLogsAsync(userId, startDate, endDate);
            return Ok(logs);
        }
        
        [HttpGet("log/detail/{logId}")]
        public async Task<IActionResult> GetWorkoutLogDetails(int logId)
        {
            var log = await _workoutService.GetWorkoutLogDetailsAsync(logId);
            
            if (log == null)
                return NotFound();
                
            var currentUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            
            // Only allow users to view their own log details unless they are a trainer or admin
            if (log.UserId != currentUserId && userRole != "Trainer" && userRole != "Admin")
                return Forbid();
                
            return Ok(log);
        }
    }
}
