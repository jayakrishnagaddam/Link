using System.Collections.Generic;
using System.Threading.Tasks;
using Trackfit.DAL.Models;
using Trackfit.Services.DTOs;

namespace Trackfit.Services.Interfaces
{
    public interface IUserService
    {
        // Authentication
        Task<UserDto> AuthenticateAsync(string email, string password);
        Task<UserDto> RegisterUserAsync(RegisterUserDto registerDto);
        Task<bool> ChangePasswordAsync(int userId, string currentPassword, string newPassword);
        
        // User management
        Task<UserDto> GetUserByIdAsync(int userId);
        Task<UserDto> GetUserByEmailAsync(string email);
        Task<IEnumerable<UserDto>> GetAllUsersAsync();
        Task<UserDto> UpdateUserAsync(UserDto userDto);
        Task<bool> DeactivateUserAsync(int userId);
        Task<bool> ActivateUserAsync(int userId);
        
        // User profile
        Task<UserProfileDto> GetUserProfileAsync(int userId);
        Task<UserProfileDto> UpdateUserProfileAsync(UserProfileDto profileDto);
        
        // User stats and progress
        Task<UserStatsDto> GetUserStatsAsync(int userId);
        Task<UserProgressReportDto> GetUserProgressReportAsync(int userId, System.DateTime startDate, System.DateTime endDate);
        
        // User workouts
        Task<IEnumerable<UserWorkoutLogDto>> GetUserWorkoutHistoryAsync(int userId, int page = 1, int pageSize = 10);
        Task<UserWorkoutLogDto> LogWorkoutAsync(UserWorkoutLogDto workoutLogDto);
        
        // User nutrition
        Task<IEnumerable<NutritionLogDto>> GetUserNutritionLogsAsync(int userId, System.DateTime? date = null);
        Task<NutritionLogDto> LogNutritionAsync(NutritionLogDto nutritionLogDto);
        
        // User achievements
        Task<IEnumerable<UserAchievementDto>> GetUserAchievementsAsync(int userId);
    }
}
