import { Component, type OnInit } from "@angular/core"
import { type FormBuilder, type FormGroup, Validators } from "@angular/forms"
import type { Router, ActivatedRoute } from "@angular/router"
import type { AuthService } from "../../services/auth.service"
import type { NotificationService } from "../../services/notification.service"

@Component({
  selector: "app-reset-password",
  templateUrl: "./reset-password.component.html",
  styleUrls: ["./reset-password.component.css"],
})
export class ResetPasswordComponent implements OnInit {
  resetPasswordForm: FormGroup
  loading = false
  submitted = false
  token: string
  resetSuccess = false
  error = ""

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService,
    private notificationService: NotificationService,
  ) {}

  ngOnInit(): void {
    this.token = this.route.snapshot.queryParams["token"] || ""

    if (!this.token) {
      this.error = "Invalid or missing reset token. Please request a new password reset link."
    }

    this.resetPasswordForm = this.formBuilder.group(
      {
        password: ["", [Validators.required, Validators.minLength(6)]],
        confirmPassword: ["", Validators.required],
      },
      {
        validator: this.mustMatch("password", "confirmPassword"),
      },
    )
  }

  // Custom validator to check if passwords match
  mustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName]
      const matchingControl = formGroup.controls[matchingControlName]

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
        return
      }

      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true })
      } else {
        matchingControl.setErrors(null)
      }
    }
  }

  // Convenience getter for easy access to form fields
  get f() {
    return this.resetPasswordForm.controls
  }

  onSubmit(): void {
    this.submitted = true

    // Stop here if form is invalid
    if (this.resetPasswordForm.invalid) {
      return
    }

    this.loading = true
    this.authService.resetPassword(this.token, this.f.password.value).subscribe(
      (success) => {
        this.resetSuccess = true
        this.loading = false
      },
      (error) => {
        this.error = error.error?.message || "Failed to reset password. Please try again."
        this.loading = false
      },
    )
  }

  navigateToLogin(): void {
    this.router.navigate(["/login"])
  }
}
