import { Injectable } from "@angular/core"
import type { HttpClient } from "@angular/common/http"
import { type Observable, Subject } from "rxjs"
import type { Notification } from "../models/message.model"
import { environment } from "../../environments/environment"

@Injectable({
  providedIn: "root",
})
export class NotificationService {
  private apiUrl = `${environment.apiUrl}/notifications`
  private alertSubject = new Subject<any>()

  constructor(private http: HttpClient) {}

  // API methods for notifications
  getUserNotifications(userId: number, unreadOnly = false): Observable<Notification[]> {
    return this.http.get<Notification[]>(`${this.apiUrl}/user/${userId}?unreadOnly=${unreadOnly}`)
  }

  getUnreadNotificationCount(userId: number): Observable<number> {
    return this.http.get<number>(`${this.apiUrl}/user/${userId}/count`)
  }

  markNotificationAsRead(notificationId: number): Observable<boolean> {
    return this.http.put<boolean>(`${this.apiUrl}/${notificationId}/read`, {})
  }

  deleteNotification(notificationId: number): Observable<boolean> {
    return this.http.delete<boolean>(`${this.apiUrl}/${notificationId}`)
  }

  // UI alert methods
  getAlert(): Observable<any> {
    return this.alertSubject.asObservable()
  }

  success(message: string, keepAfterRouteChange = false) {
    this.alert({ type: "success", message, keepAfterRouteChange })
  }

  error(message: string, keepAfterRouteChange = false) {
    this.alert({ type: "error", message, keepAfterRouteChange })
  }

  info(message: string, keepAfterRouteChange = false) {
    this.alert({ type: "info", message, keepAfterRouteChange })
  }

  warn(message: string, keepAfterRouteChange = false) {
    this.alert({ type: "warning", message, keepAfterRouteChange })
  }

  clear() {
    this.alertSubject.next(null)
  }

  private alert(alert: any) {
    alert.id = Date.now()
    this.alertSubject.next(alert)
  }
}
