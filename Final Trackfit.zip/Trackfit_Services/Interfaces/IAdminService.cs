using System.Collections.Generic;
using System.Threading.Tasks;
using Trackfit.Services.DTOs;

namespace Trackfit.Services.Interfaces
{
    public interface IAdminService
    {
        // User management
        Task<IEnumerable<UserDto>> GetAllUsersAsync(int page = 1, int pageSize = 20);
        Task<bool> DeactivateUserAsync(int userId);
        Task<bool> ActivateUserAsync(int userId);
        
        // Trainer verification
        Task<IEnumerable<TrainerCredentialDto>> GetPendingCredentialsAsync();
        Task<bool> VerifyTrainerCredentialAsync(int credentialId, int adminId);
        Task<bool> RejectTrainerCredentialAsync(int credentialId, int adminId, string reason);
        Task<bool> VerifyTrainerProfileAsync(int trainerProfileId, int adminId);
        
        // Content moderation
        Task<IEnumerable<ContentModerationDto>> GetFlaggedContentAsync();
        Task<bool> ApproveContentAsync(int contentId, string contentType);
        Task<bool> RemoveContentAsync(int contentId, string contentType, string reason);
        Task<bool> WarnUserAsync(int userId, string reason);
        
        // Analytics
        Task<PlatformAnalyticsDto> GetPlatformAnalyticsAsync(System.DateTime startDate, System.DateTime endDate);
        Task<UserActivityAnalyticsDto> GetUserActivityAnalyticsAsync(System.DateTime startDate, System.DateTime endDate);
        Task<WorkoutAnalyticsDto> GetWorkoutAnalyticsAsync(System.DateTime startDate, System.DateTime endDate);
        
        // Subscription management
        Task<IEnumerable<SubscriptionDto>> GetAllSubscriptionsAsync();
        Task<SubscriptionDto> CreateSubscriptionAsync(SubscriptionDto subscriptionDto);
        Task<SubscriptionDto> UpdateSubscriptionAsync(SubscriptionDto subscriptionDto);
        Task<bool> DeactivateSubscriptionAsync(int subscriptionId);
        
        // Support tickets
        Task<IEnumerable<SupportTicketDto>> GetAllSupportTicketsAsync(string status = null);
        Task<SupportTicketDto> GetSupportTicketAsync(int ticketId);
        Task<SupportTicketDto> UpdateSupportTicketAsync(SupportTicketDto ticketDto);
        Task<bool> AssignSupportTicketAsync(int ticketId, int adminId);
        Task<bool> ResolveSupportTicketAsync(int ticketId, string resolution);
    }
}
