import { Component, type OnInit } from "@angular/core"
import type { Router } from "@angular/router"
import type { AuthService } from "../../services/auth.service"
import type { User } from "../../models/user.model"
import type { NotificationService } from "../../services/notification.service"

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.css"],
})
export class HeaderComponent implements OnInit {
  currentUser: User | null = null
  isMenuOpen = false
  unreadNotifications = 0

  constructor(
    private authService: AuthService,
    private router: Router,
    private notificationService: NotificationService,
  ) {}

  ngOnInit(): void {
    this.authService.currentUser.subscribe((user) => {
      this.currentUser = user

      if (user) {
        this.loadNotifications()
      }
    })
  }

  logout(): void {
    this.authService.logout()
    this.router.navigate(["/login"])
  }

  toggleMenu(): void {
    this.isMenuOpen = !this.isMenuOpen
  }

  navigateToDashboard(): void {
    if (!this.currentUser) return

    switch (this.currentUser.userType) {
      case "User":
        this.router.navigate(["/user/dashboard"])
        break
      case "Trainer":
        this.router.navigate(["/trainer/dashboard"])
        break
      case "Admin":
        this.router.navigate(["/admin/dashboard"])
        break
    }
  }

  navigateToProfile(): void {
    if (!this.currentUser) return

    switch (this.currentUser.userType) {
      case "User":
        this.router.navigate(["/user/profile"])
        break
      case "Trainer":
        this.router.navigate(["/trainer/profile"])
        break
      case "Admin":
        this.router.navigate(["/admin/settings"])
        break
    }
  }

  navigateToSettings(): void {
    if (!this.currentUser) return

    switch (this.currentUser.userType) {
      case "User":
        this.router.navigate(["/user/settings"])
        break
      case "Trainer":
        this.router.navigate(["/trainer/settings"])
        break
      case "Admin":
        this.router.navigate(["/admin/settings"])
        break
    }
  }

  private loadNotifications(): void {
    if (!this.currentUser) return

    this.notificationService.getUnreadNotificationCount(this.currentUser.userId).subscribe(
      (count) => {
        this.unreadNotifications = count
      },
      (error) => {
        console.error("Error loading notifications", error)
      },
    )
  }
}
