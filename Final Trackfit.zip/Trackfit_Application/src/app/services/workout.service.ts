import { Injectable } from "@angular/core"
import type { HttpClient } from "@angular/common/http"
import type { Observable } from "rxjs"

import type {
  WorkoutProgram,
  Exercise,
  ExerciseCategory,
  UserWorkoutSchedule,
  UserWorkoutLog,
} from "../models/workout.model"
import { environment } from "../../environments/environment"

@Injectable({
  providedIn: "root",
})
export class WorkoutService {
  private apiUrl = `${environment.apiUrl}/workouts`

  constructor(private http: HttpClient) {}

  getAllWorkoutPrograms(page = 1, pageSize = 20): Observable<WorkoutProgram[]> {
    return this.http.get<WorkoutProgram[]>(`${this.apiUrl}?page=${page}&pageSize=${pageSize}`)
  }

  getWorkoutProgram(id: number): Observable<WorkoutProgram> {
    return this.http.get<WorkoutProgram>(`${this.apiUrl}/${id}`)
  }

  searchWorkoutPrograms(
    searchTerm: string,
    categoryId?: number,
    difficultyLevel?: string,
  ): Observable<WorkoutProgram[]> {
    let url = `${this.apiUrl}/search?searchTerm=${searchTerm}`
    if (categoryId) {
      url += `&categoryId=${categoryId}`
    }
    if (difficultyLevel) {
      url += `&difficultyLevel=${difficultyLevel}`
    }
    return this.http.get<WorkoutProgram[]>(url)
  }

  getRecommendedWorkoutPrograms(userId: number): Observable<WorkoutProgram[]> {
    return this.http.get<WorkoutProgram[]>(`${this.apiUrl}/recommended/${userId}`)
  }

  createWorkoutProgram(program: WorkoutProgram): Observable<WorkoutProgram> {
    return this.http.post<WorkoutProgram>(`${this.apiUrl}`, program)
  }

  updateWorkoutProgram(program: WorkoutProgram): Observable<WorkoutProgram> {
    return this.http.put<WorkoutProgram>(`${this.apiUrl}/${program.programId}`, program)
  }

  deleteWorkoutProgram(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`)
  }

  getAllExercises(page = 1, pageSize = 50): Observable<Exercise[]> {
    return this.http.get<Exercise[]>(`${this.apiUrl}/exercises?page=${page}&pageSize=${pageSize}`)
  }

  getExercise(id: number): Observable<Exercise> {
    return this.http.get<Exercise>(`${this.apiUrl}/exercises/${id}`)
  }

  getExercisesByCategory(categoryId: number): Observable<Exercise[]> {
    return this.http.get<Exercise[]>(`${this.apiUrl}/exercises/category/${categoryId}`)
  }

  getAllExerciseCategories(): Observable<ExerciseCategory[]> {
    return this.http.get<ExerciseCategory[]>(`${this.apiUrl}/categories`)
  }

  createExercise(exercise: Exercise): Observable<Exercise> {
    return this.http.post<Exercise>(`${this.apiUrl}/exercises`, exercise)
  }

  updateExercise(exercise: Exercise): Observable<Exercise> {
    return this.http.put<Exercise>(`${this.apiUrl}/exercises/${exercise.exerciseId}`, exercise)
  }

  deleteExercise(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/exercises/${id}`)
  }

  scheduleWorkout(schedule: UserWorkoutSchedule): Observable<UserWorkoutSchedule> {
    return this.http.post<UserWorkoutSchedule>(`${this.apiUrl}/schedule`, schedule)
  }

  getUserWorkoutSchedules(userId: number, startDate?: Date, endDate?: Date): Observable<UserWorkoutSchedule[]> {
    let url = `${this.apiUrl}/schedule/${userId}`
    if (startDate || endDate) {
      url += "?"
      if (startDate) {
        url += `startDate=${startDate.toISOString()}`
      }
      if (endDate) {
        url += startDate ? `&endDate=${endDate.toISOString()}` : `endDate=${endDate.toISOString()}`
      }
    }
    return this.http.get<UserWorkoutSchedule[]>(url)
  }

  updateWorkoutSchedule(schedule: UserWorkoutSchedule): Observable<UserWorkoutSchedule> {
    return this.http.put<UserWorkoutSchedule>(`${this.apiUrl}/schedule/${schedule.scheduleId}`, schedule)
  }

  cancelWorkoutSchedule(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/schedule/${id}`)
  }

  logWorkout(log: UserWorkoutLog): Observable<UserWorkoutLog> {
    return this.http.post<UserWorkoutLog>(`${this.apiUrl}/log`, log)
  }

  getUserWorkoutLogs(userId: number, startDate?: Date, endDate?: Date): Observable<UserWorkoutLog[]> {
    let url = `${this.apiUrl}/log/${userId}`
    if (startDate || endDate) {
      url += "?"
      if (startDate) {
        url += `startDate=${startDate.toISOString()}`
      }
      if (endDate) {
        url += startDate ? `&endDate=${endDate.toISOString()}` : `endDate=${endDate.toISOString()}`
      }
    }
    return this.http.get<UserWorkoutLog[]>(url)
  }

  getWorkoutLogDetails(logId: number): Observable<UserWorkoutLog> {
    return this.http.get<UserWorkoutLog>(`${this.apiUrl}/log/detail/${logId}`)
  }
}
